const assert = require('node:assert/strict');
const noop = () => {},
  context = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3, safeArea: { top: 47 } }),
  getMenuButtonBoundingClientRect: () => ({ bottom: 83 }),
  createCanvas: () => ({ getContext: () => context }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
const ui = require('../js/engine/ui'),
  original = ui.btn;
let buttons = [];
ui.btn = (g, b, u) => {
  buttons.push({ ...b });
  original(g, b, u);
};
const sm = require('../js/engine/scene-manager');
require('../js/scenes/game');
sm.go('game', 0);
function click(label) {
  buttons = [];
  sm.frame();
  const b = buttons.find((b) => b.label === label);
  assert(b, '按钮缺失 ' + label);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
function help() {
  click('机器人提示');
  click('再详细一点');
  click('应用这一步');
}
click('机器人提示');
click('自己试试');
assert(!sm.cur().won);
help();
click('撤回');
help();
help();
assert(!sm.cur().won, '应用一步后撤回必须恢复棋盘');
help();
assert(sm.cur().won, '三处提示应正确完成第一关');
console.log('渐进提示查看/关闭/应用/撤回/通关交互回归通过（宿主）');
