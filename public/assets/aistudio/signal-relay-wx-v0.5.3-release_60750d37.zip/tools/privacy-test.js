const assert = require('node:assert/strict'),
  path = require('node:path');
const root = path.resolve(__dirname, '../js');
for (const [width, height, dpr, top] of [
  [320, 568, 2, 20],
  [390, 844, 3, 47],
  [430, 932, 3, 54],
  [768, 1024, 2, 24],
]) {
  Object.keys(require.cache)
    .filter((k) => k.startsWith(root))
    .forEach((k) => delete require.cache[k]);
  let now = 100000,
    loop;
  Date.now = () => now;
  const noop = () => {},
    handlers = {};
  const ctx = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
  global.requestAnimationFrame = (f) => (loop = f);
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: width, windowHeight: height, pixelRatio: dpr, safeArea: { top } }),
    createCanvas: () => ({ getContext: () => ctx }),
    getStorageSync: () => null,
    setStorageSync: noop,
    onTouchStart: noop,
    onTouchEnd: noop,
    onHide: (f) => (handlers.hide = f),
    onShow: (f) => (handlers.show = f),
  };
  const sm = require('../js/engine/scene-manager'),
    notice = require('../js/engine/notice'),
    policy = require('../js/engine/policy'),
    wellbeing = require('../js/engine/wellbeing'),
    ui = require('../js/engine/ui'),
    S = require('../js/engine/storage').state;
  require('../js/engine/input');
  require('../js/scenes/settings');
  const original = ui.btn;
  let labels = [];
  ui.btn = (g, b, u) => {
    assert(b.x >= 0 && b.y >= top * dpr && b.x + b.w <= width * dpr + 1 && b.y + b.h <= height * dpr, b.label);
    labels.push(b.label);
    original(g, b, u);
  };
  sm.go('settings');
  sm.frame();
  for (const label of ['用户协议', '隐私保护指引', '适度游戏提示']) assert(labels.includes(label));
  const next = (() => {
    let found;
    const b = ui.btn;
    ui.btn = (g, v, u) => {
      if (v.label === '下一页') found = v;
      b(g, v, u);
    };
    sm.frame();
    ui.btn = b;
    return found;
  })();
  assert(next);
  sm.cur().onTap(next.x + 1, next.y + 1);
  labels = [];
  sm.frame();
  for (const label of ['匿名玩法统计：关', '诊断日志：关', '统计与诊断说明']) assert(labels.includes(label));
  policy.reporting();
  sm.frame();
  notice.close();
  policy.show('privacy');
  assert(notice.isOpen());
  sm.frame();
  let close = notice.buttons()[0];
  sm.cur().onTap(close.x + close.w / 2, close.y + close.h / 2);
  assert(!notice.isOpen());
  wx.openPrivacyContract = () => {
    throw Error('unsupported');
  };
  policy.show('privacy');
  assert(notice.isOpen());
  notice.close();
  wx.openPrivacyContract = (o) => o.fail();
  policy.show('privacy');
  assert(notice.isOpen());
  notice.close();
  let calls = 0;
  wx.openPrivacyContract = (o) => {
    calls++;
    o.success();
  };
  policy.show('privacy');
  assert.equal(calls, 1);
  assert(!notice.isOpen());
  const originalSet = global.setTimeout,
    originalClear = global.clearTimeout;
  let timeout;
  global.setTimeout = (f) => {
    timeout = f;
    return 1;
  };
  global.clearTimeout = () => {};
  wx.openPrivacyContract = () => {};
  policy.show('privacy');
  timeout();
  assert(notice.isOpen(), '接口无回调超时摘要');
  notice.close();
  policy.show('privacy');
  const stale = timeout;
  sm.go('settings');
  stale();
  assert(!notice.isOpen(), '切页后忽略过期回调');
  global.setTimeout = originalSet;
  global.clearTimeout = originalClear;
  let paused = 0,
    resumed = 0;
  sm.register('game', { won: false, draw: noop, pause: () => paused++, resume: () => resumed++ });
  sm.go('game');
  sm.start();
  now += 20 * 60000;
  loop();
  assert(!notice.isOpen());
  handlers.hide();
  now += 90 * 60000;
  loop();
  assert(!notice.isOpen(), '后台不累积');
  handlers.show();
  now += 19 * 60000;
  loop();
  assert(!notice.isOpen());
  now += 60000;
  loop();
  assert(notice.isOpen(), '前台累计40分钟提醒');
  const pauseCount = paused;
  now += 10 * 60000;
  loop();
  assert.equal(paused, pauseCount);
  close = notice.buttons()[0];
  sm.cur().onTap(close.x + 1, close.y + 1);
  assert(!notice.isOpen());
  assert(resumed >= 2);
  S.settings = { restReminders: false };
  now += 40 * 60000;
  loop();
  assert(!notice.isOpen(), '静默关闭定时弹窗');
  wellbeing.show();
  assert(notice.isOpen(), '保留手动入口');
  notice.close();
}
console.log('隐私/协议入口四屏、官方接口缺失/失败/成功、40分钟前台提醒、后台排除与静默通过（宿主）');
