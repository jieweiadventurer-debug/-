const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const original = require('./fixtures/propagate-before-o1');
const current = require('../js/core/propagate');
const levels = require('../js/data/levels').slice(0, 50);
const solutions = require('../js/data/solutions');
let seed = 7;
const random = () => (seed = (1664525 * seed + 1013904223) >>> 0) / 4294967296;
for (const level of levels) {
  const { R, C, fix } = current.parseLevel(level);
  assert.deepEqual(original.parseLevel(level), { R, C, fix });
  for (let n = 0; n < 21; n++) {
    const board = fix.map((row) => row.map(() => null));
    for (const [r, c, t, k] of solutions[level.id]) {
      if (n && random() < 0.2) continue;
      board[r][c] = { t, k: n && random() < 0.2 ? Math.floor(random() * 4) : k };
    }
    assert.deepEqual(current.propagate(R, C, fix, board, level.range), original.propagate(R, C, fix, board, level.range), level.id);
  }
}
const root = path.resolve(__dirname, '../js');
const baselineGame = fs.readFileSync(path.join(__dirname, 'fixtures/game-before-o1.txt'), 'utf8');
const realNow = Date.now;
Date.now = () => 10000;
function renders(useBaseline) {
  for (const key of Object.keys(require.cache)) if (key.startsWith(root)) delete require.cache[key];
  let calls = [],
    primary = true;
  const noop = () => {};
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3, safeArea: { top: 47 } }),
    getStorageSync: () => null,
    setStorageSync: noop,
    createCanvas: () => {
      const main = primary;
      primary = false;
      const context = new Proxy(
        { createLinearGradient: () => ({ addColorStop: noop }) },
        {
          get: (target, key) =>
            key in target
              ? target[key]
              : (...args) => {
                  if (main) calls.push([key, ...args.map((a) => (a && typeof a === 'object' ? [a.width, a.height] : a))]);
                },
          set: (target, key, value) => {
            target[key] = value;
            if (main) calls.push(['set', key, value]);
            return true;
          },
        },
      );
      return { getContext: () => context };
    },
  };
  const sm = require('../js/engine/scene-manager');
  const store = require('../js/engine/storage');
  for (const id of ['colors', 'bridge', 'split', 'range', 'stars']) store.state.seen['tutorial:' + id] = true;
  for (let i = 0; i < 5; i++) store.state.seen['chapter:' + i] = true;
  if (useBaseline) {
    const filename = path.join(root, 'scenes/game.js');
    const loaded = new Module(filename, module);
    loaded.filename = filename;
    loaded.paths = module.paths;
    loaded._compile(baselineGame, filename);
  } else require('../js/scenes/game');
  const output = [];
  for (let i = 0; i < levels.length; i++) {
    sm.go('game', i);
    calls = [];
    sm.frame();
    output.push(calls);
  }
  return output;
}
assert.equal(JSON.stringify(renders(false)), JSON.stringify(renders(true)), '50关初始画布指令必须与O1之前一致');
Date.now = realNow;
console.log('O1差分回归：1050组传播结果及50关初始绘制指令与基线一致（宿主）');
