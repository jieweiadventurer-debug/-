// Deterministic host-only exploration. Exceptions are deliberately not swallowed.
const assert = require('node:assert/strict'),
  path = require('node:path');
const root = path.resolve(__dirname, '../js');
for (const seed of [1, 2, 3, 7]) {
  for (const key of Object.keys(require.cache)) if (key.startsWith(root)) delete require.cache[key];
  let randomState = seed,
    saved = null,
    now = new Date(2026, 9, 30, 12).getTime(),
    buttons = [];
  const random = (n) => (randomState = (Math.imul(randomState, 1664525) + 1013904223) >>> 0) % n;
  Date.now = () => now;
  const noop = () => {},
    ctx = new Proxy(
      { createLinearGradient: () => ({ addColorStop: noop }) },
      { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
    );
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 2, safeArea: { top: 47 } }),
    createCanvas: () => ({ getContext: () => ctx }),
    getStorageSync: () => saved,
    setStorageSync: (key, value) => {
      saved = JSON.parse(JSON.stringify(value));
    },
    showModal: (o) => o.success && o.success({ confirm: true }),
    showToast: noop,
  };
  const sm = require('../js/engine/scene-manager'),
    ui = require('../js/engine/ui'),
    store = require('../js/engine/storage');
  const progress = require('../js/engine/progress'),
    LV = require('../js/data/levels'),
    pool = require('../js/data/daily-levels');
  progress.sync();
  store.state.settings = { ...store.state.settings, sound: false, vibration: false, reduceMotion: true };
  for (const id of ['colors', 'stars', 'bridge', 'split', 'range']) store.state.seen['tutorial:' + id] = true;
  for (let i = 0; i < 6; i++) store.state.seen['chapter:' + i] = true;
  for (const name of ['home', 'settings', 'game', 'daily', 'levels', 'world', 'rank', 'celebration', 'player-feedback'])
    require('../js/scenes/' + name);
  const original = ui.btn;
  ui.btn = (g, b, u) => {
    buttons.push(b);
    return original(g, b, u);
  };
  const scenes = ['home', 'settings', 'daily', 'levels', 'world', 'rank', 'celebration', 'game', 'player-feedback'];
  sm.go('game', 0);
  for (let step = 0; step < 15000; step++) {
    now += 10;
    buttons = [];
    sm.frame();
    const current = sm.cur(),
      mode = random(10);
    if (step % 80 === 79) {
      const name = scenes[random(scenes.length)];
      sm.go(name, name === 'game' ? [0, 4, 19, 39, 59][random(5)] : name === 'celebration' ? random(6) : undefined);
    } else if (mode < 5 && current.cellXY) {
      const p = current.cellXY(random(8), random(8));
      if (mode === 0) current.onLong(p.x, p.y);
      else current.onTap(p.x, p.y);
    } else if (buttons.length) {
      const b = buttons[random(buttons.length)];
      if (!b.disabled && !b.locked) current.onTap(b.x + b.w / 2, b.y + b.h / 2);
    }
    if (step % 97 === 0 && current.pause) {
      current.pause();
      if (current.resume) current.resume();
    }
  }
  sm.go('home');
  store.save();
  assert(store.flush());
  assert.doesNotThrow(() => JSON.stringify(saved));
  assert(Buffer.byteLength(JSON.stringify(saved), 'utf8') <= 256 * 1024, 'seed ' + seed + ' save >256KB');
  // Reload all modules from persisted state, then validate every campaign and daily snapshot.
  for (const key of Object.keys(require.cache)) if (key.startsWith(root)) delete require.cache[key];
  const reloaded = require('../js/engine/storage'),
    runs = require('../js/engine/runs');
  for (const [id] of Object.entries(reloaded.state.runs || {})) {
    const level = LV.find((l) => l.id === id);
    assert(level && runs.read(level), 'seed ' + seed + ' invalid ' + id);
  }
  if (reloaded.state.dailyRun) {
    const raw = reloaded.state.dailyRun,
      l = pool.find((l) => l.id === raw.levelId);
    assert(l && runs.read(l, raw.run), 'invalid daily');
  }
}
console.log('随机探索：种子1/2/3/7各15000步、全场景操作、落盘重载/所有续玩校验/256KB上限通过（宿主，非微信）');
