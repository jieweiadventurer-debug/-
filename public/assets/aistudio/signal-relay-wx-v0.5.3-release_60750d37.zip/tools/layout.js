// 宿主布局回归：多种屏幕下全部关卡的可点击按钮必须留在可视区域。
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '../js');
for (const [width, height, dpr, top] of [
  [320, 568, 2, 20],
  [390, 844, 3, 47],
  [430, 932, 3, 54],
  [768, 1024, 2, 24],
]) {
  Object.keys(require.cache)
    .filter((k) => k.startsWith(root))
    .forEach((k) => delete require.cache[k]);
  const noop = () => {};
  const context = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: width, windowHeight: height, pixelRatio: dpr, safeArea: { top } }),
    getMenuButtonBoundingClientRect: () => ({ top: top + 4, bottom: top + 36, left: width - 96, right: width - 8 }),
    createCanvas: () => ({ getContext: () => context }),
    getStorageSync: () => null,
    setStorageSync: noop,
  };
  const ui = require('../js/engine/ui');
  const original = ui.btn;
  ui.btn = (g, b, u) => {
    assert(b.y >= (top + 48) * dpr, `${width} 顶部按钮侵入胶囊区: ${b.id || b.label}`);
    assert(
      b.x >= 0 && b.y >= 0 && b.x + b.w <= width * dpr + 1 && b.y + b.h <= height * dpr,
      `${width}x${height} 按钮超屏: ${b.id || b.label}`,
    );
    original(g, b, u);
  };
  const sm = require('../js/engine/scene-manager');
  require('../js/scenes/home');
  require('../js/scenes/world');
  require('../js/scenes/levels');
  require('../js/scenes/game');
  require('../js/scenes/rank');
  require('../js/scenes/celebration');
  sm.go('rank');
  sm.frame();
  for (let i = 0; i < 6; i++) {
    sm.go('celebration', i);
    sm.frame();
  }
  const practice = require('../js/core/practice');
  for (const id of Object.keys(practice.examples)) practice.draw(context, practice.create(id));
  sm.go('world');
  sm.frame();
  sm.go('home');
  sm.frame();
  sm.go('levels');
  sm.frame();
  require('../js/data/levels').forEach((l, i) => {
    sm.go('game', i);
    sm.frame();
  });
}
console.log('4 种屏幕 × 60 关按钮边界通过（宿主布局测试）');
