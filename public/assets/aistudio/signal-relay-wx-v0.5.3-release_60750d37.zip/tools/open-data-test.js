const assert = require('node:assert/strict'),
  vm = require('node:vm'),
  fs = require('node:fs'),
  noop = () => {};
let receive,
  request,
  texts = [],
  timers = [];
const ctx = new Proxy({ fillText: (s) => texts.push(s) }, { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) }),
  canvas = { width: 300, height: 300, getContext: () => ctx };
vm.runInNewContext(fs.readFileSync('open-data/index.js', 'utf8'), {
  require: () => require('../open-data/rank-data'),
  setTimeout: (f) => (timers.push(f), timers.length),
  clearTimeout: noop,
  wx: { getSharedCanvas: () => canvas, onMessage: (f) => (receive = f), getFriendCloudStorage: (o) => (request = o) },
});
receive({ type: 'show', width: 300, height: 360 });
assert(texts.includes('正在读取好友成绩…'));
const old = request;
receive({ type: 'hide' });
old.success({ data: [{ nickname: '旧请求不得显示', KVDataList: [] }] });
assert(!texts.includes('旧请求不得显示'));
receive({ type: 'show', width: 300, height: 360 });
request.success({
  data: Array.from({ length: 7 }, (_, i) => ({
    nickname: '玩家' + i,
    KVDataList: [{ key: 'sr_score_v1', value: JSON.stringify({ v: 1, stars: 3 * (i + 1), cleared: i + 1 }) }],
  })),
});
assert(texts.includes('1 / 2'));
receive({ type: 'page', direction: 1 });
assert(texts.includes('2 / 2'));
texts = [];
receive({ type: 'page', direction: 1 });
assert(texts.includes('2 / 2'), '分页不越界');
receive({ type: 'show', width: 300, height: 360 });
request.fail();
assert(texts.includes('暂时无法读取，请刷新重试'));
receive({ type: 'show', width: 300, height: 360 });
timers.at(-1)();
assert(texts.includes('暂时无法读取，请刷新重试'));
console.log('开放域渲染、分页、失败/超时与关闭后迟到响应隔离通过（宿主）');
