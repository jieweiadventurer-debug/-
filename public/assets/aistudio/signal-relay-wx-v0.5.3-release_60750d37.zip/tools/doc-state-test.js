const assert = require('node:assert/strict'),
  fs = require('node:fs'),
  path = require('node:path'),
  crypto = require('node:crypto');
const root = path.resolve(__dirname, '..'),
  state = require('../CURRENT-STATE.json'),
  pkg = require('../package.json');
const count = pkg.scripts.test.split('&&').length;
assert.equal(state.testSuites, count);
assert.equal(state.version, pkg.version);
assert.equal(state.version, require('../js/data/config').VERSION);
assert.equal(state.campaignLevels, require('../js/data/levels').length);
assert.equal(state.dailyPoolLevels, require('../js/data/daily-levels').length);
assert(state.packages.main <= 346304);
assert(state.packages.music <= 100 * 1024);
for (const [file, hash] of Object.entries(state.protectedFiles))
  assert.equal(
    crypto
      .createHash('sha256')
      .update(fs.readFileSync(path.join(root, file)))
      .digest('hex'),
    hash,
    file + ' changed since E',
  );
for (const file of fs.readdirSync(root).filter((f) => f.endsWith('.md'))) {
  const text = fs.readFileSync(path.join(root, file), 'utf8');
  if (file.startsWith('BATCH-')) {
    assert(/当时|当前批次/.test(text), file + ' needs historical/current label');
    continue;
  }
  for (const match of text.matchAll(/(\d+)\s*组(?:宿主|测试|回归)/g)) assert.equal(Number(match[1]), count, file + ' stale test count');
}
const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');
assert(readme.includes('当前状态'));
assert(readme.includes(state.version));
assert(readme.includes(state.testSuites + '组'));
console.log('文档：版本/测试脚本组数/内容数量/正式包预算同步、历史标记及E批关卡/参考解/传播文件哈希不变通过（宿主）');
