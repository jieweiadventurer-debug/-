const assert = require('node:assert/strict'),
  noop = () => {};
let now = 100000,
  serial = 0,
  writes = 0,
  saved = null,
  fail = false;
const timers = new Map(),
  handlers = {};
Date.now = () => now;
global.setTimeout = (fn, delay) => {
  const id = ++serial;
  timers.set(id, { fn, due: now + delay });
  return id;
};
global.clearTimeout = (id) => timers.delete(id);
function advance(ms) {
  now += ms;
  for (const [id, t] of [...timers])
    if (t.due <= now) {
      timers.delete(id);
      t.fn();
    }
}
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getStorageSync: () => saved,
  setStorageSync: (key, value) => {
    writes++;
    if (fail) throw Error('disk full');
    saved = JSON.parse(JSON.stringify(value));
  },
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3, safeArea: { top: 47 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  onTouchStart: (fn) => (handlers.start = fn),
  onTouchEnd: (fn) => (handlers.end = fn),
  onHide: (fn) => (handlers.hide = fn),
};
const store = require('../js/engine/storage'),
  sm = require('../js/engine/scene-manager'),
  runs = require('../js/engine/runs'),
  progress = require('../js/engine/progress'),
  LV = require('../js/data/levels'),
  { parseLevel } = require('../js/core/propagate');
require('../js/engine/input');
require('../js/scenes/game');
for (const id of ['colors', 'bridge', 'stars', 'split', 'range']) store.state.seen['tutorial:' + id] = true;
store.state.seen['chapter:4'] = true;
sm.go('game', 49);
const before = writes,
  { fix } = parseLevel(LV[49]);
let placed = 0;
for (let r = 0; r < fix.length; r++) {
  for (let c = 0; c < fix[r].length; c++) {
    if (fix[r][c]) continue;
    const p = sm.cur().cellXY(r, c);
    sm.cur().onTap(p.x, p.y);
    if (++placed === 20) break;
  }
  if (placed === 20) break;
}
assert.equal(writes, before, '连续20次放置不立即写盘');
advance(999);
assert.equal(writes, before);
advance(1);
assert.equal(writes, before + 1);
assert.equal(saved.runs['5-10'].hist.length, 20);
const p = sm.cur().cellXY(0, 0);
sm.cur().onTap(p.x, p.y);
handlers.hide();
assert.equal(writes, before + 2);
assert.equal(saved.runs['5-10'].hist.length, 21);
assert.deepEqual(saved.runs['5-10'].board, runs.read(LV[49]).board);
store.state.energy = 10;
store.state.coins = 200;
progress.sign();
assert.equal(saved.coins, 300);
progress.buy();
assert.equal(saved.coins, 250);
assert.equal(saved.energy, 15);
progress.spend();
assert.equal(saved.energy, 14);
progress.cleared('1-1', 3, 9, true);
assert.equal(saved.stars['1-1'], 3);
store.state.coins = 777;
store.save();
fail = true;
assert.equal(store.flush(), false);
assert.notEqual(saved.coins, 777);
fail = false;
assert.equal(store.flush(), true);
assert.equal(saved.coins, 777);
const count = writes;
assert.equal(store.flush(), true);
assert.equal(writes, count, '无脏数据不重复写盘');
console.log('20次放置合并写入、后台最新快照、经济即时落盘与失败重试通过（宿主）');
