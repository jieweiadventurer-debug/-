// 信号传播核心（与网页版同一套规则，纯函数，可在 Node 中直接测试）
const DV = { U: [-1, 0], R: [0, 1], D: [1, 0], L: [0, -1] };
const OPP = { U: 'D', R: 'L', D: 'U', L: 'R' };
const ORD = ['U', 'R', 'D', 'L'];
const BASE = { s: ['L', 'R'], c: ['L', 'U'], t: ['L', 'U', 'D'], a: ['L', 'R'] };
const COL = { r: 'red', g: 'green', b: 'blue', y: 'yellow' };
const DIRM = { '>': 'R', '<': 'L', '^': 'U', v: 'D' };
const OB = { TT: 'tree', '##': 'rock', XX: 'box', '~~': 'water' };
const rot = (d, k) => ORD[(ORD.indexOf(d) + k) % 4];
const portsOf = (p) => BASE[p.t].map((d) => rot(d, p.k));

function parseToken(t) {
  if (t === '..') return null;
  if (t === '**') return { k: 'star' };
  if (t === '==') return { k: 'bridge' };
  if (OB[t]) return { k: 'obs', e: OB[t] };
  const ch = t[0];
  return { k: ch === ch.toUpperCase() ? 'src' : 'tgt', d: DIRM[t[1]], col: COL[ch.toLowerCase()] };
}
function parseLevel(level) {
  const fix = level.g.map((r) => r.split(' ').map(parseToken));
  return { R: fix.length, C: fix[0].length, fix };
}
function propagate(R, C, fix, board, range) {
  const lit = new Map(),
    br = new Map(),
    reached = new Set(),
    occ = new Map(),
    bad = new Set(),
    seen = new Map(),
    depth = new Map(),
    bridgeDepth = new Map(),
    targetIssues = new Map(),
    exhausted = new Set(),
    stops = [],
    q = [];
  fix.forEach((row, r) =>
    row.forEach((f, c) => {
      if (f && f.k === 'src') q.push({ r, c, o: f.d, p: range, col: f.col, d: 0 });
    }),
  );
  while (q.length) {
    const { r, c, o, p, col, d } = q.shift();
    const nr = r + DV[o][0],
      nc = c + DV[o][1];
    if (nr < 0 || nc < 0 || nr >= R || nc >= C) {
      stops.push({ kind: 'edge', r, c, col });
      continue;
    }
    const key = nr + ',' + nc,
      sk = key + o + col;
    const strength = p === null ? Infinity : p;
    if (seen.has(sk) && seen.get(sk) >= strength) continue;
    seen.set(sk, strength);
    const mark = () => depth.set(key, Math.min(depth.has(key) ? depth.get(key) : Infinity, d + 1));
    const f = fix[nr][nc],
      pc = board[nr][nc],
      inp = OPP[o];
    if (f && f.k === 'tgt') {
      if (f.d === inp && f.col === col) {
        reached.add(key);
        lit.set(key, col);
        mark();
      } else targetIssues.set(key, { expected: f.col, actual: col, kind: f.col !== col ? 'color' : 'direction' });
      continue;
    }
    if (f && f.k === 'bridge') {
      const ax = o === 'L' || o === 'R' ? 'h' : 'v',
        b = br.get(key) || {};
      if (b[ax] && b[ax] !== col) bad.add(key);
      b[ax] = col;
      br.set(key, b);
      mark();
      const bk = key + ax;
      bridgeDepth.set(bk, Math.min(bridgeDepth.has(bk) ? bridgeDepth.get(bk) : Infinity, d + 1));
      q.push({ r: nr, c: nc, o, p, col, d: d + 1 });
      continue;
    }
    if (!pc) {
      stops.push({ kind: f && f.k !== 'star' ? 'blocked' : 'gap', r: nr, c: nc, col });
      continue;
    }
    const ps = portsOf(pc);
    if (!ps.includes(inp)) {
      stops.push({ kind: 'pipe', r: nr, c: nc, col });
      continue;
    }
    if (p !== null && p <= 0) {
      exhausted.add(key);
      continue;
    }
    if (occ.has(key) && occ.get(key) !== col) bad.add(key);
    occ.set(key, col);
    lit.set(key, col);
    mark();
    const np = pc.t === 'a' ? range : p === null ? null : p - 1;
    ps.forEach((x) => {
      if (x !== inp) q.push({ r: nr, c: nc, o: x, p: np, col, d: d + 1 });
    });
  }
  for (const key of lit.keys()) exhausted.delete(key);
  let tg = 0;
  fix.forEach((row) =>
    row.forEach((f) => {
      if (f && f.k === 'tgt') tg++;
    }),
  );
  return {
    lit,
    br,
    reached,
    bad,
    depth,
    bridgeDepth,
    targetIssues,
    exhausted,
    stops,
    total: tg,
    win: tg > 0 && reached.size === tg && bad.size === 0,
  };
}
// 用「标准解法」验证关卡：solution = [[r,c,type,rot],...]
function simulate(level, solution, opts) {
  const { R, C, fix } = parseLevel(level);
  const board = fix.map((r) => r.map(() => null));
  (solution || []).forEach(([r, c, t, k]) => {
    board[r][c] = { t: opts && opts.noAmp && t === 'a' ? 's' : t, k };
  });
  return propagate(R, C, fix, board, level.range === undefined ? null : level.range).win;
}
module.exports = { parseLevel, propagate, simulate, portsOf, DV, OPP };
