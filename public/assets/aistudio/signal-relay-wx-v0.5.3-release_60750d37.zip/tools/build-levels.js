// 从 tools/levels.json 重新生成 js/data/levels.js及提示参考路线
const fs = require('fs');
const { levels, solutions } = require('./levels.json');
fs.writeFileSync(__dirname + '/../js/data/levels.js', '// 自动生成\nmodule.exports=' + JSON.stringify(levels) + ';\n');
console.log('已生成 ' + levels.length + ' 关');

fs.writeFileSync(
  __dirname + '/../js/data/solutions.js',
  '// 自动生成：渐进提示参考路线\nmodule.exports=' + JSON.stringify(solutions) + ';\n',
);

const daily = require('./daily-levels.json');
fs.writeFileSync(
  __dirname + '/../js/data/daily-levels.js',
  '// Generated offline; no device-side generation.\nmodule.exports=' + JSON.stringify(daily.levels) + ';\n',
);
fs.writeFileSync(
  __dirname + '/../js/data/daily-solutions.js',
  '// Prevalidated daily reference routes.\nmodule.exports=' + JSON.stringify(daily.solutions) + ';\n',
);
fs.writeFileSync(
  __dirname + '/../open-data/content-meta.js',
  '// Generated content limits, shared-domain safe.\nmodule.exports=' + JSON.stringify({ levelCount: levels.length }) + ';\n',
);
