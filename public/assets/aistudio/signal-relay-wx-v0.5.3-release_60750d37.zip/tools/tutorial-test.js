const assert = require('node:assert/strict'),
  LV = require('../js/data/levels'),
  tutorial = require('../js/core/tutorial');
for (const level of LV) {
  const items = tutorial.topics(level);
  assert(items.some((t) => t.id === 'basics'));
  assert.equal(new Set(items.map((t) => t.id)).size, items.length);
  assert(items.every((t) => t.lines.length === 3));
}
assert(!tutorial.topics(LV[0]).some((t) => t.id === 'bridge'));
assert(tutorial.topics(LV.find((l) => l.id === '3-2')).some((t) => t.id === 'bridge'));
assert(tutorial.topics(LV.find((l) => l.id === '2-2')).some((t) => t.id === 'colors'));
const noop = () => {},
  texts = [],
  ctx = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }), fillText: (t) => texts.push(t) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  store = require('../js/engine/storage'),
  runs = require('../js/engine/runs');
require('../js/scenes/game');
let buttons = [];
const original = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  original(g, b, u);
};
function click(id) {
  buttons = [];
  sm.frame();
  const b = buttons.find((b) => b.id === id || b.label === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
store.state.seen['tutorial:colors'] = true;
const i = LV.findIndex((l) => l.id === '3-2');
sm.go('game', i);
sm.frame();
assert(texts.includes('桥让两条信号各走各的'));
const before = runs.read(LV[i]);
const p = sm.cur().cellXY(1, 3);
sm.cur().onTap(p.x, p.y);
assert.deepEqual(runs.read(LV[i]).board, before.board, '教学遮罩阻止棋盘操作');
click('guideNext');
assert(store.state.seen['tutorial:bridge'], '翻页也记录已读主题');
click('继续接力');
assert(store.state.seen['tutorial:bridge']);
sm.go('game', i);
buttons = [];
sm.frame();
assert(!buttons.some((b) => b.id === 'guideClose'), '已读机制不重复弹出');
click('goals');
click('guideTab');
texts.length = 0;
sm.frame();
assert(texts.includes('同色同字母，才是一对'));
click('guidePrev');
texts.length = 0;
sm.frame();
assert(texts.includes('从发射端接到接收端'));
click('guideNext');
click('继续接力');
sm.cur().onTap(p.x, p.y);
assert.equal(runs.read(LV[i]).inv.s, LV[i].inv.s - 1, '关闭教学后操作恢复');
console.log('新机制首次教学、遮罩、已读记忆、分页和手动重看通过（宿主）');
