const assert = require('node:assert/strict'),
  noop = () => {};
let now = new Date(2026, 9, 30, 12).getTime(),
  uploads = 0;
Date.now = () => now;
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
  setUserCloudStorage: () => uploads++,
};
const store = require('../js/engine/storage'),
  S = store.state;
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui');
const daily = require('../js/engine/daily'),
  runs = require('../js/engine/runs');
const LV = require('../js/data/levels'),
  sol = require('../js/data/daily-solutions');
require('../js/scenes/home');
require('../js/scenes/game');
require('../js/scenes/daily');
const social = require('../js/engine/social');
require('../js/engine/progress').sync();
S.settings.reduceMotion = true;
S.settings.sound = false;
S.settings.vibration = false;
S.energy = 0;
S.et = now;
S.coins = 200;
S.ch = 5;
S.socialEnabled = true;
for (const id of ['colors', 'stars', 'bridge', 'split', 'range']) S.seen['tutorial:' + id] = true;
let buttons = [],
  texts = [];
const btn = ui.btn,
  text = ui.text;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
ui.text = (g, s, ...args) => {
  texts.push(s);
  text(g, s, ...args);
};
function frame() {
  buttons = [];
  texts = [];
  sm.frame();
}
function click(id) {
  frame();
  const b = buttons.findLast((b) => b.id === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
sm.go('game', 0);
const p = sm.cur().cellXY(1, 1);
sm.cur().onTap(p.x, p.y);
sm.go('home');
const main = JSON.stringify([S.runs, S.activeRun, S.stars, S.best, S.stat, S.tasks]);
const today = daily.current();
assert.equal(today.day, '2026-10-30');
assert.equal(today.level.id, daily.current().level.id);
sm.go('daily');
click('start');
assert.equal(S.energy, 0);
assert.equal(S.ch, 5);
const first = sol[today.level.id][0];
click('tool:' + first[2]);
let q = sm.cur().cellXY(first[0], first[1]);
sm.cur().onTap(q.x, q.y);
sm.cur().pause();
sm.go('daily');
assert(daily.readRun(today.level, today.day));
click('start');
assert.equal(sm.cur().accessibilityInfo().describe(first[0], first[1]).includes('空地'), true);
// Restore the placed piece to its solution orientation, then complete via source interaction handlers.
for (let k = 0; k < first[3]; k++) sm.cur().onTap(q.x, q.y);
for (const [r, c, t, k] of sol[today.level.id].slice(1)) {
  click('tool:' + t);
  q = sm.cur().cellXY(r, c);
  sm.cur().onTap(q.x, q.y);
  for (let n = 0; n < k; n++) sm.cur().onTap(q.x, q.y);
}
assert(sm.cur().won);
now += 1000;
frame();
assert(texts.some((s) => s.includes('金币 +100')));
assert.equal(S.coins, 300);
assert.equal(S.energy, 0);
assert.equal(S.dailyRun, undefined);
assert.equal(uploads, 0);
assert.equal(JSON.stringify([S.runs, S.activeRun, S.stars, S.best, S.stat, S.tasks]), main);
assert(runs.read(LV[0]));
assert.equal(daily.complete(today.level, today.day, 3, 1), 0);
assert.equal(S.coins, 300);
assert.equal(daily.bestSec(today.day, 99), 0);
assert.equal(daily.complete(today.level, today.day, 9, 1), 0);
S.stars['daily-01'] = 3;
assert.equal(social.score().cleared, 0);
delete S.stars['daily-01'];
click('levels');
assert.equal(S.ch, 5);
click('start');
click('home');
assert.equal(S.ch, 5);
now += 86400000;
const tomorrow = daily.current();
assert.equal(tomorrow.day, '2026-10-31');
assert(!daily.readRun(tomorrow.level, tomorrow.day));
assert.equal(daily.complete(today.level, today.day, 3, 1), 0, '跨日旧题不可领新日奖励');
assert.equal(daily.complete(tomorrow.level, tomorrow.day, 3, 10), 100);
assert.equal(S.coins, 400);
now -= 86400000;
assert(daily.current().blocked);
assert.equal(daily.complete(today.level, today.day, 3, 1), 0);
now += 86400000;
assert.equal(daily.complete(tomorrow.level, tomorrow.day, 3, 10), 0);
console.log('每日挑战：零体力进入、独立续玩/暂停/主线存档保留、交互通关、单日去重、跨日旧题/回拨拒奖、排行榜隔离通过（宿主）');
