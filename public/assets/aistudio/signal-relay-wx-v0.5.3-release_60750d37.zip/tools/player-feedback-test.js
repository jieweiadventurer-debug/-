const assert = require('node:assert/strict'),
  path = require('node:path'),
  noop = () => {},
  root = path.resolve(__dirname, '../js');
for (const [w, h, dpr, top] of [
  [320, 568, 2, 20],
  [390, 844, 3, 47],
  [430, 932, 3, 54],
  [768, 1024, 2, 24],
]) {
  for (const key of Object.keys(require.cache)) if (key.startsWith(root)) delete require.cache[key];
  let destroyed = 0,
    options = [],
    buttons = [];
  const ctx = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: w, windowHeight: h, pixelRatio: dpr, safeArea: { top } }),
    getStorageSync: () => null,
    setStorageSync: noop,
    createCanvas: () => ({ getContext: () => ctx }),
    createFeedbackButton: (o) => {
      options.push(o);
      return { show: noop, destroy: () => destroyed++ };
    },
  };
  const sm = require('../js/engine/scene-manager'),
    store = require('../js/engine/storage'),
    ui = require('../js/engine/ui');
  require('../js/engine/progress').sync();
  require('../js/scenes/settings');
  require('../js/scenes/player-feedback');
  const original = ui.btn;
  ui.btn = (g, b, u) => {
    buttons.push(b);
    return original(g, b, u);
  };
  for (const large of [false, true]) {
    store.state.settings.largeText = large;
    sm.go('player-feedback');
    sm.frame();
    const style = options.at(-1).style;
    assert(style.left >= 0 && style.top >= 0 && style.left + style.width <= w && style.top + style.height <= h);
    assert(style.height >= 44 && style.width >= 44);
    const created = options.length;
    sm.frame();
    assert.equal(options.length, created);
    sm.cur().pause();
    assert(destroyed);
    sm.cur().resume();
    sm.frame();
    assert.equal(options.length, created + 1);
    sm.go('settings');
    assert.equal(destroyed, options.length, 'leave destroys all native overlays');
  }
  store.state.settings.largeText = false;
  delete wx.createFeedbackButton;
  sm.go('player-feedback');
  buttons = [];
  sm.frame();
  const b = buttons.find((b) => b.id === 'feedback');
  sm.cur().onTap(b.x + 1, b.y + 1);
  assert(require('../js/engine/notice').isOpen());
}
console.log('反馈：四屏标准/大字≥44px、原生覆盖层定位/复用/后台/离场销毁、缺接口文字降级通过（宿主，不代表反馈提交）');

// A supported-looking API in devtools is not evidence that its overlay is operable.
for (const key of Object.keys(require.cache)) if (key.startsWith(root)) delete require.cache[key];
let nativeCalls = 0;
wx.getDeviceInfo = () => ({ platform: 'devtools' });
wx.createFeedbackButton = () => {
  nativeCalls++;
  throw Error('must not create simulator overlay');
};
const simulatorFeedback = require('../js/engine/player-feedback');
assert(!simulatorFeedback.available());
simulatorFeedback.sync({ x: 0, y: 0, w: 200, h: 60 });
assert.equal(nativeCalls, 0);
simulatorFeedback.fallback();
assert(require('../js/engine/notice').isOpen());
