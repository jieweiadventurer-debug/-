const assert = require('node:assert/strict'),
  noop = () => {};
Date.now = () => 100000;
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
const sm = require('../js/engine/scene-manager'),
  store = require('../js/engine/storage'),
  runs = require('../js/engine/runs'),
  entry = require('../js/engine/level-entry'),
  notice = require('../js/engine/notice'),
  LV = require('../js/data/levels'),
  { parseLevel } = require('../js/core/propagate');
sm.register('stub', { draw: noop });
sm.go('stub');
require('../js/engine/progress').sync();
function write(i) {
  const l = LV[i],
    { fix } = parseLevel(l);
  runs.write(l, { board: fix.map((row) => row.map(() => null)), inv: { ...l.inv }, hist: [], elapsed: 0, undoUsed: 0 });
}
function choose(label) {
  const b = notice.buttons().find((b) => b.label === label);
  assert(b);
  notice.surface.onTap(b.x + b.w / 2, b.y + b.h / 2);
}
for (let i = 0; i < 5; i++) write(i);
store.state.stars['1-1'] = 3;
store.state.best['1-1'] = { sec: 12 };
store.state.dailyRun = { marker: true };
let started = 0,
  exhausted = 0;
const start = () => {
  started++;
  write(5);
};
const fail = () => exhausted++;
const before = JSON.stringify(store.state),
  energy = store.state.energy;
entry.enter(5, start, fail);
assert(notice.isOpen());
assert.equal(store.state.energy, energy);
choose('保留进度');
assert.equal(started, 0);
assert.equal(JSON.stringify(store.state), before);
entry.enter(5, start, fail);
const stale = notice.buttons().find((b) => b.label === '继续挑战').run;
sm.go('stub');
stale();
assert.equal(started, 0);
assert.equal(store.state.energy, energy);
entry.enter(5, start, fail);
choose('继续挑战');
assert.equal(started, 1);
assert.equal(store.state.energy, energy - 1);
assert.equal(Object.keys(store.state.runs).length, 5);
assert(!store.state.runs['1-1']);
assert.equal(store.state.stars['1-1'], 3);
assert.equal(store.state.best['1-1'].sec, 12);
assert(store.state.dailyRun.marker);
store.state.energy = 0;
entry.enter(5, () => started++, fail);
assert.equal(started, 2);
assert(!notice.isOpen());
entry.enter(6, noop, fail);
assert.equal(exhausted, 1);
assert(!notice.isOpen());
store.state.energy = 10;
entry.enter(6, noop, fail);
store.state.energy = 0;
choose('继续挑战');
assert.equal(exhausted, 2);
assert.equal(store.state.energy, 0);
assert.equal(Object.keys(store.state.runs).length, 5);
console.log('存档预告：第6关取消不扣体力/不删档、确认精确替换/保星级成绩与每日、零体力续玩/再次检查/失效确认保护通过（宿主）');
