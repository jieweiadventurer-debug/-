const assert = require('node:assert/strict');
require.cache[require.resolve('../js/engine/canvas')] = { exports: { DPR: 1 } };
const ui = require('../js/engine/ui');
let calls = 0,
  lines = [];
const width = (s) => Array.from(s).reduce((n, c) => n + (/[0-9]/.test(c) ? 3 : /[a-zA-Z ]/.test(c) ? 6 : 12), 0);
const g = { measureText: (s) => (calls++, { width: width(s) }), fillText: (s) => lines.push(s) };
function check(s, w) {
  lines = [];
  ui.wrapped(g, s, 0, 0, w, 12);
  assert(lines.length <= 2);
  lines.forEach((l) => assert(width(l) <= w, JSON.stringify({ s, w, l })));
  return lines;
}
assert.deepEqual(check('12345678901234567890', 60), ['12345678901234567890']);
check('第12关 Signal接力2026', 80);
const balanced = check('abcdefghijk', 48);
assert.equal(balanced[1].length, 4);
check('1234567890123', 12); // 极窄时优先不溢出，无法容纳四字不强搬
check('中英ABC123', 24);
const before = calls;
check('第12关 Signal接力2026', 80);
assert.equal(calls, before, '同字体与字符串复用测量');
const other = { ...g, measureText: (s) => ({ width: width(s) * 2 }) };
lines = [];
ui.wrapped(other, '1234567890', 0, 0, 30, 12);
assert.equal(lines[0], '12345', '不同画布隔离缓存');
console.log('实测换行：数字/中英混排/窄屏/四字符尾行与字体画布缓存通过（宿主）');
