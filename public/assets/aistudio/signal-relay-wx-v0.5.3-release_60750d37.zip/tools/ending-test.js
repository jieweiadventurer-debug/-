const assert = require('node:assert/strict'),
  noop = () => {},
  texts = [];
let now = 10000;
Date.now = () => now;
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }), fillText: (s) => texts.push(s) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  store = require('../js/engine/storage'),
  LV = require('../js/data/levels'),
  sol = require('../js/data/solutions');
require('../js/scenes/game');
require('../js/scenes/celebration');
require('../js/scenes/levels');
require('../js/scenes/world');
require('../js/scenes/home');
let buttons = [];
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
function frame() {
  buttons = [];
  texts.length = 0;
  sm.frame();
}
function click(id) {
  frame();
  const b = buttons.find((b) => b.id === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
for (const id of ['colors', 'stars', 'bridge', 'split', 'range']) store.state.seen['tutorial:' + id] = true;
for (let chapter = 0; chapter < 6; chapter++) {
  const i = chapter * 10 + 9;
  sm.go('game', i);
  for (const [r, c, t, k] of sol[LV[i].id]) {
    click('tool:' + t);
    const p = sm.cur().cellXY(r, c);
    sm.cur().onTap(p.x, p.y);
    for (let n = 0; n < k; n++) sm.cur().onTap(p.x, p.y);
  }
  assert(sm.cur().won);
  now += 10000;
  click('next');
  frame();
  assert(texts.includes('第 ' + (chapter + 1) + ' 章 · 接力完成'));
  click('levels');
  assert.equal(store.state.ch, chapter);
}
LV.forEach((l) => (store.state.stars[l.id] = 3));
sm.go('celebration', 5);
frame();
assert(texts.includes('全域接通 · 星光相连'));
click('map');
frame();
assert(texts.includes('已接通 60 / 60'));
sm.go('home');
click('设置');
frame();
assert(buttons.some((b) => b.label === '减少动效：关'));
const b = buttons.find((b) => b.label === '减少动效：关');
sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
assert.equal(store.state.settings.reduceMotion, true);
console.log('六章末关结算到修复演出、全关终章、地图/选关返回与减少动效通过（宿主）');
