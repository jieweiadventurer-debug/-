const assert = require('node:assert/strict'),
  noop = () => {};
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
const practice = require('../js/core/practice'),
  store = require('../js/engine/storage'),
  sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  runs = require('../js/engine/runs'),
  LV = require('../js/data/levels');
require('../js/scenes/game');
const before = JSON.stringify(store.state);
for (const id of Object.keys(practice.examples)) {
  const s = practice.create(id),
    p = practice.geometry();
  practice.tap(s, p.x + p.cs * 4.5, p.y + p.cs * 2.5);
  assert.equal(s.step, 0);
  for (const [r, c] of s.example.steps) {
    practice.tap(s, p.x + (c + 0.5) * p.cs, p.y + (r + 0.5) * p.cs);
    practice.draw(ctx, s);
  }
  assert(s.result.win, id + '练习完成必须真实接通');
}
assert.equal(JSON.stringify(store.state), before, '六种练习不修改正式存档');
let buttons = [];
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
function click(id) {
  buttons = [];
  sm.frame();
  const b = buttons.find((b) => b.id === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
sm.go('game', 0);
click('goals');
click('guideTab');
const saved = runs.read(LV[0]);
click('practice');
const p = practice.geometry();
sm.cur().onTap(p.x + 1.5 * p.cs, p.y + 1.5 * p.cs);
assert.deepEqual(runs.read(LV[0]), saved, '练习操作不改本关快照');
click('exitPractice');
click('guideClose');
assert.deepEqual(runs.read(LV[0]), saved);
console.log('六类可操作练习实际接通、错误格不推进、退出与正式关卡隔离通过（宿主）');
