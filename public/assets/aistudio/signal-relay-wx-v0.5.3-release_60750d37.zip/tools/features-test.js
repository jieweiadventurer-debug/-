const assert = require('node:assert/strict');
const { levels } = require('./levels.json');
const { parseLevel, propagate } = require('../js/core/propagate');
const { nextHint, applyHint } = require('../js/core/hints');
const { chapters } = require('../js/core/world');
for (const level of levels) {
  const { R, C, fix } = parseLevel(level),
    board = fix.map((r) => r.map(() => null)),
    inv = { ...level.inv };
  // Start with one genuinely misplaced piece to exercise recovery as well as placement.
  const solution = require('../js/data/solutions')[level.id],
    wanted = new Set(solution.map((p) => p[0] + ',' + p[1]));
  let inserted = false;
  for (let r = 0; r < R && !inserted; r++)
    for (let c = 0; c < C && !inserted; c++)
      if (!fix[r][c] && !wanted.has(r + ',' + c)) {
        const t = Object.keys(inv).find((t) => inv[t] > 0);
        if (t) {
          board[r][c] = { t, k: 1 };
          inv[t]--;
          inserted = true;
        }
      }
  let steps = 0;
  while (!propagate(R, C, fix, board, level.range ?? null).win) {
    const before = JSON.stringify([board, inv]);
    const hint = nextHint(level, board);
    assert(hint, level.id + ' 缺少提示');
    assert.equal(JSON.stringify([board, inv]), before, '仅查看提示不可改棋盘');
    assert(applyHint(board, inv, hint), level.id + ' 提示不可应用');
    assert(Object.values(inv).every((n) => n >= 0));
    assert(++steps < 200, level.id + ' 提示未收敛');
  }
}
let c = chapters({});
assert(c[0].unlocked);
assert(!c[1].unlocked);
assert.equal(c[0].stage, '等待接力');
let stars = {};
for (let i = 1; i <= 5; i++) stars['1-' + i] = 3;
c = chapters(stars);
assert.equal(c[0].stage, '修复中');
assert.equal(c[0].totalStars, 15);
for (let i = 6; i <= 10; i++) stars['1-' + i] = 1;
c = chapters(stars);
assert(c[0].restored);
assert(c[1].unlocked);
assert(!c[2].unlocked);
assert(!applyHint([[null]], { s: 0 }, { r: 0, c: 0, kind: 'place', piece: { t: 's', k: 0 } }));
console.log('60关渐进提示收敛、库存保护、查看不改盘、地图修复/解锁回归通过');
