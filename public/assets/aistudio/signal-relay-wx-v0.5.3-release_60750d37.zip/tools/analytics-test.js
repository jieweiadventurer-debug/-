const assert = require('node:assert/strict');
const noop = () => {},
  reports = [],
  logs = [],
  handlers = {};
let now = 100000,
  applied = 0;
Date.now = () => now;
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3, safeArea: { top: 47 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
  onError: (f) => (handlers.error = f),
  onUnhandledRejection: (f) => (handlers.promise = f),
  shareAppMessage: noop,
  getRealtimeLogManager: () => ({ info: (...a) => logs.push(a), error: (...a) => logs.push(a) }),
};
const st = require('../js/engine/storage'),
  a = require('../js/engine/analytics');
a.init();
assert(!a.track('shop_open'));
st.state.settings = { analytics: true, diagnostics: false };
assert(a.track('shop_open'));
a.flush(); // 缺上报接口
wx.reportEvent = () => {
  throw Error('SDK exception');
};
now += 2000;
a.track('shop_open');
a.flush();
wx.reportEvent = (name, data) => reports.push({ name, data });
now += 2000;
assert(a.track('level_start', { id: '1-1', nickname: 'private', avatarUrl: 'private' }));
assert(!a.track('level_start', { id: '1-1' }));
a.flush();
assert.deepEqual(Object.keys(reports[0].data).sort(), ['id', 'version']);
assert(!a.track('__proto__'));
assert(!a.track('level_start', { id: '999-99' }));
assert.doesNotThrow(() =>
  a.track('level_start', {
    get id() {
      throw Error('getter');
    },
  }),
);
handlers.error('private nickname / absolute file path');
handlers.promise({ reason: 'private' });
a.flush();
assert(!JSON.stringify(reports).includes('private'));
st.state.settings.diagnostics = true;
a.refreshLogger();
now += 2000;
a.track('shop_open');
a.flush();
assert(logs.length);
st.state.settings.analytics = false;
st.state.settings.diagnostics = false;
now += 2000;
const before = reports.length;
assert(!a.track('shop_open'));
a.flush();
assert.equal(reports.length, before);
st.state.settings.analytics = true;
now += 2000;
a.track('shop_open');
st.state.settings.analytics = false;
a.refreshLogger();
st.state.settings.analytics = true;
a.flush();
assert.equal(reports.length, before, '关闭统计时清除待发送队列，重新开启不补发');
// 缺更新接口可启动，再用新的模块验证延后提示与保存后应用。
let updates = require('../js/engine/updates');
assert.doesNotThrow(() => updates.init());
delete require.cache[require.resolve('../js/engine/updates')];
wx.getUpdateManager = () => ({
  onUpdateReady: (f) => (handlers.ready = f),
  onUpdateFailed: (f) => (handlers.failed = f),
  applyUpdate: () => applied++,
});
updates = require('../js/engine/updates');
updates.init();
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  notice = require('../js/engine/notice');
require('../js/scenes/game');
require('../js/scenes/home');
require('../js/scenes/settings');
st.state.settings.analytics = true;
for (const k of ['colors', 'bridge', 'split', 'range', 'stars']) st.state.seen['tutorial:' + k] = true;
for (let i = 0; i < 5; i++) st.state.seen['chapter:' + i] = true;
let buttons = [];
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  return btn(g, b, u);
};
function frame() {
  buttons = [];
  sm.frame();
}
function click(id) {
  frame();
  const b = buttons.find((b) => b.id === id || b.label === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
function drain() {
  for (let i = 0; i < 20; i++) a.flush();
}
now += 2000;
reports.length = 0;
sm.go('game', 0);
handlers.ready();
frame();
assert(!notice.isOpen(), '未通关不能被更新打断');
let g = sm.cur();
let p = g.cellXY(1, 0);
g.onTap(p.x, p.y);
click('hint');
click('再详细一点');
click('应用这一步');
require('../js/engine/wellbeing').show();
now += 10 * 60000;
frame();
let restClose = notice.buttons()[0];
sm.cur().onTap(restClose.x + 1, restClose.y + 1);
[2, 3].forEach((c) => {
  const p = g.cellXY(1, c);
  g.onTap(p.x, p.y);
});
assert(g.won);
now += 1000;
frame();
assert(notice.isOpen(), '结算后允许提示更新');
let b = notice.buttons()[0];
sm.cur().onTap(b.x + 1, b.y + 1);
frame();
assert(!notice.isOpen(), '稍后不能立即再弹');
sm.go('game', 1);
sm.go('home');
frame();
assert(notice.isOpen());
b = notice.buttons()[1];
sm.cur().onTap(b.x + 1, b.y + 1);
assert.equal(applied, 1);
// 保存失败时不得应用更新。
st.save();
wx.setStorageSync = () => {
  throw Error('disk');
};
sm.go('game', 1);
sm.go('home');
frame();
b = notice.buttons()[1];
sm.cur().onTap(b.x + 1, b.y + 1);
assert.equal(applied, 1);
assert(notice.isOpen());
wx.setStorageSync = noop;
notice.close();
st.flush();
handlers.failed();
now += 2000;
sm.go('home');
click('商店');
click('关闭');
// 练习入口、分享和榜单开关按实际处理器触发。
sm.go('game', 0);
click('goals');
click('guideTab');
click('practice');
sm.go('home');
require('../js/engine/social').share();
require('../js/scenes/rank');
sm.go('rank');
click('enable');
b = notice.buttons()[1];
sm.cur().onTap(b.x + 1, b.y + 1);
click('enable');
drain();
for (const name of [
  'level_start',
  'level_win',
  'level_quit',
  'hint_used',
  'inspect_used',
  'practice_enter',
  'shop_open',
  'share',
  'rank_opt',
])
  assert(
    reports.some((r) => r.name === name),
    name,
  );
const win = reports.find((r) => r.name === 'level_win');
assert.deepEqual(win.data, {
  version: require('../js/data/config').VERSION,
  id: '1-1',
  stars: 3,
  sec: 0,
  used: 3,
  par: true,
  undo: 0,
  hints: 1,
});
assert(reports.some((r) => r.name === 'hint_used' && r.data.phase === 1));
assert(reports.some((r) => r.name === 'hint_used' && r.data.phase === 2));
assert(reports.some((r) => r.name === 'rank_opt' && r.data.on === false));
console.log('统计缺接口/异常/去重/白名单/默认关闭、全局错误去敏、交互事件、结算更新与保存失败拦截通过（宿主）');
