// 冒烟测试：用假的 wx 在 Node 里跑通 首页→选关→游戏→通关。node tools/smoke.js
const noop = () => {};
const ctxStub = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  {
    get: (t, k) => (k in t ? t[k] : noop),
    set: (t, k, v) => {
      t[k] = v;
      return true;
    },
  },
);
const store = {},
  handlers = {};
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3, safeArea: { top: 47 } }),
  createCanvas: () => ({ width: 0, height: 0, getContext: () => ctxStub }),
  onTouchStart: (f) => (handlers.start = f),
  onTouchEnd: (f) => (handlers.end = f),
  onTouchCancel: noop,
  getStorageSync: (k) => store[k],
  setStorageSync: (k, v) => (store[k] = v),
};
global.requestAnimationFrame = noop;
const sm = require('../js/engine/scene-manager');
require('../js/engine/input');
require('../js/scenes/home');
require('../js/scenes/levels');
require('../js/scenes/game');
const tap = (x, y) => {
  handlers.start({ touches: [{ clientX: x / 3, clientY: y / 3 }] });
  handlers.end();
};
sm.go('home');
sm.frame();
sm.go('levels');
sm.frame();
sm.go('game', 0);
sm.frame();
const g = sm.cur();
// 1-1：先选直线管，在 (1,1)(1,2)(1,3) 各点一次
[1, 2, 3].forEach((c) => {
  const p = g.cellXY(1, c);
  tap(p.x, p.y);
});
sm.frame();
console.log('1-1 通关:', !!g.won, '星数:', g.won && g.won.n);
// 再挑一个复杂关，渲染一帧确认不报错（含桥、增幅器、分流）
['3-6', '4-3', '5-10'].forEach((id) => {
  const i = require('../js/data/levels').findIndex((l) => l.id === id);
  sm.go('game', i);
  sm.frame();
});
console.log('复杂关渲染正常');
