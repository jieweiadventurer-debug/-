# Adapted construction functions from user-supplied gen-levels.py.
# Legacy Python simulator and all top-level generation/writes intentionally removed.
import random, heapq, json, re
DV = {'U': (-1, 0), 'R': (0, 1), 'D': (1, 0), 'L': (0, -1)}
OPP = {'U': 'D', 'R': 'L', 'D': 'U', 'L': 'R'}
ORD = ['U', 'R', 'D', 'L']
BASE = {'s': ['L', 'R'], 'c': ['L', 'U'], 't': ['L', 'U', 'D'], 'a': ['L', 'R']}
AR = {'R': '>', 'L': '<', 'U': '^', 'D': 'v'}
RA = {v: k for k, v in AR.items()}
rot = lambda d, k: ORD[(ORD.index(d) + k) % 4]
add = lambda c, d: (c[0] + DV[d][0], c[1] + DV[d][1])

def dirof(a, b):
    return [d for d in DV if add(a, d) == b][0]

def route(R, C, s, g, blocked, rng, tp):
    pq = [(0, rng.random(), s, None, [s])]
    best = set()
    while pq:
        c, _, cur, d, path = heapq.heappop(pq)
        if cur == g:
            return path
        if (cur, d) in best:
            continue
        best.add((cur, d))
        for nd in DV:
            n = add(cur, nd)
            if not (0 <= n[0] < R and 0 <= n[1] < C) or n in blocked or n in path:
                continue
            heapq.heappush(pq, (c + 1 + rng.random() + (tp if d and nd != d else 0), rng.random(), n, nd, path + [n]))

def attempt(cfg, rng):
    R, C = (cfg['R'], cfg['C'])
    occ = set()
    tower = {}
    bridges = set()
    chains = []
    ports = {}
    free = lambda c: 0 <= c[0] < R and 0 <= c[1] < C and (c not in occ)
    border = [(r, c) for r in range(R) for c in range(C) if r in (0, R - 1) or c in (0, C - 1)]

    def pick(avoid=()):
        for _ in range(80):
            c = rng.choice(border) if rng.random() < 0.6 else (rng.randrange(R), rng.randrange(C))
            if not free(c) or c in avoid:
                continue
            ds = [d for d in DV if free(add(c, d)) and add(c, d) not in avoid]
            if ds:
                d = rng.choice(ds)
                return (c, d, add(c, d))

    def reg(nodes):
        for a, b in zip(nodes, nodes[1:]):
            d = dirof(a, b)
            if a not in tower and a not in bridges:
                ports.setdefault(a, set()).add(d)
            if b not in tower and b not in bridges:
                ports.setdefault(b, set()).add(OPP[d])
    tp = rng.uniform(0.2, 1.2)
    for i, col in enumerate(cfg['colors']):
        if cfg.get('line') and i == 0:
            if cfg['line'] == 'v':
                c0 = rng.randrange(C)
                s, sd, t, td = ((0, c0), 'D', (R - 1, c0), 'U')
                mid = [(r, c0) for r in range(1, R - 1)]
            else:
                r0 = rng.randrange(R)
                s, sd, t, td = ((r0, 0), 'R', (r0, C - 1), 'L')
                mid = [(r0, c) for c in range(1, C - 1)]
            tower[s] = ('src', col, sd)
            tower[t] = ('tgt', col, td)
            occ |= {s, t, *mid}
            nodes = [s] + mid + [t]
            chains.append((col, nodes))
            reg(nodes)
            continue
        bridging = cfg.get('bridge') and i == 1
        avoid = set()
        if bridging:
            A = chains[0][1]
            cand = [j for j in range(2, len(A) - 2) if A[j] not in bridges and dirof(A[j], A[j + 1]) == OPP[dirof(A[j], A[j - 1])]]
            if not cand:
                return None
            j = rng.choice(cand)
            X = A[j]
            pd = rng.choice([d for d in DV if d not in (dirof(X, A[j - 1]), dirof(X, A[j + 1]))])
            P1, P2 = (add(X, pd), add(X, OPP[pd]))
            if not (free(P1) and free(P2)):
                return None
            avoid = {P1, P2}
        a = pick(avoid)
        if not a:
            return None
        s, sd, sn = a
        occ.add(s)
        b = None
        for _ in range(40):
            b = pick(avoid)
            if b and b[0] != s and (sn != b[2]) and (sn != b[0]) and (b[2] != s) and (abs(s[0] - b[0][0]) + abs(s[1] - b[0][1]) >= cfg['minlen']):
                break
            b = None
        if not b:
            return None
        t, td, tn = b
        occ.add(t)
        tower[s] = ('src', col, sd)
        tower[t] = ('tgt', col, td)
        if bridging:
            s1 = route(R, C, sn, P1, occ | {P2}, rng, tp)
            if not s1:
                return None
            s2 = route(R, C, P2, tn, occ | set(s1), rng, tp)
            if not s2:
                return None
            nodes = [s] + s1 + [X] + s2 + [t]
            occ |= set(s1) | set(s2)
            bridges.add(X)
        else:
            p = route(R, C, sn, tn, occ, rng, tp)
            if not p:
                return None
            nodes = [s] + p + [t]
            occ |= set(p)
        chains.append((col, nodes))
        reg(nodes)
    # A converted crossing is fixed bridge terrain, never a placeable pipe.
    for crossing in bridges:
        ports.pop(crossing, None)
    for _ in range(cfg['tee']):
        opts = [(ci, j, d) for ci, (col, nodes) in enumerate(chains) for j in range(1, len(nodes) - 1) if nodes[j] not in bridges and nodes[j] in ports and (ports[nodes[j]] in ({'L', 'R'}, {'U', 'D'})) for d in DV if d not in ports[nodes[j]] and free(add(nodes[j], d))]
        if not opts:
            return None
        ci, j, d = rng.choice(opts)
        col, nodes = chains[ci]
        cell = nodes[j]
        nb = add(cell, d)
        bt = None
        for _ in range(40):
            bt = pick()
            if bt and bt[0] != nb and (bt[2] != cell):
                break
            bt = None
        if not bt:
            return None
        t, td, tn = bt
        occ.add(t)
        tower[t] = ('tgt', col, td)
        p = route(R, C, nb, tn, occ, rng, tp)
        if not p:
            return None
        occ |= set(p)
        nn = [cell] + p + [t]
        chains.append((col, nn))
        reg(nn)
    types = {c: 't' if len(p) == 3 else 's' if p in ({'L', 'R'}, {'U', 'D'}) else 'c' for c, p in ports.items()}
    if sum((1 for v in types.values() if v == 't')) != cfg['tee'] or sum((1 for v in types.values() if v == 'c')) < cfg['minturns']:
        return None
    rg = cfg['range']
    if rg:
        ok = [True]
        seen = set()

        def walk(cell, indir, pw):
            if (cell, indir) in seen:
                return
            seen.add((cell, indir))
            if pw <= 0:
                ok[0] = False
                return
            if types[cell] == 's' and pw <= 2:
                types[cell] = 'a'
                nx = rg
            else:
                nx = pw - 1
            for d in ports[cell]:
                if d == indir:
                    continue
                n = add(cell, d)
                while n in bridges:
                    n = add(n, d)
                if n in ports:
                    walk(n, OPP[d], nx)
        for c, (k, col, d) in tower.items():
            if k == 'src':
                n = add(c, d)
                if n in ports:
                    walk(n, OPP[d], rg)
        if not ok[0] or 'a' not in types.values():
            return None
    star_cells = rng.sample([c for c in ports], min(cfg['stars'], len(ports)))
    water = cfg['water']
    grid = [['..'] * C for _ in range(R)]
    for c, (k, col, d) in tower.items():
        grid[c[0]][c[1]] = (col.upper() if k == 'src' else col) + AR[d]
    for c in bridges:
        grid[c[0]][c[1]] = '=='
    for c in star_cells:
        grid[c[0]][c[1]] = '**'
    fr = [(r, c) for r in range(R) for c in range(C) if (r, c) not in occ]
    for c in rng.sample(fr, int(len(fr) * cfg['obs'])):
        grid[c[0]][c[1]] = rng.choice(['TT', 'TT', '##', 'XX'] + (['~~', '~~'] if water else []))
    sol = {}
    for c, t in types.items():
        sol[c] = (t, [k for k in range(4) if set((rot(d, k) for d in BASE[t])) == ports[c]][0])
    inv = {k: sum((1 for t, _ in sol.values() if t == k)) for k in 'scta'}
    return dict(g=[' '.join(r) for r in grid], par=len(sol), range=rg, inv=inv, sol=sol)
