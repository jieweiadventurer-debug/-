// 50 关回归：node tools/verify.js
const { levels, solutions } = require('./levels.json');
const { simulate } = require('../js/core/propagate');
let ok = 0,
  bad = [];
levels.forEach((l) => {
  const sol = solutions[l.id];
  const counts = { s: 0, c: 0, t: 0, a: 0 };
  sol.forEach((p) => counts[p[2]]++);
  const invOk = ['s', 'c', 't', 'a'].every((k) => counts[k] === l.inv[k]);
  const solved = simulate(l, sol);
  const emptyFails = !simulate(l, []);
  const ampNeeded = !l.range || !simulate(l, sol, { noAmp: true });
  if (solved && emptyFails && ampNeeded && invOk && sol.length === l.par) ok++;
  else bad.push(l.id);
});
console.log(ok + '/' + levels.length + ' 关通过' + (bad.length ? '，失败：' + bad.join(',') : ''));
process.exit(bad.length ? 1 : 0);
