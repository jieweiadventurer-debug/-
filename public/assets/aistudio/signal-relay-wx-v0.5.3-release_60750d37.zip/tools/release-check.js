const assert = require('node:assert/strict'),
  fs = require('node:fs'),
  path = require('node:path'),
  vm = require('node:vm'),
  CFG = require('../js/data/config');
const root = path.resolve(__dirname, '..'),
  game = JSON.parse(fs.readFileSync(path.join(root, 'game.json'))),
  project = JSON.parse(fs.readFileSync(path.join(root, 'project.config.json')));
assert.equal(project.appid, 'wx82a5467c9bf7901a');
assert.equal(project.compileType, 'game');
assert.equal(CFG.DEV_UNLOCK, false);
assert(fs.existsSync(path.join(root, game.openDataContext, 'index.js')));
for (const file of ['images/share-card.png', 'audio/win.wav', 'audio/place.wav', 'audio/rotate.wav', 'audio/sign.wav', 'audio/reward.wav'])
  assert(fs.statSync(path.join(root, file)).size > 0, file);
function walk(dir) {
  for (const f of fs.readdirSync(dir)) {
    const p = path.join(dir, f);
    if (fs.statSync(p).isDirectory()) walk(p);
    else if (p.endsWith('.js')) new vm.Script(fs.readFileSync(p, 'utf8'), { filename: p });
  }
}
walk(path.join(root, 'js'));
walk(path.join(root, 'open-data'));
console.log('发布静态检查通过：AppID、正式解锁、开放域、素材及JS语法；不代表微信审核或真机验收');
console.log(CFG.REWARDED_AD_UNIT_ID ? '广告位已填写，仍需真实播放验收' : '阻塞项：未配置广告位 ID，真实广告暂不可用');
