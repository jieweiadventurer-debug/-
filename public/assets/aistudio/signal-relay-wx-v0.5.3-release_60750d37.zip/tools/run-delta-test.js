const assert = require('node:assert/strict');
global.wx = { getStorageSync: () => null, setStorageSync: () => {} };
const runs = require('../js/engine/runs'),
  store = require('../js/engine/storage'),
  LV = require('../js/data/levels'),
  { parseLevel } = require('../js/core/propagate');
const clone = (v) => JSON.parse(JSON.stringify(v));
const l = LV[59],
  { fix } = parseLevel(l),
  board = fix.map((row) => row.map(() => null)),
  inv = { ...l.inv };
let legacy = [],
  hist = [],
  seed = 7;
const rng = (n) => (seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) % n;
for (let step = 0; step < 400; step++) {
  const r = rng(8),
    c = rng(8);
  if (fix[r][c] && fix[r][c].k !== 'star') continue;
  const t = Object.keys(inv).find((t) => inv[t] > 0);
  if (!board[r][c] && !t) continue;
  legacy.push(JSON.stringify({ b: board, i: inv }));
  if (legacy.length > 50) legacy.shift();
  const e = runs.capture(board, inv, r, c);
  hist.push(e);
  if (hist.length > 50) hist.shift();
  if (board[r][c]) {
    if (rng(3) === 0) {
      inv[board[r][c].t]++;
      board[r][c] = null;
    } else board[r][c].k = (board[r][c].k + 1) % 4;
  } else {
    board[r][c] = { t, k: 0 };
    inv[t]--;
  }
  runs.seal(e, inv);
}
const data = { board, inv, hist, elapsed: 1234, undoUsed: 0, sel: 's', started: true };
const old = { ...clone(data), version: 1, signature: JSON.stringify(l), hist: legacy };
const fresh = runs.encode(l, data),
  migrated = runs.read(l, old);
assert(migrated);
assert.deepEqual(migrated.board, board);
assert.deepEqual(migrated.inv, inv);
assert.equal(migrated.hist.length, 50);
const b = clone(board),
  i = { ...inv };
for (let n = 49; n >= 0; n--) {
  runs.undo(b, i, migrated.hist[n]);
  const expected = JSON.parse(legacy[n]);
  assert.deepEqual(b, expected.b);
  assert.deepEqual(i, expected.i);
}
const ratio = Buffer.byteLength(JSON.stringify(fresh)) / Buffer.byteLength(JSON.stringify(old));
assert(ratio <= 0.3, 'ratio ' + ratio);
const broken = clone(old);
broken.hist[0] = 'broken';
const rescued = runs.read(l, broken);
assert.deepEqual(rescued.board, board);
assert.equal(rescued.hist.length, 0);
const corrupt = clone(fresh);
corrupt.hist[0].d = { s: 999 };
assert.equal(runs.read(l, corrupt).hist.length, 0);
for (const level of LV.slice(0, 7)) {
  const { fix } = parseLevel(level);
  runs.write(level, { board: fix.map((row) => row.map(() => null)), inv: { ...level.inv }, hist: [], elapsed: 0, undoUsed: 0 });
}
assert.equal(Object.keys(store.state.runs).length, 5);
assert(!store.state.runs[LV[0].id]);
assert(store.state.runs[LV[6].id]);
store.state.dailyRun = { marker: true };
runs.write(LV[2], runs.read(LV[2]));
runs.write(LV[7], { ...runs.read(LV[3]), board: parseLevel(LV[7]).fix.map((row) => row.map(() => null)), inv: { ...LV[7].inv }, hist: [] });
assert(store.state.runs[LV[2].id]);
assert.deepEqual(store.state.dailyRun, { marker: true });
console.log('撤回差分/旧v1迁移与坏历史保盘、50步8×8快照比例 ' + (ratio * 100).toFixed(1) + '%、最近5个/每日隔离通过（宿主）');
