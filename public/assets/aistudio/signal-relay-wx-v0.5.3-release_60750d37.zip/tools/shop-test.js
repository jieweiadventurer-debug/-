const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '../js');
for (const width of [320, 390, 430, 768]) {
  Object.keys(require.cache)
    .filter((k) => k.startsWith(root))
    .forEach((k) => delete require.cache[k]);
  const noop = () => {};
  const ctx = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: width, windowHeight: 844, pixelRatio: 2, safeArea: { top: 47 } }),
    createCanvas: () => ({ getContext: () => ctx }),
    getStorageSync: () => null,
    setStorageSync: noop,
    createRewardedVideoAd: noop,
  };
  const sm = require('../js/engine/scene-manager'),
    ui = require('../js/engine/ui'),
    CFG = require('../js/data/config');
  require('../js/scenes/home');
  let buttons = [];
  ui.btn = (g, b) => buttons.push(b);
  function frame() {
    buttons = [];
    sm.frame();
  }
  function click(label) {
    frame();
    const b = buttons.find((b) => b.label === label);
    assert(b, label);
    sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
    frame();
  }
  const heights = [];
  for (const id of ['', 'adunit-host-test']) {
    CFG.REWARDED_AD_UNIT_ID = id;
    sm.go('home');
    click('商店');
    const video = buttons.filter((b) => String(b.label).includes('视频'));
    assert.equal(video.length, id ? 1 : 0, '未配置隐藏，配置后自动出现');
    assert(!buttons.some((b) => String(b.label).includes('暂未开放')));
    const exchange = buttons.find((b) => b.label === '50 金币兑换 5 体力'),
      close = buttons.find((b) => b.label === '关闭');
    const last = id ? video[0] : exchange;
    assert(close.y >= last.y + last.h + 16 * 2, '按钮与关闭保留间距');
    assert(close.y + close.h <= 844 * 2);
    heights.push(close.y - exchange.y);
  }
  assert.equal(heights[1] - heights[0], 48 * 2, '无广告行自动收拢');
}
console.log('商店配置开关、无广告占位收拢、四种屏宽按钮间距通过（宿主）');
