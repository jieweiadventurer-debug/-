"""Original 8-second chiptune loop; standard-library synthesis, no sampled audio."""
import math, struct, wave, argparse, shutil, subprocess
from pathlib import Path
RATE=16000
MELODY=[72,76,79,81,79,76,74,76,72,67,69,72,74,76,67,71]
ROOTS=[48,45,41,43]
def hz(note): return 440*2**((note-69)/12)
def triangle(phase): return 2/math.pi*math.asin(math.sin(phase))
def envelope(t,length): return max(0,min(1,t/.018,(length-t)/.065))
frames=[]
for i in range(RATE*8):
    t=i/RATE;step=int(t/.5);local=t-step*.5
    lead=triangle(2*math.pi*hz(MELODY[step])*local)*envelope(local,.47)*.12
    bar=int(t/2);bt=t-bar*2
    pad=sum(math.sin(2*math.pi*hz(ROOTS[bar]+n)*bt) for n in [12,16 if bar!=1 else 15,19])/3*envelope(bt,2)*.09
    beat=t%0.5;bass=math.sin(2*math.pi*hz(ROOTS[bar]-12)*beat)*envelope(beat,.40)*.10
    frames.append(struct.pack('<h',int(max(-1,min(1,lead+pad+bass))*32767)))
parser=argparse.ArgumentParser();parser.add_argument('--ffmpeg',default=shutil.which('ffmpeg'));args=parser.parse_args()
if not args.ffmpeg:parser.error('Provide --ffmpeg /path/to/ffmpeg (audio build tool only)')
root=Path(__file__).resolve().parents[1]
output=root/'tools'/'fixtures'/'music-source.wav'
with wave.open(str(output),'wb') as f:
    f.setnchannels(1);f.setsampwidth(2);f.setframerate(RATE);f.writeframes(b''.join(frames))
print(output,output.stat().st_size,'bytes; 8 seconds, 16kHz mono PCM16')

mp3=root/'music'/'relay-loop.mp3'
subprocess.run([args.ffmpeg,'-y','-hide_banner','-loglevel','error','-i',str(output),'-c:a','libmp3lame','-b:a','64k','-write_xing','1',str(mp3)],check=True)
assert mp3.stat().st_size<=100*1024
print(mp3,mp3.stat().st_size,'bytes; MP3 64kbps, with encoder delay metadata; phone loop listening still required')
