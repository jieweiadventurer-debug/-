const assert = require('node:assert/strict');
const old = require('./fixtures/campaign-before-content.json');
const campaign = require('../js/data/levels'),
  solutions = require('../js/data/solutions');
const pool = require('../js/data/daily-levels'),
  dailySolutions = require('../js/data/daily-solutions');
const { validate } = require('./validate-content-candidate');
const { chapters } = require('../js/core/world');
const { nextHint, applyHint } = require('../js/core/hints');
const { parseLevel, propagate } = require('../js/core/propagate');
assert.equal(campaign.length, 60);
assert.equal(pool.length, 30);
assert.equal(JSON.stringify(campaign.slice(0, 50)), JSON.stringify(old.levels), '旧关卡签名必须逐字不变');
for (const l of old.levels) assert.deepEqual(solutions[l.id], old.solutions[l.id]);
assert.equal(new Set([...campaign, ...pool].map((l) => l.id)).size, 90);
const novel = [...campaign.slice(50), ...pool];
assert.equal(new Set(novel.map((l) => JSON.stringify(l.g))).size, 40);
for (const level of novel) {
  const solution = solutions[level.id] || dailySolutions[level.id];
  const result = validate(level, solution);
  assert(result, level.id + ' 未通过正式引擎');
  if (level.id.startsWith('6-')) assert(result.bridgesBoth, level.id + ' 必须双轴过桥');
  const { R, C, fix } = parseLevel(level),
    board = fix.map((row) => row.map(() => null)),
    inv = { ...level.inv };
  let steps = 0;
  while (!propagate(R, C, fix, board, level.range).win) {
    const hint = nextHint(level, board);
    assert(hint && applyHint(board, inv, hint), level.id + ' 提示必须可用');
    assert(++steps < 200);
  }
}
const scores = campaign.slice(50).map((l) => validate(l, solutions[l.id]).score);
assert(scores.every((s, i) => !i || s >= scores[i - 1]));
assert.equal(chapters({}).length, 6);
assert(!chapters({})[5].unlocked);
assert(chapters({ '5-10': 1 })[5].unlocked);
const { rows, KEY } = require('../open-data/rank-data');
const item = (cleared) => ({ nickname: 'test', KVDataList: [{ key: KEY, value: JSON.stringify({ v: 1, cleared, stars: cleared * 3 }) }] });
assert.equal(rows([item(60)]).length, 1);
assert.equal(rows([item(61)]).length, 0);
console.log('内容：旧50关签名/解法不变、新10+30关正式引擎三星/库存/射程/渐进提示、双轴桥、难度排序与60关排行榜边界通过（宿主）');
