const assert = require('node:assert/strict');
const { parseLevel, propagate } = require('../js/core/propagate');
function run(g, solution = []) {
  const l = { g },
    p = parseLevel(l),
    b = p.fix.map((r) => r.map(() => null));
  solution.forEach(([r, c, t, k]) => (b[r][c] = { t, k }));
  return propagate(p.R, p.C, p.fix, b, null);
}
const cross = run(['.. Rv ..', 'B> == b<', '.. r^ ..']);
assert(cross.win);
assert.equal(cross.bad.size, 0);
assert.equal(cross.bridgeDepth.get('1,1h'), 1);
assert.equal(cross.bridgeDepth.get('1,1v'), 1);
const conflict = run(['R> == B<']);
assert(conflict.bad.has('0,1'), '桥上同一通道不同颜色必须冲突');
const route = run(
  ['R> .. .. .. r<'],
  [
    [0, 1, 's', 0],
    [0, 2, 's', 0],
    [0, 3, 's', 0],
  ],
);
assert(route.win);
assert.deepEqual([...route.depth.values()], [1, 2, 3, 4]);
console.log('真实信号距离、桥独立通道与同通道冲突回归通过');

// 用户2-2截图：几何上接通，但两组信号接反，必须给出颜色诊断。
{
  const core = require('../js/core/propagate'),
    level = require('../js/data/levels').find((l) => l.id === '2-2');
  const { R, C, fix } = core.parseLevel(level),
    board = fix.map((row) => row.map(() => null));
  [
    [1, 2, 'c', 1],
    [1, 3, 'c', 0],
    [0, 3, 'c', 2],
    [0, 4, 's', 0],
    [5, 2, 's', 0],
    [5, 1, 'c', 1],
    [4, 1, 's', 1],
    [3, 1, 's', 1],
    [2, 1, 'c', 3],
    [2, 0, 'c', 2],
  ].forEach(([r, c, t, k]) => (board[r][c] = { t, k }));
  const result = core.propagate(R, C, fix, board, null);
  require('node:assert/strict').equal(result.win, false);
  require('node:assert/strict').equal(result.reached.size, 0);
  require('node:assert/strict').deepEqual(result.targetIssues.get('0,5'), { expected: 'red', actual: 'blue', kind: 'color' });
  require('node:assert/strict').deepEqual(result.targetIssues.get('3,0'), { expected: 'blue', actual: 'red', kind: 'color' });
  console.log('用户2-2截图错色连接诊断通过（宿主）');
}

// 射程停止位置、增幅修复和提示优先级。
{
  const { diagnose } = require('../js/core/diagnostics');
  const p = parseLevel({ g: ['R> .. .. .. r<'] });
  const b = [[null, { t: 's', k: 0 }, { t: 's', k: 0 }, { t: 's', k: 0 }, null]];
  let result = propagate(p.R, p.C, p.fix, b, 1);
  assert.deepEqual([...result.exhausted], ['0,2']);
  assert.equal(result.win, false);
  assert.equal(diagnose(result).kind, 'range');
  assert(diagnose(result).message.includes('第1行第3列'));
  b[0][1] = { t: 'a', k: 0 };
  b[0][2] = { t: 'a', k: 0 };
  result = propagate(p.R, p.C, p.fix, b, 1);
  assert(result.win);
  assert.equal(diagnose(result), null);
  const target = parseLevel({ g: ['R> .. r<'] });
  result = propagate(1, 3, target.fix, [[null, { t: 's', k: 0 }, null]], 1);
  assert(result.win, '射程恰好抵达目标可过关');
  assert.equal(diagnose(conflict).kind, 'conflict');
  console.log('射程定位、增幅恢复、临界射程和错误提示优先级通过（宿主）');
}

// 四个接收入口的提示必须与实际判定一致；错色提示给出具体位置。
{
  const { diagnose } = require('../js/core/diagnostics');
  for (const [d, word] of [
    ['U', '上'],
    ['R', '右'],
    ['D', '下'],
    ['L', '左'],
  ]) {
    const fix = [
        [
          { k: 'src', col: 'red', d: 'R' },
          { k: 'tgt', col: 'red', d },
        ],
      ],
      result = propagate(1, 2, fix, [[null, null]], null);
    assert.equal(result.win, d === 'L');
    if (d !== 'L') {
      const problem = diagnose(result, fix);
      assert.equal(problem.kind, 'direction');
      assert(problem.message.includes('第1行第2列'));
      assert(problem.message.includes(word + '侧白箭头'));
    }
  }
  const p = parseLevel({ g: ['B> r<'] }),
    result = propagate(p.R, p.C, p.fix, [[null, null]], null);
  assert.equal(diagnose(result, p.fix).message, '第1行第2列：需要红色，接到了蓝色');
  console.log('接收端四向入口、定位和错色说明通过（宿主）');
}

// 自查使用实际传播停点，不能参考标准解，也不能把支路停点当作通关失败。
{
  const { checkRoute } = require('../js/core/diagnostics');
  function inspect(g, pieces = [], range = null) {
    const p = parseLevel({ g }),
      b = p.fix.map((row) => row.map(() => null));
    pieces.forEach(([r, c, t, k]) => (b[r][c] = { t, k }));
    return checkRoute(propagate(p.R, p.C, p.fix, b, range), p.fix);
  }
  assert.equal(inspect(['R> .. r<']).kind, 'gap');
  assert.deepEqual(inspect(['R> .. r<'], [[0, 1, 's', 1]]).cells, ['0,1']);
  assert.equal(inspect(['R> .. r<'], [[0, 1, 's', 1]]).kind, 'pipe');
  assert.equal(inspect(['R> TT r<']).kind, 'blocked');
  assert.equal(
    inspect(
      ['R> .. ..', 'r> .. ..'],
      [
        [0, 1, 's', 0],
        [0, 2, 's', 0],
      ],
    ).kind,
    'edge',
  );
  assert.equal(inspect(['R> .. r<'], [[0, 1, 's', 0]]).kind, 'complete');
  assert.equal(inspect(['R> .. b<'], [[0, 1, 's', 0]]).kind, 'color');
  assert.equal(
    inspect(
      ['R> .. .. r<'],
      [
        [0, 1, 's', 0],
        [0, 2, 's', 0],
      ],
      1,
    ).kind,
    'range',
  );
  console.log('线路自查空缺、旋转、阻挡、越界与错误优先级通过（宿主）');
}
