"""Offline, deterministic candidates. Formal JS engine is the only acceptance validator.
python3 tools/generate-content.py --out /tmp/relay-content --node /path/to/node
"""
import argparse,json,random,subprocess,shutil
from pathlib import Path
from generator_base import attempt
ROOT=Path(__file__).resolve().parents[1]
def fingerprint(rows):
    grid=[row.split() for row in rows]
    def rotate(g):
        R,C=len(g),len(g[0]);out=[['..']*R for _ in range(C)]
        for r in range(R):
            for c in range(C):
                t=g[r][c]
                if len(t)==2 and t[1] in '^>v<':t=t[0]+{'^':'>','>':'v','v':'<','<':'^'}[t[1]]
                out[c][R-1-r]=t
        return out
    def mirror(g):
        return [[t[0]+{'<':'>','>':'<'}.get(t[1],t[1]) if len(t)==2 and t[1] in '^>v<' else t for t in row[::-1]] for row in g]
    variants=[]
    for start in [grid,mirror(grid)]:
        g=start
        for _ in range(4):
            colors={};value=[]
            for row in g:
                line=[]
                for t in row:
                    if len(t)==2 and t[1] in '^>v<':
                        key=t[0].lower()
                        if key not in colors:colors[key]='rbgy'[len(colors)]
                        color=colors[key];t=(color.upper() if t[0].isupper() else color)+t[1]
                    elif t in ['TT','##','XX','~~']:t='XX'
                    line.append(t)
                value.append(' '.join(line))
            variants.append(json.dumps(value));g=rotate(g)
    return min(variants)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--node',default=shutil.which('node'));args=ap.parse_args()
    if not args.node:ap.error('Node is required; use --node')
    out=Path(args.out).resolve()
    if out==ROOT or ROOT in out.parents:ap.error('Output must be outside the runtime project')
    existing=json.loads((ROOT/'tools/levels.json').read_text())
    used={fingerprint(l['g'])for l in existing['levels'][:50]};chapter=[];daily=[]
    for group,count in [('chapter',10),('daily',30)]:
        for i in range(count):
            if group=='chapter':
                cfg=dict(R=8,C=8,colors=['r','g','b','y'] if i>=8 else ['r','g','b'],tee=2 if i>=3 else 1,bridge=True,range=4 if i not in [0,1,5] else None,stars=3,obs=.26,water=True,tp=0,minlen=4,minturns=4)
            else:
                n=6 if i<10 else 7
                cfg=dict(R=n,C=n,colors=['r'] if i<8 else ['r','g'] if i<22 else ['r','g','b'],tee=1,bridge=i>=10 and i%2==0,range=4 if i%3==2 else None,stars=1+i%3,obs=.22,water=True,tp=0,minlen=3,minturns=1)
            rng=random.Random(20261030+(0 if group=='chapter' else 10000)+i);accepted=None
            for tries in range(18000):
                c=attempt(cfg,rng)
                if not c or c['par']<(22 if group=='chapter' else 7) or (group=='daily' and c['par']>28):continue
                fp=fingerprint(c['g'])
                if fp in used:continue
                level={k:c[k]for k in ['par','range','inv','g']};level['id']='6-1'
                solution=[[r,col,t,k]for (r,col),(t,k)in c['sol'].items()]
                checked=subprocess.run([args.node,str(ROOT/'tools/validate-content-candidate.js')],input=json.dumps(dict(level=level,solution=solution)),text=True,capture_output=True,check=True)
                valid=json.loads(checked.stdout)
                if not valid or (cfg['bridge'] and not valid['bridgesBoth']):continue
                accepted=dict(level=level,solution=solution,score=valid['score']);used.add(fp);break
            if accepted is None:raise RuntimeError((group,i,'candidate limit'))
            (chapter if group=='chapter' else daily).append(accepted)
            print(group,i+1,'tries',tries+1,'pieces',c['par'],'score',valid['score'],flush=True)
    chapter.sort(key=lambda c:c['score']);daily.sort(key=lambda c:c['score'])
    for group,prefix in [(chapter,'6-'),(daily,'daily-')]:
        for i,c in enumerate(group):c['level']['id']=prefix+(str(i+1) if prefix=='6-' else str(i+1).zfill(2))
    out.mkdir(parents=True,exist_ok=True);(out/'content.json').write_text(json.dumps(dict(chapter=chapter,daily=daily),ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
