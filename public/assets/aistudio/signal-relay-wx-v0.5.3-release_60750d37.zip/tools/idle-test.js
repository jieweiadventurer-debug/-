const assert = require('node:assert/strict');
const noop = () => {};
let now = 100000,
  queued,
  paints = 0;
Date.now = () => now;
const ctx = new Proxy(
  { clearRect: () => paints++, createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3 }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
global.requestAnimationFrame = (f) => (queued = f);
const sm = require('../js/engine/scene-manager');
const S = require('../js/engine/progress').sync();
S.settings.reduceMotion = true;
require('../js/scenes/game');
require('../js/scenes/home');
function advance(n, step = 16) {
  for (let i = 0; i < n; i++) {
    now += step;
    queued();
  }
}
sm.go('game', 0);
sm.start();
paints = 0;
advance(60);
assert(paints <= 5, '静止游戏 60 帧不应持续重绘');
sm.invalidate();
advance(1);
assert(paints > 0);
sm.go('home');
advance(1);
paints = 0;
advance(60);
assert.equal(paints, 0, '减少动效首页静止');
S.settings.reduceMotion = false;
advance(1);
paints = 0;
advance(5);
assert.equal(paints, 5, '首页动效逐帧刷新');
let until = now + 80;
sm.register('flow-test', { animating: (t) => t < until, draw: noop });
sm.go('flow-test');
paints = 0;
advance(5);
assert.equal(paints, 5, '流动及最终定格帧');
advance(1);
paints = 0;
advance(60);
assert.equal(paints, 0);
let deadline = now + 1000;
sm.register('deadline-test', { draw: noop, nextFrameAt: () => deadline });
sm.go('deadline-test');
advance(1);
paints = 0;
advance(60);
assert.equal(paints, 0);
advance(4);
assert.equal(paints, 1, '定时状态必须到期刷新');
sm.setActive(false);
sm.invalidate(200);
paints = 0;
advance(5);
assert.equal(paints, 0);
sm.setActive(true);
advance(1);
assert.equal(paints, 1);
S.settings.reduceMotion = true;
S.energy = 0;
S.et = now - 299980;
sm.go('home');
advance(1);
const before = S.energy;
advance(2);
assert.equal(S.energy, before + 1, '静止首页体力到期刷新');
console.log('按需重绘：静止游戏/首页、连续动画、定时唤醒、切后台与体力恢复通过（宿主假 rAF）');
// 满体力首页也需跨日更新；商店自然恢复后文案/按钮不能保留旧状态。
const ui = require('../js/engine/ui');
let buttons = [];
const originalBtn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  originalBtn(g, b, u);
};
function capture() {
  buttons = [];
  sm.frame();
}
S.energy = 29;
S.et = now - 299980;
sm.go('home');
capture();
const shop = buttons.find((b) => b.id === '商店');
sm.cur().onTap(shop.x + shop.w / 2, shop.y + shop.h / 2);
sm.invalidate();
advance(1);
advance(2);
capture();
assert.equal(S.energy, 30);
assert(!buttons.find((b) => b.label === '50 金币兑换 5 体力').primary, '恢复到满体力禁用兑换');
sm.go('home');
advance(1);
const date = new Date(now);
date.setHours(24, 0, 0, 0);
paints = 0;
advance(1, date.getTime() - now + 1);
assert.equal(paints, 1, '静止首页跨日刷新');
