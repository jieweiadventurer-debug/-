const assert = require('node:assert/strict'),
  noop = () => {};
const listeners = {};
const telemetry = [];
let shareCalls = [],
  cloudCalls = [],
  closes = [],
  errors = [],
  showMode = 'ok',
  shows = 0,
  loads = 0;
const ad = {
  onClose: (f) => closes.push(f),
  offClose: noop,
  onError: (f) => errors.push(f),
  offError: noop,
  show: () => {
    shows++;
    return showMode === 'retry' && shows % 2 === 1
      ? Promise.reject(Error('load first'))
      : showMode === 'fail'
        ? Promise.reject(Error('unavailable'))
        : Promise.resolve();
  },
  load: () => {
    loads++;
    return showMode === 'fail' ? Promise.reject(Error('no fill')) : Promise.resolve();
  },
};
global.wx = {
  getStorageSync: () => null,
  setStorageSync: noop,
  reportEvent: (name, data) => telemetry.push({ name, data }),
  createRewardedVideoAd: () => ad,
  shareAppMessage: (o) => shareCalls.push(o),
  showShareMenu: noop,
  onShareAppMessage: (f) => (listeners.share = f),
  getLaunchOptionsSync: () => ({ query: { from: 'share', level: '2-2' } }),
  onShow: (f) => (listeners.show = f),
  setUserCloudStorage: (o) => {
    cloudCalls.push(o);
    o.success();
  },
};
const CFG = require('../js/data/config'),
  store = require('../js/engine/storage'),
  progress = require('../js/engine/progress'),
  ads = require('../js/engine/ads'),
  social = require('../js/engine/social');
const tick = async () => {
  for (let i = 0; i < 12; i++) await Promise.resolve();
};
(async () => {
  progress.sync().settings.analytics = true;
  store.state.energy = 10;
  store.state.et = Date.now();
  assert.equal((await ads.watch()).code, 'unavailable');
  assert.equal(store.state.energy, 10);
  CFG.REWARDED_AD_UNIT_ID = 'adunit-host-test';
  let p = ads.watch();
  await tick();
  assert.equal((await ads.watch()).code, 'busy');
  const oldClose = closes.at(-1);
  oldClose({ isEnded: false });
  assert.equal((await p).code, 'cancelled');
  assert.equal(store.state.energy, 10);
  p = ads.watch();
  await tick();
  oldClose({ isEnded: true });
  assert.equal(store.state.energy, 10, '迟到回调不得奖励下一次请求');
  closes.at(-1)({ isEnded: true });
  assert.equal((await p).gained, 5);
  closes.at(-1)({ isEnded: true });
  assert.equal(store.state.energy, 15, '同次关闭回调不可重复领奖');
  store.state.energy = 28;
  p = ads.watch();
  await tick();
  closes.at(-1)({ isEnded: true });
  assert.equal((await p).gained, 2);
  assert.equal(store.state.energy, 30);
  assert.equal((await ads.watch()).code, 'full');
  store.state.energy = 10;
  showMode = 'fail';
  p = ads.watch();
  await tick();
  assert.equal((await p).code, 'error');
  assert.equal(store.state.energy, 10);
  showMode = 'retry';
  shows = 0;
  p = ads.watch();
  await tick();
  assert(loads > 0);
  closes.at(-1)({ isEnded: true });
  assert.equal((await p).code, 'reward');
  p = ads.watch();
  await tick();
  errors.at(-1)();
  assert.equal((await p).code, 'error');
  p = ads.watch();
  await tick();
  closes.at(-1)(undefined);
  assert.equal((await p).code, 'cancelled', '无完整观看证明不得发奖');
  const analytics = require('../js/engine/analytics');
  for (let i = 0; i < 20; i++) analytics.flush();
  for (const result of ['shown', 'completed', 'cancelled', 'error'])
    assert(
      telemetry.some((e) => e.name === 'ad_result' && e.data.result === result),
      result,
    );
  social.init();
  assert.equal(social.consumeInvite(), '2-2');
  assert.equal(social.consumeInvite(), null);
  social.readInvite({ query: { from: 'share', level: 'bad' } });
  assert.equal(social.consumeInvite(), null);
  assert(social.share('2-2'));
  assert.equal(shareCalls[0].query, 'from=share&level=2-2');
  assert(!('success' in shareCalls[0]), '分享不伪造完成回调或发奖');
  store.state.stars = { '1-1': 3, '1-2': 2 };
  social.upload();
  assert.equal(cloudCalls.length, 0, '不开启榜单不上传成绩');
  store.state.socialEnabled = true;
  social.upload();
  const value = JSON.parse(cloudCalls[0].KVDataList[0].value);
  assert.equal(value.stars, 5);
  assert.equal(value.cleared, 2);
  assert.deepEqual(Object.keys(value).sort(), ['cleared', 'stars', 'updatedAt', 'v']);
  const { rows } = require('../open-data/rank-data'),
    key = social.SCORE_KEY;
  const user = (name, stars, cleared) => ({ nickname: name, KVDataList: [{ key, value: JSON.stringify({ v: 1, stars, cleared }) }] });
  assert.deepEqual(
    rows([user('乙', 5, 2), user('甲', 6, 2), user('坏', 200, 2), { KVDataList: [] }]).map((r) => r.name),
    ['甲', '乙'],
  );
  console.log('广告完成/取消/失败/重试/迟到防重、分享邀请、成绩自愿同步与排行校验通过（宿主模拟API，不是真实微信服务）');
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
