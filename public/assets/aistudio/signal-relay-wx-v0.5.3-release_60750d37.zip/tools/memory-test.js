const assert = require('node:assert/strict'),
  noop = () => {};
let listener,
  subscriptions = 0,
  created = 0,
  destroyed = 0;
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 2, safeArea: { top: 47 } }),
  createCanvas: () => {
    created++;
    return { width: 1, height: 1, getContext: () => ctx };
  },
  getStorageSync: () => null,
  setStorageSync: noop,
  onMemoryWarning: (f) => {
    listener = f;
    subscriptions++;
  },
  loadSubpackage: (o) => o.success(),
  createInnerAudioContext: () => ({ play: noop, pause: noop, destroy: () => destroyed++, onError: noop }),
};
const sm = require('../js/engine/scene-manager'),
  sprites = require('../js/data/sprites'),
  store = require('../js/engine/storage'),
  music = require('../js/engine/music'),
  memory = require('../js/engine/memory'),
  analytics = require('../js/engine/analytics');
require('../js/engine/progress').sync();
require('../js/scenes/home');
require('../js/scenes/game');
memory.init();
memory.init();
assert.equal(subscriptions, 1);
music.setEnabled(true);
sm.go('home');
sm.frame();
assert(sprites.cacheSize() > 0);
const n = created;
listener({ level: 10 });
assert.equal(sprites.cacheSize(), 0);
assert.equal(destroyed, 1);
assert(music.enabled());
assert.equal(music.status(), '已暂停');
sm.frame();
assert(created > n);
assert(sprites.cacheSize() > 0);
music.setEnabled(true);
assert.equal(music.status(), '播放中');
listener({ level: 15 });
assert.equal(sprites.cacheSize(), 0);
assert.equal(destroyed, 2);
store.state.settings.largeText = true;
sm.go('game', 0);
sm.frame();
listener();
assert.doesNotThrow(() => sm.frame());
let reports = 0;
const old = analytics.track;
analytics.track = (name) => {
  assert.equal(name, 'memory_warning');
  reports++;
};
listener();
assert.equal(reports, 0);
store.state.settings.analytics = true;
listener();
listener();
assert.equal(reports, 1);
analytics.track = old;
console.log('内存警告：一次监听、精灵/离屏缓存释放后重绘、音乐销毁保开关并可重播、匿名统计一次通过（宿主模拟事件）');

let pending;
wx.loadSubpackage = (o) => {
  pending = o;
};
// A fresh module starts with an unloaded subpackage.
delete require.cache[require.resolve('../js/engine/music')];
const late = require('../js/engine/music');
late.setEnabled(true);
late.release();
pending.success();
assert.equal(late.status(), '已暂停');
late.setEnabled(true);
assert.equal(late.status(), '播放中');
