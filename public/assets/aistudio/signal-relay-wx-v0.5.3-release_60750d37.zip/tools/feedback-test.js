const assert = require('node:assert/strict'),
  noop = () => {};
const voices = [];
let writes = 0,
  vibrations = 0,
  broken = false;
global.wx = {
  getStorageSync: () => null,
  setStorageSync: noop,
  vibrateShort: () => vibrations++,
  createInnerAudioContext: () => {
    if (broken) throw Error('unsupported');
    const v = {
      played: 0,
      sought: 0,
      stop() {
        throw Error('stop must not be used');
      },
      seek(n) {
        assert.equal(n, 0);
        this.sought++;
      },
      play() {
        this.played++;
      },
      onError(fn) {
        this.error = fn;
      },
      set src(value) {
        writes++;
        this.source = value;
      },
    };
    voices.push(v);
    return v;
  },
};
const store = require('../js/engine/storage'),
  progress = require('../js/engine/progress'),
  feedback = require('../js/engine/feedback');
progress.sync();
for (let i = 0; i < 5; i++) feedback.play('place');
assert.equal(voices.length, 2);
assert.equal(writes, 2);
assert.deepEqual(
  voices.map((v) => v.played),
  [3, 2],
);
assert.equal(
  voices.reduce((n, v) => n + v.sought, 0),
  5,
);
assert.equal(vibrations, 5);
store.state.settings.sound = false;
feedback.play('place');
feedback.play('new-sound');
assert.equal(writes, 2);
assert.equal(
  voices.reduce((n, v) => n + v.played, 0),
  5,
);
assert.equal(vibrations, 7, '静音不自动关闭震动');
store.state.settings.sound = true;
store.state.settings.vibration = false;
feedback.play('place');
assert.equal(vibrations, 7);
assert.equal(writes, 2);
voices.forEach((v) => v.error());
feedback.play('place');
assert.equal(
  voices.reduce((n, v) => n + v.played, 0),
  6,
  '损坏实例静默降级',
);
broken = true;
assert.doesNotThrow(() => feedback.play('broken'));
assert.doesNotThrow(() => feedback.play('broken'));
console.log('双音效实例轮换、src仅赋值两次、静音/震动独立控制与错误降级通过（宿主）');
