const assert = require('node:assert/strict');
const events = require('../js/engine/events');
let seen = [];
const off = events.on('probe', (v) => seen.push(v));
events.emit('probe', 1);
off();
off();
events.emit('probe', 2);
assert.deepEqual(seen, [1]);
const warn = console.warn;
console.warn = () => {};
const bad = events.on('probe', () => {
  throw Error('listener');
});
events.on('probe', (v) => seen.push(v));
events.emit('probe', 3);
bad();
console.warn = warn;
assert.deepEqual(seen, [1, 3]);
let uploads = 0;
global.wx = {
  getStorageSync: () => null,
  setStorageSync: () => {},
  setUserCloudStorage: (o) => {
    uploads++;
    o.success();
  },
};
const store = require('../js/engine/storage'),
  progress = require('../js/engine/progress');
require('../js/engine/social');
progress.cleared('1-1', 3, 10, true);
assert.equal(uploads, 0, '未开启同步不上传');
store.state.socialEnabled = true;
progress.cleared('1-2', 2, 20, false);
assert.equal(uploads, 1);
assert.equal(store.state.stars['1-2'], 2);
console.log('事件订阅/退订/异常隔离、通关奖励与自愿成绩同步通过（宿主）');
