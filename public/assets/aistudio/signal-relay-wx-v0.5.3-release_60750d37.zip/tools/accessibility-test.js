const assert = require('node:assert/strict'),
  path = require('node:path');
const root = path.resolve(__dirname, '../js');
let now = 100000;
Date.now = () => now;
for (const [width, height, dpr, top] of [
  [320, 568, 2, 20],
  [390, 844, 3, 47],
  [430, 932, 3, 54],
  [768, 1024, 2, 24],
]) {
  Object.keys(require.cache)
    .filter((k) => k.startsWith(root))
    .forEach((k) => delete require.cache[k]);
  const handlers = {},
    noop = () => {};
  let first = true,
    main;
  const contexts = [];
  global.wx = {
    getSystemInfoSync: () => ({ windowWidth: width, windowHeight: height, pixelRatio: dpr, safeArea: { top } }),
    getAppBaseInfo: () => ({ fontSizeSetting: 24 }),
    createCanvas: () => {
      const g = new Proxy(
        { createLinearGradient: () => ({ addColorStop: noop }) },
        { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
      );
      contexts.push(g);
      if (first) {
        main = g;
        first = false;
      }
      return { getContext: () => g };
    },
    onTouchStart: noop,
    onTouchEnd: noop,
    onHide: (f) => (handlers.hide = f),
    onShow: (f) => (handlers.show = f),
    getStorageSync: () => null,
    setStorageSync: noop,
  };
  const sm = require('../js/engine/scene-manager'),
    ui = require('../js/engine/ui'),
    prefs = require('../js/engine/accessibility-preferences'),
    access = require('../js/engine/accessibility'),
    store = require('../js/engine/storage'),
    notice = require('../js/engine/notice');
  require('../js/engine/input');
  assert(prefs.enabled(), '系统大字体作为默认参考');
  prefs.set('largeText', false);
  assert(!prefs.enabled(), '明确选择覆盖系统参考');
  prefs.set('largeText', true);
  const S = require('../js/engine/progress').sync();
  S.settings.reduceMotion = true;
  for (const t of ['colors', 'bridge', 'split', 'range', 'stars']) S.seen['tutorial:' + t] = true;
  for (let i = 0; i < 6; i++) S.seen['chapter:' + i] = true;
  for (const scene of ['home', 'settings', 'levels', 'world', 'game', 'rank', 'celebration']) require('../js/scenes/' + scene);
  const original = ui.btn;
  ui.btn = (g, b, u) => {
    if (g === main && prefs.enabled()) {
      assert(b.w / dpr >= 44 && b.h / dpr >= 44, b.label || b.id);
      assert(b.x >= 0 && b.y >= top * dpr && b.x + b.w <= width * dpr + 1 && b.y + b.h <= height * dpr, b.label);
    }
    original(g, b, u);
  };
  function frame() {
    sm.frame();
    const source = sm.cur().source;
    if (!source) return;
    const buttons = access.buttons(source);
    for (let i = 0; i < buttons.length; i++)
      for (let j = i + 1; j < buttons.length; j++) {
        const a = buttons[i],
          b = buttons[j];
        assert(!(a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y), '大按钮不重叠');
      }
  }
  function click(label) {
    for (let i = 0; i < 30; i++) {
      frame();
      const source = sm.cur().source,
        buttons = source ? access.buttons(source) : notice.buttons();
      const b = buttons.find((b) => b.label === label || b.label.startsWith(label));
      if (b) {
        sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
        frame();
        return;
      }
      const next = buttons.find((b) => b.label === '下页');
      assert(next, label);
      sm.cur().onTap(next.x + 1, next.y + 1);
    }
    throw Error(label);
  }
  for (const high of [false, true]) {
    prefs.set('highContrast', high);
    for (let i = 0; i < 60; i++) {
      sm.go('game', i);
      frame();
    }
    for (const scene of ['home', 'settings', 'levels', 'world', 'rank', 'celebration']) {
      sm.go(scene, 0);
      frame();
    }
  }
  sm.go('game', 0);
  frame();
  const source = sm.cur().source;
  click('逐格操作');
  const firstButton = access.buttons(source)[0],
    originalFill = main.fillText,
    ys = [];
  main.fillText = (text, x, y) => {
    if (text === firstButton.label) ys.push(y);
  };
  ui.touchAt(null);
  frame();
  ui.touchAt({ x: firstButton.x + 1, y: firstButton.y + 1 });
  frame();
  ui.touchAt(null);
  main.fillText = originalFill;
  assert.equal(ys[1] - ys[0], Math.max(2, Math.round(2 * dpr)), '按压文字与按钮同移');
  click('下一行');
  click('下一列');
  click('放置/旋转');
  handlers.hide();
  now += 60000;
  handlers.show();
  click('下一列');
  click('放置/旋转');
  click('下一列');
  click('放置/旋转');
  assert(source.won, '等效大按钮路线应能三星通关');
  assert.equal(source.won.sec, 0, '大字模式后台时间不计入关卡');
  assert(source.accessibilityInfo().summary[0].includes('★★★'), '结算使用大字摘要，不裁切棋盘');
  now += 300;
  frame();
  assert(!access.buttons(source).some((b) => b.label === '上页' || b.label === '下页'), '单页结算不显示无效翻页');
  click('再挑战');
  frame();
  click('三星目标');
  click('玩法说明');
  click('动手练习');
  click('按提示完成练习一步');
  click('退出练习');
  notice.open({ title: '测试说明', lines: ['第一行正文', '第二行正文', '第三行正文', '第四行正文', '第五行正文', '第六行正文'] });
  frame();
  click('下一段');
  click('知道了');
  sm.go('settings');
  frame();
  click('返回标准布局');
  assert(!prefs.enabled());
}
// 高对比文字配色至少保持原有对比。
const store = require('../js/engine/storage'),
  prefs = require('../js/engine/accessibility-preferences');
store.state.settings.highContrast = true;
const lum = (s) =>
  s
    .match(/[a-f\d]{2}/gi)
    .map((x) => parseInt(x, 16) / 255)
    .map((x) => (x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4))
    .reduce((a, v, i) => a + v * [0.2126, 0.7152, 0.0722][i], 0);
const ratio = (a, b) => (Math.max(lum(a), lum(b)) + 0.05) / (Math.min(lum(a), lum(b)) + 0.05);
for (const [fg, bg] of [
  ['#f4f4f4', '#333c57'],
  ['#94b0c2', '#333c57'],
  ['#b5c9d6', '#333c57'],
  ['#1a1c2c', '#ffcd75'],
  ['#73464c', '#ffcd75'],
])
  assert(ratio(prefs.color(fg), prefs.color(bg)) >= ratio(fg, bg));
const CFG = require('../js/data/config'),
  DV = require('../js/core/propagate').DV,
  renderer = require('../js/scenes/game/board-render');
const patterns = [];
for (const color of Object.values(CFG.COLORS)) {
  const rects = [],
    g = { fillRect: (...a) => rects.push(a) };
  renderer({ state: { u: 2 }, CFG, DV }).pipe(g, 0, 0, ['L', 'R'], color);
  patterns.push(JSON.stringify(rects));
}
assert.equal(new Set(patterns).size, 4, '四种信号有不同纹理');
console.log('大字等效操作：四屏×60关×高对比开关、44px目标无重叠、放置通关/练习/分页/退出、系统字号与颜色纹理通过（宿主）；不代表读屏支持');
