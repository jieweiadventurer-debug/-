const assert = require('node:assert/strict');
let timer,
  handlers = {},
  taps = 0,
  longs = 0;
const oldSet = setTimeout,
  oldClear = clearTimeout;
global.setTimeout = (f) => ((timer = f), 1);
global.clearTimeout = () => {
  timer = null;
};
const scene = {
  onTap: () => taps++,
  onLong: () => {
    longs++;
    return false;
  },
};
require.cache[require.resolve('../js/engine/canvas')] = { exports: { DPR: 3 } };
require.cache[require.resolve('../js/engine/scene-manager')] = { exports: { cur: () => scene, invalidate: () => {}, setActive: () => {} } };
global.wx = {
  onTouchStart: (f) => (handlers.start = f),
  onTouchEnd: (f) => (handlers.end = f),
  onTouchMove: (f) => (handlers.move = f),
  onTouchCancel: (f) => (handlers.cancel = f),
  onHide: (f) => (handlers.hide = f),
};
require('../js/engine/input');
const event = (x = 10, y = 10) => ({ touches: [{ clientX: x, clientY: y }] });
handlers.start(event());
handlers.end();
assert.equal(taps, 1);
handlers.start(event());
handlers.move(event(40));
handlers.end();
assert.equal(taps, 1);
handlers.start(event());
handlers.cancel();
handlers.end();
assert.equal(taps, 1);
handlers.start(event());
timer();
handlers.end();
assert.equal(longs, 1);
assert.equal(taps, 2, '未处理的长按应保留按钮点击');
scene.onLong = () => true;
handlers.start(event());
timer();
handlers.end();
assert.equal(taps, 2, '有效长按不应再触发点击');
handlers.start(event());
handlers.hide();
handlers.end();
assert.equal(taps, 2);
global.setTimeout = oldSet;
global.clearTimeout = oldClear;
console.log('短按、移动取消、长按、触摸取消与切后台输入回归通过');

// Actual SDK event shape captured in the developer tool: fractional logical coordinates,
// and an empty touches array on release. Do not multiply by screen scale twice.
let actualPoint;
scene.onTap = (x, y) => {
  actualPoint = { x, y };
};
scene.onLong = () => false;
handlers.start({ touches: [{ identifier: 0, clientX: 371.546875, clientY: 735.7109375 }] });
handlers.end({ touches: [], changedTouches: [{ identifier: 0, clientX: 371.546875, clientY: 735.7109375 }] });
assert.deepEqual(actualPoint, { x: 1114.640625, y: 2207.1328125 });
console.log('真实SDK事件形状：小数逻辑坐标×DPR一次、空touches抬起仍正确点击通过（宿主复现，不是真机）');
