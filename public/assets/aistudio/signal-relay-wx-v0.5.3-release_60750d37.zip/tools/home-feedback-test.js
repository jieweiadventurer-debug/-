const assert = require('node:assert/strict'),
  noop = () => {},
  texts = [],
  played = [];
let vibration = 0,
  now = new Date(2026, 9, 30, 12).getTime();
Date.now = () => now;
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }), fillText: (s) => texts.push(s) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
  vibrateShort: () => vibration++,
  createInnerAudioContext: () => ({
    stop: noop,
    play() {
      played.push(this.src);
    },
  }),
};
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  store = require('../js/engine/storage'),
  hud = require('../js/engine/hud');
require('../js/scenes/home');
let rank = false;
sm.register('rank', { enter: () => (rank = true), draw: noop });
let buttons = [];
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
function frame() {
  texts.length = 0;
  buttons = [];
  sm.frame();
}
function click(id) {
  frame();
  const b = buttons.find((b) => b.id === id || b.label === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
sm.go('home');
const S = store.state,
  coins = S.coins;
click('签到');
frame();
assert(texts.includes('签到成功'));
assert(texts.includes('+100 金币'));
assert.equal(S.coins, coins + 100);
assert.deepEqual(played, ['audio/sign.wav']);
assert.equal(vibration, 1);
click('关闭');
frame();
assert(buttons.some((b) => b.id === '签到' && b.label === '已签到'));
click('签到');
frame();
assert(texts.includes('今日已签到'));
assert.equal(S.coins, coins + 100);
assert.equal(played.length, 1);
assert.equal(vibration, 1);
click('关闭');
S.settings.sound = false;
S.settings.vibration = false;
now += 86400000;
click('签到');
assert.equal(S.coins, coins + 200);
assert.equal(played.length, 1);
assert.equal(vibration, 1);
click('关闭');
click('hud:energy');
frame();
assert(texts.includes('体力商店'));
click('关闭');
click('hud:coins');
frame();
assert(texts.includes('体力商店'));
click('关闭');
assert.equal(hud.compact(9999), '9999');
assert.equal(hud.compact(123456), '12.3万');
assert.equal(hud.compact(123456789), '1.2亿');
S.coins = 123456;
frame();
assert(texts.includes('12.3万'));
click('hud:rank');
assert(rank, '等级卡保留好友榜入口');
console.log('签到音效/去重/静音/震动设置、奖励弹窗、资源图标入口与大数显示通过（宿主）');
// 回拨拦截不得显示奖励成功或播放领取音效。
sm.go('home');
now -= 86400000;
const rollbackCoins = S.coins,
  rollbackAudio = played.length;
click('签到');
frame();
assert(texts.includes('时间校验'));
assert(!texts.includes('+100 金币'));
assert.equal(S.coins, rollbackCoins);
assert.equal(played.length, rollbackAudio);
