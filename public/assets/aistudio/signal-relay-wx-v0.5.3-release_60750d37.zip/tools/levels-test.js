const assert = require('node:assert/strict'),
  noop = () => {},
  texts = [];
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }), fillText: (t) => texts.push(t) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
const ui = require('../js/engine/ui'),
  sm = require('../js/engine/scene-manager'),
  store = require('../js/engine/storage'),
  runs = require('../js/engine/runs'),
  LV = require('../js/data/levels'),
  { parseLevel } = require('../js/core/propagate');
let buttons = [],
  entered = null;
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
require('../js/scenes/levels');
sm.register('game', { enter: (arg) => (entered = arg), draw: noop });
function frame() {
  buttons = [];
  texts.length = 0;
  sm.frame();
}
function click(id) {
  frame();
  const b = buttons.find((b) => b.id === id);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
  frame();
}
const S = store.state;
S.ch = 0;
S.stars = { '1-1': 2, '1-2': 3 };
S.best = { '1-1': { sec: 125 } };
const { fix } = parseLevel(LV[2]);
runs.write(LV[2], {
  board: fix.map((row) => row.map(() => null)),
  inv: { ...LV[2].inv },
  hist: [],
  undoUsed: 0,
  sel: 's',
  elapsed: 0,
  started: false,
});
S.energy = 0;
S.et = Date.now();
sm.go('levels');
frame();
assert(texts.includes('最佳 02:05'));
assert(texts.includes('已通关'), '旧存档有星级但缺用时，应显示已通关');
assert(texts.includes('通关上一关解锁'));
assert(texts.includes('续玩 · 不耗体力'));
const original = JSON.stringify({ stars: S.stars, best: S.best, energy: S.energy, runs: S.runs });
click('filter:stars');
assert.deepEqual(
  buttons.filter((b) => b.id.startsWith('lv:')).map((b) => b.id),
  ['lv:0'],
);
assert(buttons.some((b) => b.label === '补星 1'));
assert.equal(JSON.stringify({ stars: S.stars, best: S.best, energy: S.energy, runs: S.runs }), original, '筛选不修改进度和经济数据');
click('filter:resume');
assert.deepEqual(
  buttons.filter((b) => b.id.startsWith('lv:')).map((b) => b.id),
  ['lv:2'],
);
click('ch:1');
assert(texts.includes('本章没有未完成的存档'));
assert(!buttons.some((b) => b.id.startsWith('lv:')));
click('filter:stars');
assert(texts.includes('本章暂无需要补星的已通关关卡'));
click('filter:all');
assert.equal(buttons.filter((b) => b.id.startsWith('lv:')).length, 10);
click('lv:10');
assert.equal(entered, null, '筛选不能绕过解锁');
click('ch:0');
click('filter:resume');
click('lv:2');
assert.deepEqual(entered, { index: 2, resume: true });
assert.equal(S.energy, 0, '零体力续玩不扣体力');
console.log('选关补星/续玩筛选、空状态、成绩显示、锁定与零体力恢复通过（宿主）');
