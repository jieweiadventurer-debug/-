// Host baseline only. This does not measure device frame rate, battery or memory.
const { performance } = require('node:perf_hooks'),
  { parseLevel, propagate } = require('../js/core/propagate'),
  LV = require('../js/data/levels'),
  solutions = require('../js/data/solutions');
const values = [];
for (const level of LV) {
  const { R, C, fix } = parseLevel(level),
    board = fix.map((row) => row.map(() => null));
  for (const [r, c, t, k] of solutions[level.id]) board[r][c] = { t, k };
  for (let i = 0; i < 10; i++) propagate(R, C, fix, board, level.range);
  const start = performance.now();
  for (let i = 0; i < 100; i++) propagate(R, C, fix, board, level.range);
  values.push({ id: level.id, ms: (performance.now() - start) / 100 });
}
values.sort((a, b) => a.ms - b.ms);
console.log(
  JSON.stringify(
    {
      environment: 'Node host, not WeChat or iPhone',
      levels: 50,
      iterationsPerLevel: 100,
      medianMs: values[25].ms,
      p95Ms: values[47].ms,
      slowest: values[49],
    },
    null,
    2,
  ),
);
