// Static palette check only, not a WCAG conformance audit of the Canvas game.
const assert = require('node:assert/strict');
function lum(hex) {
  const values = hex
    .match(/[a-f\d]{2}/gi)
    .map((v) => parseInt(v, 16) / 255)
    .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return values[0] * 0.2126 + values[1] * 0.7152 + values[2] * 0.0722;
}
const pairs = [
  ['正文', '#f4f4f4', '#333c57'],
  ['次要说明', '#b5c9d6', '#333c57'],
  ['辅助说明', '#94b0c2', '#333c57'],
  ['主按钮', '#1a1c2c', '#ffcd75'],
  ['选中管件', '#1a1c2c', '#ffcd75'],
];
for (const [label, a, b] of pairs) {
  const ratio = (Math.max(lum(a), lum(b)) + 0.05) / (Math.min(lum(a), lum(b)) + 0.05);
  assert(ratio >= 4.5, label);
  console.log(label + ': ' + ratio.toFixed(2) + ':1');
}
console.log('静态主要文字配色对比通过；不覆盖透明叠加、读屏语义、焦点及全部像素');
