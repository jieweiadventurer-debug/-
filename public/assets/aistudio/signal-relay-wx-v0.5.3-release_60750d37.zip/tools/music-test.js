const assert = require('node:assert/strict'),
  fs = require('node:fs');
const callbacks = {},
  notices = [];
let loaded,
  loads = 0,
  plays = 0,
  pauses = 0,
  created = 0,
  onError;
global.wx = {
  getStorageSync: () => null,
  setStorageSync: () => {},
  loadSubpackage: (o) => {
    loads++;
    loaded = o;
  },
  createInnerAudioContext: () => {
    created++;
    return { play: () => plays++, pause: () => pauses++, onError: (f) => (onError = f), destroy: () => {} };
  },
  onHide: (f) => (callbacks.hide = f),
  onShow: (f) => (callbacks.show = f),
  onAudioInterruptionBegin: (f) => (callbacks.interrupt = f),
  onAudioInterruptionEnd: (f) => (callbacks.resume = f),
};
const store = require('../js/engine/storage'),
  music = require('../js/engine/music');
require('../js/engine/events').on('notice', (v) => notices.push(v));
music.init();
assert.equal(loads, 0);
assert.equal(created, 0);
store.state.settings = { sound: false };
music.setEnabled(true);
assert.equal(loads, 1);
assert.equal(plays, 0);
music.setEnabled(false);
loaded.success();
assert.equal(plays, 0, '下载后已关闭不播放');
music.setEnabled(true);
assert.equal(created, 1);
assert.equal(plays, 1, '音效关闭不影响独立音乐');
callbacks.hide();
assert(pauses);
callbacks.show();
assert.equal(plays, 2);
assert.equal(created, 1);
callbacks.interrupt();
callbacks.hide();
callbacks.resume();
assert.equal(plays, 2);
callbacks.show();
assert.equal(plays, 3);
music.setEnabled(false);
callbacks.show();
assert.equal(plays, 3);
music.setEnabled(true);
onError();
assert(!music.enabled());
assert(notices.length);
delete wx.createInnerAudioContext;
music.setEnabled(true);
assert(!music.enabled());
const wav = fs.readFileSync(require('node:path').join(__dirname, './fixtures/music-source.wav'));
assert.equal(wav.toString('ascii', 0, 4), 'RIFF');
assert(wav.length <= 300 * 1024);
assert.equal(wav.readUInt32LE(24), 16000);
assert.equal(wav.readUInt16LE(34), 16);
const mp3 = fs.readFileSync(require('node:path').join(__dirname, '../music/relay-loop.mp3'));
assert(mp3.length <= 100 * 1024);
assert.equal(mp3.toString('ascii', 0, 3), 'ID3');
const cfg = require('../game.json');
assert(cfg.subpackages.some((p) => p.name === 'music' && p.root === 'music/'));
console.log('音乐：默认不加载、分包异步关闭竞态、独立开关、前后台/中断恢复、错误降级与自制音频预算通过（宿主，不代表听感）');
