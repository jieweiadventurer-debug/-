const assert = require('node:assert/strict'),
  fs = require('node:fs'),
  crypto = require('node:crypto');
const { report, analyze } = require('./difficulty-report');
const paths = ['../js/data/levels', '../js/data/solutions', '../js/core/propagate'].map((p) => require.resolve(p));
const hashes = () => paths.map((p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'));
const before = hashes(),
  a = report(),
  b = report();
assert.equal(a.csv, b.csv);
assert.equal(a.text, b.text);
assert.equal(a.rows.length, 60);
assert(a.rows.find((r) => r.id === '2-7').flag === '章内难度明显回落');
const flags = analyze(
  [
    { chapter: 1, score: 20 },
    { chapter: 1, score: 10 },
    { chapter: 2, score: 5 },
  ],
  0.2,
);
assert.equal(flags[1].flag, '章内难度明显回落');
assert.equal(flags[2].flag, '章间衰退');
assert(report({ threshold: 0.01 }).rows.filter((r) => r.flag).length >= a.rows.filter((r) => r.flag).length);
assert.throws(() => report({ threshold: 0 }));
assert.deepEqual(hashes(), before);
console.log('难度报告：60关指标、确定性、已知2-7回落、章间标记、可配阈值与源文件不变通过（宿主）');
