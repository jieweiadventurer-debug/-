const assert = require('node:assert/strict'),
  LV = require('../js/data/levels'),
  { parseLevel } = require('../js/core/propagate');
const noop = () => {},
  ctx = new Proxy(
    { createLinearGradient: () => ({ addColorStop: noop }) },
    { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
  );
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
let now = 10000;
Date.now = () => now;
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  runs = require('../js/engine/runs');
require('../js/scenes/game');
let messages = [];
const wrapped = ui.wrapped;
ui.wrapped = (g, s, ...args) => {
  messages.push(s);
  wrapped(g, s, ...args);
};
const index = LV.findIndex((l) => l.id === '2-2'),
  level = LV[index],
  { fix } = parseLevel(level),
  board = fix.map((row) => row.map(() => null)),
  inv = { ...level.inv };
[
  [1, 2, 'c', 1],
  [1, 3, 'c', 0],
  [0, 3, 'c', 2],
  [0, 4, 's', 0],
  [5, 2, 's', 0],
  [5, 1, 'c', 1],
  [4, 1, 's', 1],
  [3, 1, 's', 1],
  [2, 1, 'c', 3],
  [2, 0, 'c', 2],
].forEach(([r, c, t, k]) => {
  board[r][c] = { t, k };
  inv[t]--;
});
runs.write(level, { board, inv, hist: [], undoUsed: 0, sel: 's', elapsed: 0, started: false });
assert(runs.read(level));
sm.go('game', { index, resume: true });
function message() {
  messages = [];
  sm.frame();
  return messages[0];
}
function tap(r, c) {
  const p = sm.cur().cellXY(r, c);
  sm.cur().onTap(p.x, p.y);
}
assert(message().includes('需要红色，接到了蓝色'));
const before = runs.read(level);
tap(3, 0);
assert(message().includes('蓝色 B 接收端：从上侧白箭头接入同色信号'));
assert.deepEqual(runs.read(level), before, '查看端点不改棋盘、库存或计时快照');
now += 5001;
assert(message().includes('需要红色，接到了蓝色'), '查看结束自动恢复错误定位');
tap(3, 0);
tap(0, 4);
assert(!message().includes('蓝色 B 接收端'), '改动棋盘立即结束旧查看说明');
tap(3, 0);
sm.go('game', { index, resume: true });
assert(!message().includes('蓝色 B 接收端'), '重新进入不保留临时查看');
console.log('错误状态下端点查看、超时恢复、改盘清理与续玩回归通过（宿主）');
// 自查入口关闭提示并定位真实停点，不消耗库存、体力或修改存档。
{
  let buttons = [];
  const btn = ui.btn;
  ui.btn = (g, b, u) => {
    buttons.push(b);
    btn(g, b, u);
  };
  sm.go('game', 0);
  function click(label) {
    buttons = [];
    sm.frame();
    const b = buttons.find((b) => b.id === label || b.label === label);
    assert(b, label);
    sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
  }
  const before = runs.read(LV[0]);
  click('机器人提示');
  click('checkRoute');
  buttons = [];
  assert(message().includes('停在空格'));
  assert.deepEqual(runs.read(LV[0]), before);
  assert(!buttons.some((b) => b.id === 'checkRoute'), '检查后关闭提示遮罩');
  const p = sm.cur().cellXY(1, 1);
  sm.cur().onTap(p.x, p.y);
  assert(!message().includes('停在空格'), '改盘清除上一次自查结果');
  console.log('线路自查入口、只读检查与改盘清理通过（宿主）');
}
