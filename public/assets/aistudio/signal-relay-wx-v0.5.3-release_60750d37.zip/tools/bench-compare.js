// Paired host comparison; this is not a phone performance measurement.
const { performance } = require('perf_hooks'),
  path = require('path'),
  root = path.resolve(__dirname, '..');
const old = require(root + '/tools/fixtures/propagate-before-o1'),
  cur = require(root + '/js/core/propagate'),
  LV = require(root + '/js/data/levels'),
  sol = require(root + '/js/data/solutions');
const fixtures = LV.map((l) => {
  const p = cur.parseLevel(l),
    b = p.fix.map((row) => row.map(() => null));
  sol[l.id].forEach(([r, c, t, k]) => (b[r][c] = { t, k }));
  return { l, p, b };
});
const call = (engine, f) => engine.propagate(f.p.R, f.p.C, f.p.fix, f.b, f.l.range);
for (let warm = 0; warm < 100; warm++)
  for (const f of fixtures) {
    call(old, f);
    call(cur, f);
  }
const values = { old: [], current: [] };
for (let round = 0; round < 7; round++)
  for (const f of fixtures) {
    for (const [name, engine] of round % 2
      ? [
          ['current', cur],
          ['old', old],
        ]
      : [
          ['old', old],
          ['current', cur],
        ]) {
      const t = performance.now();
      for (let i = 0; i < 300; i++) call(engine, f);
      values[name].push((performance.now() - t) / 300);
    }
  }
const summary = (v) => {
  v.sort((a, b) => a - b);
  return { medianMs: v[Math.floor(v.length * 0.5)], p95Ms: v[Math.floor(v.length * 0.95)] };
};
const a = summary(values.old),
  b = summary(values.current);
console.log(
  JSON.stringify(
    {
      environment: 'paired Node host benchmark, 7 rounds x 50 levels x 300 iterations',
      baseline: a,
      current: b,
      medianRatio: b.medianMs / a.medianMs,
      p95Ratio: b.p95Ms / a.p95Ms,
    },
    null,
    2,
  ),
);
