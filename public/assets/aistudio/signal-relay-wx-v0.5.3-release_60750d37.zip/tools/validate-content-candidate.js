const { parseLevel, propagate, simulate } = require('../js/core/propagate');
const { metrics } = require('./difficulty-report');
function validate(level, solution) {
  const { R, C, fix } = parseLevel(level),
    board = fix.map((row) => row.map(() => null)),
    counts = { s: 0, c: 0, t: 0, a: 0 };
  for (const [r, c, t, k] of solution) {
    if (
      !Number.isInteger(r) ||
      !Number.isInteger(c) ||
      !board[r] ||
      c < 0 ||
      c >= C ||
      board[r][c] ||
      (fix[r][c] && fix[r][c].k !== 'star') ||
      !Object.hasOwn(counts, t) ||
      !Number.isInteger(k) ||
      k < 0 ||
      k > 3
    )
      return null;
    board[r][c] = { t, k };
    counts[t]++;
  }
  if (solution.length !== level.par || !Object.keys(counts).every((t) => counts[t] === level.inv[t])) return null;
  const result = propagate(R, C, fix, board, level.range);
  if (!result.win || simulate(level, []) || (level.range && simulate(level, solution, { noAmp: true }))) return null;
  if (fix.some((row, r) => row.some((f, c) => f && f.k === 'star' && !result.lit.has(r + ',' + c)))) return null;
  return { score: metrics(level, solution).score, bridgesBoth: [...result.br.values()].some((b) => b.h && b.v) };
}
if (require.main === module) {
  let input = '';
  process.stdin.on('data', (s) => (input += s));
  process.stdin.on('end', () => {
    try {
      const c = JSON.parse(input);
      process.stdout.write(JSON.stringify(validate(c.level, c.solution)));
    } catch (e) {
      process.stdout.write('null');
    }
  });
}
module.exports = { validate };
