const assert = require('node:assert/strict'),
  path = require('node:path');
const root = path.resolve(__dirname, '../js');
for (const platform of ['ios', 'android', 'devtools']) {
  for (const [width, height] of [
    [320, 568],
    [390, 844],
    [430, 932],
    [768, 1024],
  ]) {
    Object.keys(require.cache)
      .filter((k) => k.startsWith(root))
      .forEach((k) => delete require.cache[k]);
    const noop = () => {},
      handlers = {},
      menus = [];
    let now = 100000;
    Date.now = () => now;
    const g = new Proxy(
      { createLinearGradient: () => ({ addColorStop: noop }) },
      { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
    );
    global.wx = {
      getDeviceInfo: () => ({ platform }),
      getSystemInfoSync: () => ({ windowWidth: width, windowHeight: height, pixelRatio: 2, safeArea: { top: 20 } }),
      createCanvas: () => ({ getContext: () => g }),
      getStorageSync: () => null,
      setStorageSync: noop,
      showShareMenu: (o) => menus.push(o),
      onShareTimeline: (f) => (handlers.timeline = f),
    };
    const sm = require('../js/engine/scene-manager'),
      social = require('../js/engine/social'),
      store = require('../js/engine/storage'),
      ui = require('../js/engine/ui'),
      notice = require('../js/engine/notice');
    require('../js/scenes/game');
    require('../js/scenes/celebration');
    social.init();
    assert.equal(social.timelineAvailable(), platform === 'android');
    assert.equal(!!handlers.timeline, platform === 'android');
    let buttons = [];
    const btn = ui.btn;
    ui.btn = (g, b, u) => {
      buttons.push(b);
      assert(b.x >= 0 && b.y >= 0 && b.x + b.w <= width * 2 + 1 && b.y + b.h <= height * 2, b.label);
      btn(g, b, u);
    };
    function frame() {
      buttons = [];
      sm.frame();
    }
    for (const t of ['colors', 'bridge', 'split', 'range', 'stars']) store.state.seen['tutorial:' + t] = true;
    for (let i = 0; i < 5; i++) store.state.seen['chapter:' + i] = true;
    sm.go('game', 0);
    const scene = sm.cur();
    [1, 2, 3].forEach((c) => {
      const p = scene.cellXY(1, c);
      scene.onTap(p.x, p.y);
    });
    assert.equal(scene.won.n, 3);
    now += 500;
    frame();
    let button = buttons.find((b) => b.id === 'timeline');
    assert.equal(!!button, platform === 'android');
    const before = JSON.stringify(store.state);
    if (button) {
      scene.onTap(button.x + 1, button.y + 1);
      assert(notice.isOpen());
      const result = handlers.timeline();
      assert.equal(result.query, 'from=timeline&level=1-1');
      assert(!('success' in result));
      assert(!('reward' in result));
      assert.equal(JSON.stringify(store.state), before);
      notice.close();
      assert(menus.some((m) => m.menus.includes('shareAppMessage') && m.menus.includes('shareTimeline')));
    } else assert.equal(social.prepareTimeline('1-1'), false);
    sm.go('game', 0);
    const two = sm.cur();
    let first = two.cellXY(1, 1);
    two.onTap(first.x, first.y);
    frame();
    const undo = buttons.find((b) => b.id === 'undo');
    two.onTap(undo.x + 1, undo.y + 1);
    [1, 2, 3].forEach((c) => {
      const p = two.cellXY(1, c);
      two.onTap(p.x, p.y);
    });
    assert.equal(two.won.n, 2);
    now += 500;
    frame();
    assert(!buttons.some((b) => b.id === 'timeline'), '两星不展示三星朋友圈入口');
    sm.go('celebration', 0);
    frame();
    button = buttons.find((b) => b.id === 'timeline');
    assert.equal(!!button, platform === 'android');
    if (button) {
      sm.cur().onTap(button.x + 1, button.y + 1);
      assert.equal(handlers.timeline().query, 'from=timeline&level=1-10');
      notice.close();
    }
    social.readInvite({ query: { from: 'timeline', level: '2-2' } });
    assert.equal(social.consumeInvite(), '2-2');
    social.readInvite({ query: { from: 'timeline', level: 'bad' } });
    assert.equal(social.consumeInvite(), null);
    // 接口不存在及抛错均降级，不影响奖励/通关。
    if (platform === 'android') {
      require('../js/engine/events').emit('scene_change');
      assert.equal(handlers.timeline().query, 'from=timeline');
      wx.showShareMenu = () => {
        throw Error('unsupported');
      };
      assert(!social.prepareTimeline('1-1'));
      notice.close();
    }
    delete wx.onShareTimeline;
    assert(!social.timelineAvailable());
    assert(!social.prepareTimeline('1-1'));
  }
}
console.log('朋友圈：Android能力门控/其他平台隐藏、四屏三星结算/演出、官方菜单、邀请参数与无奖励通过（宿主，不代表真实朋友圈发布）');
