const assert = require('node:assert/strict');
let now = 100000,
  clock = 0,
  cost = 0.125,
  loop;
Date.now = () => now;
const noop = () => {},
  texts = [];
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }), fillText: (s) => texts.push(s) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 320, windowHeight: 568, pixelRatio: 2, safeArea: { top: 20 } }),
  getPerformance: () => ({
    now: () => {
      clock += cost;
      return clock;
    },
  }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => null,
  setStorageSync: noop,
};
global.requestAnimationFrame = (f) => (loop = f);
const sm = require('../js/engine/scene-manager'),
  perf = require('../js/engine/performance'),
  S = require('../js/engine/progress').sync(),
  ui = require('../js/engine/ui');
S.settings.reduceMotion = false;
S.settings.lowEffects = false;
require('../js/scenes/home');
require('../js/scenes/settings');
sm.go('home');
sm.start();
assert(!perf.isVisible());
assert(!texts.some((t) => String(t).includes('调试面板')));
const normalCalls = perf.snapshot().calls;
assert(normalCalls > 0);
let buttons = [];
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
sm.go('settings');
sm.frame();
let version = buttons.find((b) => b.id === 'version');
assert(version);
for (let i = 0; i < 4; i++) {
  sm.cur().onTap(version.x + 1, version.y + 1);
  now += 100;
}
assert(!perf.isVisible());
sm.cur().onTap(version.x + 1, version.y + 1);
assert(perf.isVisible());
sm.frame();
assert(texts.some((t) => String(t).includes('调试面板')));
for (let i = 0; i < 5; i++) {
  now += 100;
  sm.cur().onTap(version.x + 1, version.y + 1);
}
assert(!perf.isVisible());
// 静止低重绘频率不能触发性能降级。
sm.register('static', { draw: noop });
sm.go('static');
for (let i = 0; i < 30; i++) {
  now += 1000;
  loop();
}
assert(!S.settings.lowEffects);
sm.go('home');
for (let i = 0; i < 11; i++) {
  now += 100;
  loop();
}
sm.setActive(false);
now += 600000;
loop();
sm.setActive(true);
for (let i = 0; i < 20; i++) {
  now += 100;
  loop();
}
assert(!S.settings.lowEffects, '未满连续2秒不降级');
now += 100;
loop();
assert(S.settings.lowEffects);
assert.equal(S.settings.flow, 30);
sm.frame();
assert(perf.snapshot().calls < normalCalls, '精简后不再绘制扫描线/光束');
sm.register('active', { animating: () => true, draw: noop });
sm.go('active');
for (let i = 0; i < 180; i++) {
  now += 16;
  loop();
}
assert(S.settings.lowEffects, '恢复流畅后不自动反复开启');
perf.setLowEffects(false);
assert(!S.settings.lowEffects, '玩家可手动恢复');
cost = 20;
now += 16;
sm.frame();
assert.equal(perf.snapshot().slowestMs, 20);
cost = 0.125;
for (let i = 0; i < 61; i++) {
  now += 16;
  sm.frame();
}
assert.equal(perf.snapshot().slowestMs, 0.125, '最慢耗时只保留最近60次绘制');
S.note = '中文😀';
const expected = Buffer.byteLength(JSON.stringify(S), 'utf8');
now += 1001;
assert.equal(perf.snapshot().storageBytes, expected, 'UTF8大小含中文与代理对');
assert(perf.snapshot().fps > 50);
console.log('隐藏面板五连点、帧率/调用/60帧耗时/存档字节、静止排除、慢帧两秒降级和手动恢复通过（宿主）');
