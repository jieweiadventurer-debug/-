// Static heuristic only: no solver search or claim about measured player difficulty.
const fs = require('node:fs'),
  path = require('node:path');
const levels = require('../js/data/levels'),
  solutions = require('../js/data/solutions');
const { parseLevel } = require('../js/core/propagate');
function metrics(level, solution) {
  const { R, C, fix } = parseLevel(level),
    cells = fix.flat();
  const count = (k) => cells.filter((f) => f && f.k === k).length;
  const colors = new Set(cells.filter((f) => f && f.k === 'src').map((f) => f.col)).size;
  const pieces = solution.length,
    tees = solution.filter((p) => p[2] === 't').length,
    amps = solution.filter((p) => p[2] === 'a').length;
  const bridges = count('bridge'),
    stars = count('star'),
    obstacles = count('obs'),
    area = R * C,
    density = obstacles / area;
  // Weights are explicit and deterministic; do not infer cognitive difficulty from area alone.
  const score = Number(
    (pieces * 2 + colors * 4 + tees * 3 + amps * 3 + bridges * 2 + stars + area * 0.08 + density * 5 + (level.range ? 2 : 0)).toFixed(3),
  );
  return {
    id: level.id,
    chapter: Number(level.id.split('-')[0]),
    area,
    pieces,
    colors,
    tees,
    amps,
    bridges,
    obstacles,
    density: Number(density.toFixed(6)),
    stars,
    score,
  };
}
function analyze(rows, threshold = 0.15) {
  return rows.map((row, i) => {
    const previous = rows[i - 1];
    const drop = previous && previous.score > 0 ? (previous.score - row.score) / previous.score : 0;
    return {
      ...row,
      drop: Number(Math.max(0, drop).toFixed(6)),
      flag: previous && drop >= threshold ? (previous.chapter === row.chapter ? '章内难度明显回落' : '章间衰退') : '',
    };
  });
}
function report({ threshold = 0.15 } = {}) {
  if (!Number.isFinite(threshold) || threshold <= 0 || threshold > 1) throw Error('threshold must be in (0,1]');
  const rows = analyze(
    levels.map((l) => metrics(l, solutions[l.id])),
    threshold,
  );
  const keys = Object.keys(rows[0]);
  const csv = keys.join(',') + '\n' + rows.map((r) => keys.map((k) => String(r[k])).join(',')).join('\n') + '\n';
  const text = [
    '# 关卡静态难度报告',
    '',
    `共 ${rows.length} 关；回落阈值 ${(threshold * 100).toFixed(1)}%。`,
    '综合分 = 标准管件×2 + 颜色×4 + 三通×3 + 增幅×3 + 桥×2 + 星点 + 面积×0.08 + 障碍密度×5 + 有限射程×2。',
    '仅比较相邻关卡。分数是可解释的静态启发式，不能替代真实通关率/用时；章首教学重置可能有意降低难度。',
    '标准管件/三通/增幅来自参考解，桥/障碍/星点来自棋盘。工具不改任何关卡或参考解。',
    '',
    ...rows.filter((r) => r.flag).map((r) => `- ${r.id}：${r.flag}，${(r.drop * 100).toFixed(1)}%，综合分 ${r.score}。`),
    '',
  ].join('\n');
  return { rows, csv, text };
}
if (require.main === module) {
  const args = process.argv.slice(2);
  let threshold = 0.15,
    output = path.resolve(__dirname, '../../signal-relay-difficulty');
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--threshold') threshold = Number(args[++i]);
    else if (args[i] === '--out') output = path.resolve(args[++i]);
    else throw Error('Unknown argument: ' + args[i]);
  }
  const result = report({ threshold });
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, 'difficulty.csv'), result.csv);
  fs.writeFileSync(path.join(output, 'difficulty.md'), result.text);
  console.log(result.text);
  console.log('输出目录: ' + output);
}
module.exports = { metrics, analyze, report };
