const assert = require('node:assert/strict');
let clock = 100000,
  stored = null;
Date.now = () => clock;
const noop = () => {},
  texts = [];
const ctx = new Proxy(
  { createLinearGradient: () => ({ addColorStop: noop }), fillText: (s) => texts.push(s) },
  { get: (t, k) => (k in t ? t[k] : noop), set: (t, k, v) => ((t[k] = v), true) },
);
global.wx = {
  getSystemInfoSync: () => ({ windowWidth: 390, windowHeight: 844, pixelRatio: 3, safeArea: { top: 47 } }),
  createCanvas: () => ({ getContext: () => ctx }),
  getStorageSync: () => stored,
  setStorageSync: (k, v) => (stored = JSON.parse(JSON.stringify(v))),
};
const sm = require('../js/engine/scene-manager'),
  ui = require('../js/engine/ui'),
  store = require('../js/engine/storage'),
  runs = require('../js/engine/runs'),
  progress = require('../js/engine/progress'),
  levels = require('../js/data/levels');
require('../js/scenes/home');
require('../js/scenes/levels');
require('../js/scenes/game');
let buttons = [];
const btn = ui.btn;
ui.btn = (g, b, u) => {
  buttons.push(b);
  btn(g, b, u);
};
function click(id) {
  buttons = [];
  sm.frame();
  const b = buttons.filter((b) => b.id === id || b.label === id).at(-1);
  assert(b, id);
  sm.cur().onTap(b.x + b.w / 2, b.y + b.h / 2);
}
assert(progress.enterLevel(0));
sm.go('game', { index: 0, resume: true });
let p = sm.cur().cellXY(1, 1);
sm.cur().onTap(p.x, p.y);
clock += 5000;
click('home');
assert.equal(runs.read(levels[0]).elapsed, 5000);
assert(stored.runs['1-1']);
store.state.energy = 0;
clock += 60000;
assert(progress.enterLevel(0), '零体力仍可续玩');
assert(!progress.enterLevel(1), '新关仍需体力');
sm.go('game', { index: 0, resume: true });
assert.equal(runs.read(levels[0]).elapsed, 5000);
click('undo');
assert.equal(runs.read(levels[0]).inv.s, 3);
assert.equal(runs.read(levels[0]).undoUsed, 1);
click('goals');
sm.frame();
assert(texts.some((s) => String(s).includes('已用 1 次')));
click('继续接力');
clock += 2000;
sm.cur().pause();
const before = runs.read(levels[0]).elapsed;
clock += 50000;
sm.cur().resume();
clock += 1000;
sm.cur().pause();
assert.equal(runs.read(levels[0]).elapsed, before + 1000, '后台时间不计入');
sm.cur().resume();
for (const c of [1, 2, 3]) {
  p = sm.cur().cellXY(1, c);
  sm.cur().onTap(p.x, p.y);
}
assert(sm.cur().won);
assert.equal(sm.cur().won.n, 2);
assert.equal(runs.read(levels[0]), null, '完成后清理快照');
clock += 5000;
texts.length = 0;
sm.frame();
assert(texts.some((s) => String(s).includes('未达成 · 不使用撤回')));
click('goals');
buttons = [];
sm.frame();
assert(!buttons.some((b) => b.label === '继续接力'), '结算遮罩后的导航不能打开弹窗');
click('选关');
assert.equal(sm.cur().won, undefined, '结算按钮仍可进入选关');
sm.go('game', 0);
for (const c of [1, 2, 3]) {
  p = sm.cur().cellXY(1, c);
  sm.cur().onTap(p.x, p.y);
}
clock += 5000;
const coins = store.state.coins,
  best = store.state.best['1-1'].sec,
  stars = store.state.stars['1-1'];
store.state.energy = 0;
click('再挑战');
assert(!sm.cur().won);
const retry = runs.read(levels[0]);
assert.equal(retry.inv.s, 3);
assert.equal(retry.hist.length, 0);
assert.equal(retry.undoUsed, 0);
assert.equal(retry.elapsed, 0);
assert.equal(store.state.energy, 0);
assert.equal(store.state.stars['1-1'], stars);
assert.equal(store.state.best['1-1'].sec, best);
assert.equal(store.state.coins, coins);
for (const c of [1, 2, 3]) {
  p = sm.cur().cellXY(1, c);
  sm.cur().onTap(p.x, p.y);
}
assert.equal(sm.cur().won.n, 3);
assert.equal(store.state.coins, coins, '同星再挑战不会重复产币');
sm.go('game', 0);
store.state.runs['1-1'].inv.s = 99;
assert.equal(runs.read(levels[0]), null, '损坏库存不能恢复');
console.log('续玩、零体力恢复、库存/撤回、暂停计时、三星解释和快照校验通过（宿主）');

// Bounded history remains restorable, including snapshots from older versions.
sm.go('game', 0);
p = sm.cur().cellXY(1, 1);
for (let i = 0; i < 80; i++) sm.cur().onTap(p.x, p.y);
let capped = runs.read(levels[0]);
assert.equal(capped.hist.length, 50);
store.state.runs['1-1'].hist = [...capped.hist, ...capped.hist];
const migrated = runs.read(levels[0]);
assert.equal(migrated.hist.length, 50);
assert.deepEqual(migrated.board, capped.board);
sm.go('game', { index: 0, resume: true });
for (let i = 0; i < 50; i++) click('undo');
assert.equal(runs.read(levels[0]).hist.length, 0);
const atLimit = JSON.stringify(runs.read(levels[0]).board);
click('undo');
texts.length = 0;
sm.frame();
assert(texts.some((s) => String(s).includes('已经没有可以撤回的操作')));
assert.equal(JSON.stringify(runs.read(levels[0]).board), atLimit);
console.log('80次操作历史上限、旧快照截断恢复与撤回到头通过（宿主）');
