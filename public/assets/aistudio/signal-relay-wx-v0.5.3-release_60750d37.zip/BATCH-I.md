# BATCH-I · 当前批次（v0.5.2，2026-10-31）

本批由 Muse 按用户指令亲自完成（原计划交 Entire 云端 Agent，因额度实为 $0.04 且已用完、跑 Agent 须绑卡，用户拍板不绑卡改由 Muse 执行）。代码已同步推送 Entire 仓库 signal-relay-wx 托管。

## 改动

1. 音量系统（新功能）：新增 js/engine/volume.js 低/中/高三档，音效与音乐共用；默认「中」= 音效 0.6（旧固定 0.25，用户真机反馈偏小）、音乐 0.22（与旧口径一致）。设置页在「音乐」下新增「音量：低/中/高」循环切换，切换即试听放置音效。progress.sync 增加 volumeLevel 合法性兜底（缺失/非法回落 'mid'，旧存档自动兼容）。feedback.play 每次播放按当前档位设 volume（改档即时生效）；music 在创建与续播时按档位设 volume。
2. 像素美术优化（js/data/sprites.js，轮廓不变、只加色阶与点缀）：星星与闪电加高光 #ffe9a8 与阴影 #eda33a 双色阶（starPoint 同步同调色板）；金币加顶部高光；树加两颗橙色果点；水面加两点青色波光；木箱加右侧暗边；机器人加两枚珊瑚色腮红（眼睛行下方）。受保护文件未动，哈希复核一致。
3. 版本：0.5.1 → 0.5.2（package.json / config.VERSION / CURRENT-STATE.json / README / ACCEPTANCE 同步）。包体积已按 2026-10-31 开发者工具正式预览实测更新：主包 256267B、音乐 65163B、总 321430B（上限 346304B 内）。

## 验证

- npm test（41 组宿主测试）、npm run lint、npm run format:check 结果见本批执行记录；真机音效仍以用户 iPhone 扫码预览为准（模拟器音频不可靠）。
