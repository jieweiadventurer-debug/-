# BATCH-J · 当前批次（v0.5.3，2026-10-31）

本批由 Muse 亲自完成。起因：用户真机试玩 v0.5.2 反馈「还是没声音，音乐点击打开就显示暂停了」。v0.5.2 只调了播放乘数、未量素材响度，真机验收未过，本批按实测数据重修。

## 根因（实测，非推测）

1. 素材响度过低：place/rotate/win 三个 wav 峰值仅 0.107（满幅），reward/sign 峰值 0.254；音乐 mp3 峰值 -10.9dB、均值 -21.0dB。叠加上版乘数（音效 0.6 / 音乐 0.22），实际出声峰值约 0.06，手机外放近乎听不见。
2. 静音键跟随未关：feedback 与 music 两处 InnerAudioContext 均未设 obeyMuteSwitch，默认 true 时 iPhone 静音拨片开着即全程静音。
3. 播放状态靠猜：music 的 playing 为本地标志位，从未监听 onPlay/onPause 真实事件；且 InnerAudioContext 刚设 src 同一拍 play 在真机常被吞，吞后无补播，设置页遂长期显示「已暂停」。feedback 同理：首个音效与设 src 同一拍，首播易丢。

## 改动

1. 素材归一化：5 个 wav 以线性增益归一到峰值 0.90（采样率/时长/格式不变，文件大小不变）；音乐 mp3 +9.5dB 增益加限幅重编码（峰值 -0.8dB、均值 -11.0dB，65,133B，ID3 头保留，分包预算内）。
2. js/engine/feedback.js：创建实例时显式 obeyMuteSwitch=false；新增 preload() 在启动时预建全部音效实例提前解码；实例未就绪时首次播放挂起，onCanplay 就绪后补播。坏实例静默降级的原有语义不变（feedback-test 合同保留）。
3. js/engine/music.js：显式 obeyMuteSwitch=false；新增 onPlay/onPause 真实状态同步（realPlaying）与 wantPlay 挂起标志，onCanplay 时若仍未真播则直接补播；pause/fail 清理挂起状态。
4. js/engine/volume.js：音乐乘数上调（低 0.18 / 中 0.35 / 高 0.55），音效乘数不变（素材已归一化）。
5. game.js：启动时调用 feedback.preload()。
6. 版本：0.5.2 → 0.5.3（package.json / config.VERSION / CURRENT-STATE.json / README / ACCEPTANCE 同步）。包体积按本批开发者工具正式预览实测回填。

## 验证

- npm test（41 组宿主测试）、npm run lint、npm run format:check 全绿（见本批执行记录）。
- 真机验收仍以用户 iPhone 扫码预览为准：本批验收点为音效可闻（放置/旋转）、音乐打开后状态显示播放中且可闻、静音拨片开着也应出声。
