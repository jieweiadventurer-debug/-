// 像素精灵点阵（与网页版同一份数据）+ 烘焙缓存
const SPR = {
  tree: {
    p: { G: '#a7f070', g: '#38b764', b: '#73464c', f: '#ef7d57' },
    r: ['...GG...', '..GGGg..', '.GfgGGg.', '..GGgGG.', '.GGGfgGg', 'GGgGGGGg', '...bb...', '...bb...'],
  },
  rock: {
    p: { l: '#94b0c2', L: '#f4f4f4', d: '#333c57' },
    r: ['........', '...llll.', '..lLlldd', '.lLllldd', 'lLllllld', 'llllllld', '.dddddd.', '........'],
  },
  box: {
    p: { b: '#73464c', o: '#c28a5b', d: '#4e2f36' },
    r: ['bbbbbbbd', 'booooood', 'bbbbbbbd', 'booooood', 'booooood', 'bbbbbbbd', 'booooood', 'bbbbbbbd'],
  },
  water: {
    p: { w: '#3b5dc9', W: '#41a6f6', s: '#73eff7' },
    r: ['wwwWWwsw', 'wwwwwwww', 'WWwwwwWW', 'wwwwwwww', 'wsWWwwww', 'wwwwwwww', 'wwwwwWWw', 'wwwwwwww'],
  },
  star: {
    p: { Y: '#ffcd75', H: '#ffe9a8', S: '#eda33a' },
    r: ['...HH...', '...HY...', 'HYYYYYYS', '.HYYYYS.', '..HYYS..', '.HYYSS.', '.HY..YS.', 'HY....SS'],
  },
  robot: {
    p: { k: '#1a1c2c', w: '#f4f4f4', c: '#73eff7', y: '#ffcd75', o: '#ef7d57' },
    r: [
      '....yy....',
      '....kk....',
      '.kkkkkkkk.',
      'kwwwwwwwwk',
      'kwkkkkkkwk',
      'kwkckkckwk',
      'kwokkkkowk',
      'kwwwwwwwwk',
      '.kkkkkkkk.',
      '..kyyyyk..',
    ],
  },
  bolt: {
    p: { Y: '#ffcd75', H: '#ffe9a8', S: '#eda33a' },
    r: ['....HH..', '...HY...', '..HY....', '.HYYYYS.', '...YY...', '..YS....', '.YS.....', 'S.......'],
  },
  coin: {
    p: { o: '#ef7d57', Y: '#ffcd75', H: '#ffe9a8' },
    r: ['..oooo..', '.oHHHHo.', 'oHYoYYYo', 'oYYoYYYo', 'oYYoYYYo', 'oYYYYYYo', '.oYYYYo.', '..oooo..'],
  },
  lock: {
    p: { l: '#94b0c2', Y: '#ffcd75', d: '#1a1c2c' },
    r: ['..llll..', '.l....l.', '.l....l.', 'YYYYYYYY', 'YYYddYYY', 'YYYddYYY', 'YYYYYYYY', '........'],
  },
};
// Match the reference: a broad, solid 8px gold silhouette, without an outline.
SPR.starPoint = { p: { Y: '#ffcd75', H: '#ffe9a8', S: '#eda33a' }, r: SPR.star.r };
const cache = {};
function bake(name, u, dim) {
  const key = name + u + (dim ? 'd' : '');
  if (cache[key]) return cache[key];
  const d = SPR[name],
    c = wx.createCanvas();
  c.width = d.r[0].length * u;
  c.height = d.r.length * u;
  const g = c.getContext('2d');
  d.r.forEach((row, y) =>
    [...row].forEach((ch, x) => {
      if (ch === '.') return;
      g.fillStyle = dim && name === 'star' ? '#566c86' : dim && name === 'starPoint' ? '#b8a071' : d.p[ch];
      g.fillRect(x * u, y * u, u, u);
    }),
  );
  return (cache[key] = c);
}
function clearCache() {
  for (const key of Object.keys(cache)) {
    cache[key].width = 0;
    cache[key].height = 0;
    delete cache[key];
  }
}
module.exports = { SPR, bake, clearCache, cacheSize: () => Object.keys(cache).length };
