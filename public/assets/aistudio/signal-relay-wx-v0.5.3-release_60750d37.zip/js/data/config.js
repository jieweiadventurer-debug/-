module.exports = {
  VERSION: '0.5.3',
  REWARDED_AD_UNIT_ID: '', // 在微信流量主后台创建后填写真实 adunit- ID
  DAILY_REWARD: 100,
  MAXE: 30, // 体力上限
  ENERGY_MS: 5 * 60 * 1000, // 每 5 分钟恢复 1 点
  DEV_UNLOCK: false, // 开发期：解锁全部关卡，上线前改为 false
  COLORS: { red: '#ef4b5c', green: '#5fe36c', blue: '#41a6f6', yellow: '#ffcd75' },
  CHAPTERS: ['晨光草原', '森林溪谷', '海岸灯塔', '峡谷瀑布', '云端星塔', '极光群岛'],
};
