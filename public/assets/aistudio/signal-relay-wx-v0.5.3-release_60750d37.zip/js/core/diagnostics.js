const names = { red: '红', blue: '蓝', green: '绿', yellow: '黄' };
const directions = { U: '上', R: '右', D: '下', L: '左' };
function diagnose(result, fix) {
  if (result.bad.size) return { kind: 'conflict', cells: [...result.bad], message: '红框内信号混色了，请分开不同颜色的路线。' };
  const issue = [...result.targetIssues.entries()].find(([key]) => !result.reached.has(key));
  if (issue) {
    const [key, detail] = issue,
      [r, c] = key.split(',').map(Number),
      endpoint = fix && fix[r] && fix[r][c];
    const where = '第' + (r + 1) + '行第' + (c + 1) + '列：';
    return {
      kind: detail.kind,
      cells: [key],
      message:
        detail.kind === 'color'
          ? where + '需要' + names[detail.expected] + '色，接到了' + names[detail.actual] + '色'
          : where + '入口不对，请从' + (endpoint ? directions[endpoint.d] + '侧白箭头' : '短管一侧') + '接入',
    };
  }
  if (result.exhausted.size) {
    const cells = [...result.exhausted],
      [r, c] = cells[0].split(',').map(Number);
    return { kind: 'range', cells, message: '射程耗尽：第' + (r + 1) + '行第' + (c + 1) + '列。请在前方亮管处增幅' };
  }
  return null;
}
// 仅描述当前真实信号停点，不使用预置解法，也不判定某条路线唯一正确。
function checkRoute(result, fix) {
  if (result.win) return { kind: 'complete', cells: [], message: '全部接收端已接通，可以查看三星目标。' };
  const issue = diagnose(result, fix);
  if (issue) return issue;
  const pending = new Set();
  fix.forEach((row, r) =>
    row.forEach((f, c) => {
      if (f && f.k === 'tgt' && !result.reached.has(r + ',' + c)) pending.add(f.col);
    }),
  );
  const stop = (result.stops || []).find((s) => pending.has(s.col));
  if (!stop) return { kind: 'open', cells: [], message: '还有目标未接通，请从同色发射端沿线检查。' };
  const where = '第' + (stop.r + 1) + '行第' + (stop.c + 1) + '列',
    color = names[stop.col] + '色';
  const text = {
    gap: '停在空格，可在此接续管件',
    pipe: '遇到未对齐管件，请旋转或换件',
    blocked: '被固定格挡住，请调整路线',
    edge: '走到棋盘边缘，请调整路线',
  };
  return { kind: stop.kind, cells: [stop.r + ',' + stop.c], message: color + '在' + where + text[stop.kind] };
}
module.exports = { diagnose, checkRoute };
