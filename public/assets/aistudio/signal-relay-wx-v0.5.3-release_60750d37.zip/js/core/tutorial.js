// 教学按本关真实机制生成，首次进入只展示一个尚未读过的主题。
const { parseLevel } = require('./propagate');
function topics(level) {
  const { fix } = parseLevel(level),
    cells = fix.flat(),
    list = [];
  if (new Set(cells.filter((f) => f && f.k === 'src').map((f) => f.col)).size > 1)
    list.push({
      id: 'colors',
      title: '同色同字母，才是一对',
      lines: ['实心框发射信号，空心框接收信号。', '红色 R 接红色 R，黄色 Y 接黄色 Y。', '点击端点，高亮它的同色伙伴。'],
    });
  if (cells.some((f) => f && f.k === 'bridge'))
    list.push({
      id: 'bridge',
      title: '桥让两条信号各走各的',
      lines: ['横向直通，纵向直通，互不转弯。', '两种颜色可以从桥上交叉通过。', '同一通道不能混入两种颜色。'],
    });
  if (level.inv.t > 0)
    list.push({
      id: 'split',
      title: '三通把一路信号分出去',
      lines: ['一个入口，另外两个端口同时输出。', '可为同色的多个接收端分路。', '点击旋转，让端口对准相邻管件。'],
    });
  if (level.inv.a > 0 || level.range != null)
    list.push({
      id: 'range',
      title: '信号走远了，需要增幅',
      lines: ['普通管件每经过一格消耗一点射程。', '在射程用尽前放置带 + 的增幅器。', '增幅器将射程恢复为本关初始值。'],
    });
  if (cells.some((f) => f && f.k === 'star'))
    list.push({
      id: 'stars',
      title: '让信号经过星点',
      lines: ['星点所在空格也能放置管件。', '信号经过后，星点会亮起。', '收齐全部星点，可获得对应的一星。'],
    });
  list.push({
    id: 'basics',
    title: '从发射端接到接收端',
    lines: ['点空格放置管件，点管件旋转。', '长按取回；撤回恢复上一步。', '从接收端白箭头所在的一侧接入。'],
  });
  return list;
}
function firstUnread(level, seen) {
  return topics(level).find((t) => t.id !== 'basics' && !seen['tutorial:' + t.id]) || null;
}
module.exports = { topics, firstUnread };
