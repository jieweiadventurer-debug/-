const LV = require('../data/levels');
const names = ['草原中继站', '森林信号桥', '海岸灯塔', '峡谷增幅站', '云端星塔', '极光天线阵'];
const describe = ['草原的第一束光', '让林间信号相连', '让海岸灯塔重亮', '跨过峡谷的回声', '把星光送到远方', '让极光跨越群岛'];
function chapters(stars) {
  return names.map((name, i) => {
    const levels = LV.slice(i * 10, i * 10 + 10),
      cleared = levels.filter((l) => stars[l.id] > 0).length,
      totalStars = levels.reduce((n, l) => n + (stars[l.id] || 0), 0);
    const unlocked = i === 0 || (stars[LV[i * 10 - 1].id] || 0) > 0;
    const next = levels.find((l) => !(stars[l.id] > 0));
    return {
      nextId: next ? next.id : null,
      index: i,
      name,
      description: describe[i],
      cleared,
      totalStars,
      unlocked,
      restored: cleared === 10,
      stage: cleared === 10 ? '已修复' : cleared >= 5 ? '修复中' : cleared ? '已接通信号' : '等待接力',
    };
  });
}
module.exports = { chapters };
