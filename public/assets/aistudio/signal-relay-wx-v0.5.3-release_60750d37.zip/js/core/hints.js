const solutions = require('../data/solutions');
const dailySolutions = require('../data/daily-solutions');
const { portsOf } = require('./propagate');
const same = (a, b) => a && b && a.t === b.t && portsOf(a).slice().sort().join('') === portsOf(b).slice().sort().join('');
function nextHint(level, board) {
  const solution = solutions[level.id] || dailySolutions[level.id];
  if (!solution) return null;
  const wanted = new Map(solution.map(([r, c, t, k]) => [r + ',' + c, { t, k }]));
  // Recover misplaced stock before asking the player to place another piece.
  for (let r = 0; r < board.length; r++)
    for (let c = 0; c < board[r].length; c++) {
      const pc = board[r][c],
        target = wanted.get(r + ',' + c);
      if (pc && (!target || pc.t !== target.t)) return { r, c, kind: 'remove', piece: pc };
    }
  for (const [r, c, t, k] of solution) {
    const pc = board[r][c],
      piece = { t, k };
    if (!same(pc, piece)) return { r, c, kind: pc ? 'rotate' : 'place', piece };
  }
  return null;
}
module.exports = { nextHint, same };
function applyHint(board, inv, h) {
  if (!h || !board[h.r] || h.c < 0 || h.c >= board[h.r].length) return false;
  const pc = board[h.r][h.c];
  if (h.kind === 'remove') {
    if (!pc) return false;
    inv[pc.t]++;
    board[h.r][h.c] = null;
    return true;
  }
  if (h.kind === 'rotate') {
    if (!pc || pc.t !== h.piece.t) return false;
    pc.k = h.piece.k;
    return true;
  }
  if (h.kind === 'place') {
    if (pc || !(inv[h.piece.t] > 0)) return false;
    inv[h.piece.t]--;
    board[h.r][h.c] = { t: h.piece.t, k: h.piece.k };
    return true;
  }
  return false;
}
module.exports.applyHint = applyHint;
