// Guided sandbox uses the same propagation rules; no inventory or save mutations.
const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas'),
  ui = require('../engine/ui'),
  { parseLevel, propagate, portsOf, DV } = require('./propagate'),
  CFG = require('../data/config');
const starMarker = require('../engine/star-marker');
const examples = {
  basics: {
    title: '放置与旋转',
    g: ['.. .. .. .. ..', 'R> .. r< .. ..', '.. .. .. .. ..'],
    steps: [
      [1, 1, 's', 0, '点青框，放置直线'],
      [1, 1, 's', 1, '再点这根管件，转为竖直'],
      [1, 1, 's', 2, '再旋转一次，接回红色终点'],
    ],
  },
  colors: {
    title: '同色字母配对',
    g: ['R> .. r< .. ..', '.. .. .. .. ..', 'B> .. b< .. ..'],
    steps: [
      [0, 1, 's', 0, '先把红色 R 接到红色 R'],
      [2, 1, 's', 0, '再把蓝色 B 接到蓝色 B'],
    ],
  },
  bridge: {
    title: '桥的独立通道',
    g: ['.. Bv .. .. ..', 'R> == .. r< ..', '.. b^ .. .. ..'],
    steps: [[1, 2, 's', 0, '蓝色已直通，补上红色横向线路']],
  },
  split: {
    title: '三通分路',
    g: ['.. rv .. .. ..', 'R> .. r< .. ..', '.. .. .. .. ..'],
    steps: [
      [1, 1, 't', 0, '点青框放三通，观察朝向'],
      [1, 1, 't', 1, '再点旋转，同时接通两个红色终点'],
    ],
  },
  range: {
    title: '在射程用尽前增幅',
    range: 1,
    g: ['.. .. .. .. ..', 'R> .. .. .. r<', '.. .. .. .. ..'],
    steps: [
      [1, 1, 'a', 0, '先在信号还亮的位置放增幅器'],
      [1, 2, 'a', 0, '继续增幅，恢复一格射程'],
      [1, 3, 's', 0, '最后放直线，恰好抵达终点'],
    ],
  },
  stars: {
    title: '让信号经过星点',
    g: ['.. .. .. .. ..', 'R> .. ** r< ..', '.. .. .. .. ..'],
    steps: [
      [1, 1, 's', 0, '先接续红色信号'],
      [1, 2, 's', 0, '在星点格放管，让信号经过'],
    ],
  },
};
function create(id) {
  const example = examples[id] || examples.basics,
    { fix, R, C } = parseLevel(example);
  const state = { example, fix, R, C, board: fix.map((row) => row.map(() => null)), step: 0 };
  state.result = propagate(R, C, fix, state.board, example.range == null ? null : example.range);
  return state;
}
function box() {
  const h = Math.min(420 * DPR, H - contentTop - safeBottom - 8 * DPR);
  return { x: W * 0.04, y: Math.max(contentTop, (H - h) / 2), w: W * 0.92, h };
}
function geometry() {
  const m = box(),
    cs = Math.floor(Math.min((m.w - 24 * DPR) / 5, (m.h - 230 * DPR) / 3));
  return { m, cs, x: Math.round((W - cs * 5) / 2), y: m.y + 118 * DPR };
}
function buttons(state) {
  const m = box();
  return [
    {
      id: 'exitPractice',
      x: m.x + 16 * DPR,
      y: m.y + m.h - 58 * DPR,
      w: m.w - 32 * DPR,
      h: 40 * DPR,
      label: state.step >= state.example.steps.length ? '练习完成 · 返回本关' : '退出练习 · 返回本关',
      primary: true,
    },
  ];
}
function draw(g, s) {
  const { m, cs, x: bx, y: by } = geometry(),
    done = s.step >= s.example.steps.length,
    step = s.example.steps[s.step];
  g.fillStyle = 'rgba(10,10,20,.9)';
  g.fillRect(0, 0, W, H);
  ui.panel(g, m.x, m.y, m.w, m.h, 2 * DPR);
  ui.text(
    g,
    '动手练习 · ' + s.example.title,
    W / 2,
    m.y + 28 * DPR,
    Math.min(16 * DPR, (m.w - 24 * DPR) / ('动手练习 · ' + s.example.title).length),
    '#ffcd75',
  );
  ui.text(g, done ? '接通成功！' : s.step + 1 + ' / ' + s.example.steps.length, W / 2, m.y + 58 * DPR, 12 * DPR, '#94b0c2');
  ui.wrapped(g, done ? '这套操作也适用于正式关卡。' : step[4], W / 2, m.y + 88 * DPR, m.w - 24 * DPR, 12 * DPR, '#f4f4f4', 'center');
  const marks = { red: 'R', blue: 'B', green: 'G', yellow: 'Y' };
  for (let r = 0; r < s.R; r++)
    for (let c = 0; c < s.C; c++) {
      const x = bx + c * cs,
        y = by + r * cs,
        f = s.fix[r][c],
        pc = s.board[r][c],
        key = r + ',' + c;
      g.fillStyle = (r + c) % 2 ? '#4a5d78' : '#566c86';
      g.fillRect(x, y, cs - 1, cs - 1);
      if (f && f.k === 'star') starMarker.draw(g, x, y, cs, !!pc, s.result.lit.has(key));
      const ports = f && (f.k === 'src' || f.k === 'tgt') ? [f.d] : f && f.k === 'bridge' ? ['L', 'R', 'U', 'D'] : pc ? portsOf(pc) : [];
      const col = f && f.col ? CFG.COLORS[f.col] : s.result.lit.has(key) ? CFG.COLORS[s.result.lit.get(key)] : '#b3b9d1';
      g.fillStyle = col;
      ports.forEach((d) => {
        const [dy, dx] = DV[d];
        g.fillRect(
          x + cs / 2 - (dx < 0 ? cs / 2 : cs * 0.09),
          y + cs / 2 - (dy < 0 ? cs / 2 : cs * 0.09),
          dx ? cs * 0.59 : cs * 0.18,
          dy ? cs * 0.59 : cs * 0.18,
        );
      });
      if (f && (f.k === 'src' || f.k === 'tgt')) {
        g.fillStyle = CFG.COLORS[f.col];
        g.fillRect(x + cs * 0.22, y + cs * 0.22, cs * 0.56, cs * 0.56);
        g.fillStyle = f.k === 'src' || s.result.reached.has(key) ? '#ffffff' : '#1a1c2c';
        g.fillRect(x + cs * 0.3, y + cs * 0.3, cs * 0.4, cs * 0.4);
        ui.text(g, marks[f.col], x + cs / 2, y + cs / 2, cs * 0.27, f.k === 'src' || s.result.reached.has(key) ? '#1a1c2c' : '#ffffff');
      }
      if (f && f.k === 'bridge') ui.text(g, '╬', x + cs / 2, y + cs / 2, cs * 0.5, '#ffcd75');
      if (pc && pc.t === 'a') ui.text(g, '+', x + cs / 2, y + cs / 2, cs * 0.4, '#ffcd75');
      if (step && step[0] === r && step[1] === c) {
        g.strokeStyle = '#73eff7';
        g.lineWidth = 2 * DPR;
        g.strokeRect(x + 2 * DPR, y + 2 * DPR, cs - 4 * DPR, cs - 4 * DPR);
      }
    }
  ui.text(g, '练习不扣体力，不修改本关进度', W / 2, m.y + m.h - 82 * DPR, 11 * DPR, '#94b0c2');
  buttons(s).forEach((b) => ui.btn(g, b, 2 * DPR));
}
function tap(s, x, y) {
  if (ui.hit(buttons(s), x, y)) return true;
  const step = s.example.steps[s.step];
  if (!step) return false;
  const p = geometry(),
    r = Math.floor((y - p.y) / p.cs),
    c = Math.floor((x - p.x) / p.cs);
  if (r !== step[0] || c !== step[1]) return false;
  s.board[r][c] = { t: step[2], k: step[3] };
  s.step++;
  s.result = propagate(s.R, s.C, s.fix, s.board, s.example.range == null ? null : s.example.range);
  return false;
}
module.exports = { create, draw, tap, geometry, examples };
