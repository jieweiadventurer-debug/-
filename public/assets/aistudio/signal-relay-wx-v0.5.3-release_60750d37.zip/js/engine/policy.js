const notice = require('./notice');
const events = require('./events');
const summaries = {
  agreement: [
    '这是单机解谜游戏，进度保存在本机。',
    '删除微信缓存可能导致本地进度丢失。',
    '分享不发奖励；规则以游戏说明为准。',
    '协议草案需用户确认，不构成正式协议。',
  ],
  privacy: [
    '棋盘、星数、金币和设置保存在本机。',
    '好友榜仅自愿开启后同步成绩数据。',
    '总星数、通关数、版本、更新时间。',
    '玩法统计和诊断日志均可选择开启。',
    '好友昵称仅在微信开放域内展示。',
    '本摘要需用户确认，以后台完整指引为准。',
  ],
};
let serial = 0,
  timer = null;
function cancel() {
  serial++;
  if (timer !== null) clearTimeout(timer);
  timer = null;
}
events.on('scene_change', cancel);
function summary(kind) {
  notice.open({ title: kind === 'privacy' ? '隐私保护指引' : '用户协议', lines: summaries[kind] });
}
function reporting() {
  notice.open({
    title: '统计与诊断说明',
    lines: [
      '玩法统计：关卡、星数、用时和操作计数。',
      '诊断日志：事件类别与游戏版本。',
      '不上传错误原文、堆栈或身份信息。',
      '只在你开启对应开关后发送。',
      '用于发现卡关和异常，可随时关闭。',
    ],
  });
}
function show(kind) {
  cancel();
  // Checked 2026-10-30 in official minigame-api-typings; website unavailable during verification.
  // https://developers.weixin.qq.com/minigame/dev/api/open-api/privacy/wx.openPrivacyContract.html
  if (kind !== 'privacy' || typeof wx.openPrivacyContract !== 'function') {
    summary(kind);
    return;
  }
  const token = serial;
  const finish = (fallback) => {
    if (token !== serial) return;
    cancel();
    if (fallback) summary('privacy');
  };
  // DevTools can expose the API without opening a page or settling callbacks.
  timer = setTimeout(() => finish(true), 1500);
  try {
    wx.openPrivacyContract({ success: () => finish(false), fail: () => finish(true) });
  } catch (e) {
    finish(true);
  }
}
module.exports = { show, summary, reporting };
