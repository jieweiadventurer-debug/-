// Large controls are an equivalent input route; the board thumbnail is deliberately not touchable.
const { W, H, DPR, contentTop, safeBottom } = require('./canvas');
const ui = require('./ui'),
  prefs = require('./accessibility-preferences'),
  store = require('./storage'),
  notice = require('./notice'),
  events = require('./events');
const LV = require('../data/levels');
const states = new WeakMap();
let offscreen = null;
const names = {
  home: '首页',
  'player-feedback': '意见反馈',
  daily: '每日挑战',
  levels: '选关',
  game: '接力棋盘',
  settings: '游戏偏好',
  world: '修复地图',
  rank: '好友榜',
  celebration: '接力演出',
};
function stateFor(source) {
  let s = states.get(source);
  if (!s) {
    s = { page: 0, row: 0, col: 0, board: false, buttons: [], scope: '' };
    states.set(source, s);
  }
  return s;
}
function label(b) {
  if (b.label) return String(b.label) + (b.locked ? ' · 未解锁' : '');
  if (b.id && b.id.startsWith('lv:')) return '第 ' + LV[Number(b.id.slice(3))].id + ' 关' + (b.locked ? ' · 未解锁' : '');
  const labels = {
    start: store.state.activeRun ? '继续游戏' : '开始游戏',
    'tool:s': '直线管',
    'tool:c': '拐角管',
    'tool:t': '三通管',
    'tool:a': '增幅器',
    'hud:rank': '等级与好友榜',
    'hud:energy': '体力与商店',
    'hud:coins': '金币与商店',
  };
  return labels[b.id] || b.id || '操作';
}
function capture(source, dt) {
  if (!offscreen) {
    offscreen = wx.createCanvas();
    offscreen.width = W;
    offscreen.height = H;
  }
  const g = offscreen.getContext('2d'),
    buttons = [],
    texts = [],
    oldBtn = ui.btn,
    oldText = ui.text,
    oldWrapped = ui.wrapped;
  try {
    ui.btn = (ctx, b, u) => {
      if (ctx === g) buttons.push({ ...b });
      return oldBtn(ctx, b, u);
    };
    ui.text = (ctx, text, ...args) => {
      if (ctx === g && text) texts.push(String(text));
      return oldText(ctx, text, ...args);
    };
    ui.wrapped = (ctx, text, ...args) => {
      if (ctx === g && text) texts.push(String(text));
      return oldWrapped(ctx, text, ...args);
    };
    g.clearRect(0, 0, W, H);
    source.draw(g, dt);
  } finally {
    ui.btn = oldBtn;
    ui.text = oldText;
    ui.wrapped = oldWrapped;
  }
  return { buttons: source.accessibilityButtons ? source.accessibilityButtons(buttons) : buttons, texts: [...new Set(texts)] };
}
function at(label, run, x, y, w, h = 52 * DPR) {
  return { label, run, x, y, w, h, fs: 18 * DPR };
}
function read(lines) {
  notice.open({ title: '画面说明', lines: lines.length ? lines : ['当前画面暂无额外说明。'] });
}
function exit() {
  prefs.set('largeText', false);
  store.save();
  events.emit('invalidate');
}
function controlsLayout() {
  const top = contentTop + 188 * DPR,
    end = H - safeBottom - 124 * DPR;
  const h = Math.max(52 * DPR, Math.min(76 * DPR, (end - top - 16 * DPR) / 3));
  return { y: top + Math.max(0, (end - top - 3 * h - 16 * DPR) / 2), h, step: h + 8 * DPR };
}
function menuButtons(s, source, info, captured) {
  const actions = captured.buttons.map((b) => ({ label: label(b), run: () => source.onTap(b.x + b.w / 2, b.y + b.h / 2) }));
  if (info && info.operable)
    actions.unshift({
      label: '逐格操作 · 大按钮',
      run: () => {
        s.board = true;
      },
    });
  if (info && info.practice) actions.unshift({ label: '按提示完成练习一步', run: info.practice });
  const pages = Math.max(1, Math.ceil(actions.length / 3));
  s.page = Math.min(s.page, pages - 1);
  const region = controlsLayout();
  const buttons = actions
    .slice(s.page * 3, s.page * 3 + 3)
    .map((a, i) => at(a.label, a.run, W * 0.05, region.y + i * region.step, W * 0.9, region.h));
  const navigation =
    pages > 1
      ? [
          ['上页', () => (s.page = (s.page + pages - 1) % pages)],
          [`${s.page + 1}/${pages} 说明`, () => read(captured.texts)],
          ['下页', () => (s.page = (s.page + 1) % pages)],
        ]
      : [['画面说明', () => read(captured.texts)]];
  const gap = 8 * DPR,
    w = (W * 0.9 - gap * (navigation.length - 1)) / navigation.length,
    y = H - safeBottom - 108 * DPR;
  navigation.forEach(([label, run], i) => buttons.push(at(label, run, W * 0.05 + i * (w + gap), y, w, 44 * DPR)));
  return buttons;
}
function boardButtons(s, info) {
  const w = (W * 0.9 - 16 * DPR) / 3,
    x = W * 0.05,
    region = controlsLayout(),
    y = region.y;
  const move = (r, c) => {
    s.row = (s.row + r + info.R) % info.R;
    s.col = (s.col + c + info.C) % info.C;
  };
  return [
    ['上一行', () => move(-1, 0), 1, 0],
    ['上一列', () => move(0, -1), 0, 1],
    ['放置/旋转', () => info.activate(s.row, s.col), 1, 1],
    ['下一列', () => move(0, 1), 2, 1],
    ['下一行', () => move(1, 0), 1, 2],
    ['取回管件', () => info.remove(s.row, s.col), 2, 2],
    [
      '工具菜单',
      () => {
        s.board = false;
      },
      0,
      2,
    ],
  ].map(([l, f, c, r]) => at(l, f, x + c * (w + 8 * DPR), y + r * region.step, w, region.h));
}
function preview(g, s, info) {
  const y = contentTop + 46 * DPR;
  if (info && info.summary) {
    info.summary
      .slice(0, 3)
      .forEach((line, i) =>
        ui.wrapped(g, line, W / 2, contentTop + (66 + i * 44) * DPR, W * 0.9, (i ? 16 : 22) * DPR, i ? '#ffffff' : '#ffcd75'),
      );
  } else if (info && info.rect) {
    const b = info.rect,
      scale = Math.min((W * 0.44) / b.w, (108 * DPR) / b.h),
      dw = b.w * scale,
      dh = b.h * scale;
    g.drawImage(offscreen, b.x, b.y, b.w, b.h, W * 0.05, y, dw, dh);
    g.strokeStyle = '#ffcd75';
    g.lineWidth = 2 * DPR;
    g.strokeRect(W * 0.05 + (s.col * dw) / info.C, y + (s.row * dh) / info.R, dw / info.C, dh / info.R);
    const cs = b.w / info.C;
    g.drawImage(offscreen, b.x + s.col * cs, b.y + s.row * cs, cs, cs, W * 0.62, y, 88 * DPR, 88 * DPR);
    ui.wrapped(g, info.describe(s.row, s.col), W / 2, contentTop + 158 * DPR, W * 0.9, 16 * DPR, '#ffffff');
  } else {
    const scale = Math.min((W * 0.8) / W, (108 * DPR) / H),
      w = W * scale,
      h = H * scale;
    g.drawImage(offscreen, (W - w) / 2, y, w, h);
    ui.text(g, '大按钮操作 · 点“说明”阅读画面', W / 2, contentTop + 158 * DPR, 16 * DPR, '#ffffff');
  }
}
function draw(g, source, name, dt) {
  const s = stateFor(source),
    captured = capture(source, dt),
    info = source.accessibilityInfo && source.accessibilityInfo();
  const scope = info ? info.scope : '';
  if (scope !== s.scope) {
    s.scope = scope;
    s.page = 0;
    s.board = false;
  }
  if (info) {
    s.row = Math.min(s.row, info.R - 1);
    s.col = Math.min(s.col, info.C - 1);
  }
  ui.background(g, W, H);
  ui.text(g, (names[name] || '信号接力') + ' · 大字操作', W / 2, contentTop + 20 * DPR, 20 * DPR, '#ffcd75');
  const smoothing = g.imageSmoothingEnabled;
  g.imageSmoothingEnabled = false;
  preview(g, s, info);
  g.imageSmoothingEnabled = smoothing;
  s.buttons = s.board && info && info.operable ? boardButtons(s, info) : menuButtons(s, source, info, captured);
  if (s.board)
    s.buttons.push(
      at('格子说明', () => read([info.describe(s.row, s.col), ...captured.texts]), W * 0.05, H - safeBottom - 108 * DPR, W * 0.9, 44 * DPR),
    );
  s.buttons.push(at('返回标准布局', exit, W * 0.05, H - safeBottom - 56 * DPR, W * 0.9, 44 * DPR));
  for (const b of s.buttons) {
    const offset = ui.pressed(b) ? Math.max(2, Math.round(2 * DPR)) : 0;
    ui.btn(g, { ...b, label: '' }, 2 * DPR);
    g.strokeStyle = prefs.color('#94b0c2');
    g.lineWidth = DPR;
    g.strokeRect(b.x + DPR, b.y + DPR + offset, b.w - 2 * DPR, b.h - 2 * DPR);
    ui.wrapped(g, b.label, b.x + b.w / 2, b.y + b.h / 2 + offset, b.w - 8 * DPR, 16 * DPR, '#ffffff');
  }
}
function surface(source) {
  const s = stateFor(source);
  if (!s.surface)
    s.surface = {
      source,
      pause: () => {
        if (source.pause) source.pause();
      },
      resume: () => {
        if (source.resume) source.resume();
      },
      onTap(x, y) {
        const b = ui.hit(s.buttons, x, y);
        if (b) {
          b.run();
          events.emit('invalidate');
        }
      },
      onLong: () => false,
    };
  return s.surface;
}
module.exports = {
  draw,
  release() {
    if (offscreen) {
      offscreen.width = 0;
      offscreen.height = 0;
      offscreen = null;
    }
  },
  surface,
  enabled: prefs.enabled,
  buttons: (source) => stateFor(source).buttons,
  reset: (source) => states.delete(source),
};
