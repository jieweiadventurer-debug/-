// 存档：wx 本地存储；损坏时回到默认值
const KEY = 'sr_save';
const CFG = require('../data/config');
const defaults = () => ({
  coins: 200,
  energy: 30,
  et: Date.now(),
  stars: {},
  best: {},
  ci: '',
  ch: 0,
  stat: { clear: 0, par: 0, amp: 0 },
  ach: {},
  seen: {},
  tasks: null,
});
function load() {
  try {
    const base = defaults(),
      raw = wx.getStorageSync(KEY);
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return base;
    const result = Object.assign(base, raw);
    for (const k of ['stars', 'best', 'ach', 'seen'])
      if (!result[k] || typeof result[k] !== 'object' || Array.isArray(result[k])) result[k] = {};
    result.stat = Object.assign({ clear: 0, par: 0, amp: 0 }, raw.stat && typeof raw.stat === 'object' ? raw.stat : {});
    if (!Number.isFinite(result.coins) || result.coins < 0) result.coins = 200;
    if (!Number.isInteger(result.ch) || result.ch < 0 || result.ch >= CFG.CHAPTERS.length) result.ch = 0;
    return result;
  } catch (e) {
    return defaults();
  }
}
const state = load();
let dirty = false;
let timer = null;
function flush() {
  if (timer !== null) clearTimeout(timer);
  timer = null;
  if (!dirty) return true;
  try {
    wx.setStorageSync(KEY, state);
    dirty = false;
    return true;
  } catch (e) {
    // Keep dirty state; the next save or lifecycle boundary retries the write.
    return false;
  }
}
function save() {
  dirty = true;
  if (timer !== null) clearTimeout(timer);
  timer = setTimeout(flush, 1000);
}
module.exports = { state, save, flush };
