const { DPR } = require('./canvas'),
  events = require('./events'),
  notice = require('./notice');
let button = null,
  signature = '',
  failed = false,
  simulated;
function destroy() {
  const old = button;
  button = null;
  signature = '';
  try {
    if (old) old.destroy();
  } catch (e) {}
}
function simulator() {
  if (simulated === undefined) {
    try {
      const getInfo = wx.getDeviceInfo || wx.getSystemInfoSync;
      simulated = typeof getInfo === 'function' && getInfo.call(wx).platform === 'devtools';
    } catch (e) {
      simulated = false;
    }
  }
  return simulated;
}
function available() {
  // Avoid the native overlay while missing simulator touch delivery is investigated.
  // Keep the official native flow on phones; use an operable explanation in devtools.
  return !simulator() && !failed && typeof wx.createFeedbackButton === 'function';
}
function sync(rect) {
  if (!rect || !available()) {
    destroy();
    return;
  }
  const key = JSON.stringify([rect.x, rect.y, rect.w, rect.h]);
  if (button && signature === key) return;
  destroy();
  // Official minigame API, checked 2026-10-30. Coordinates use logical pixels.
  // https://developers.weixin.qq.com/minigame/dev/api/open-api/feedback/wx.createFeedbackButton.html
  try {
    button = wx.createFeedbackButton({
      type: 'text',
      text: '打开微信反馈',
      style: {
        left: rect.x / DPR,
        top: rect.y / DPR,
        width: rect.w / DPR,
        height: rect.h / DPR,
        backgroundColor: '#ffcd75',
        color: '#1a1c2c',
        fontSize: 18,
        lineHeight: rect.h / DPR,
        textAlign: 'center',
        borderColor: '#1a1c2c',
        borderWidth: 2,
        borderRadius: 0,
      },
    });
    if (!button || typeof button.destroy !== 'function') throw Error('Feedback unavailable');
    signature = key;
    if (typeof button.show === 'function') button.show();
  } catch (e) {
    failed = true;
    destroy();
    events.emit('invalidate');
  }
}
function fallback() {
  notice.open({
    title: '反馈方式',
    lines: [
      simulator() ? '请在手机微信扫码预览后打开反馈。' : '当前环境暂不支持微信反馈入口。',
      '反馈联系方式：需用户提供。',
      '可先记录关卡编号、问题步骤与截图。',
      '请勿包含密码、手机号等个人信息。',
    ],
  });
}
events.on('scene_change', destroy);
module.exports = { sync, destroy, available, fallback };
