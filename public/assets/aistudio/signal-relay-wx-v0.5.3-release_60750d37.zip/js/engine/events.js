// Small local event bus: listeners cannot interrupt rewards or other subscribers.
const listeners = new Map();
function on(name, listener) {
  let group = listeners.get(name);
  if (!group) {
    group = new Set();
    listeners.set(name, group);
  }
  group.add(listener);
  return () => {
    group.delete(listener);
    if (!group.size && listeners.get(name) === group) listeners.delete(name);
  };
}
function emit(name, value) {
  for (const listener of Array.from(listeners.get(name) || [])) {
    try {
      listener(value);
    } catch (e) {
      console.warn('Event listener failed: ' + name, e);
    }
  }
}
module.exports = { on, emit };
