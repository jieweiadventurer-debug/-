const store = require('./storage'),
  progress = require('./progress'),
  runs = require('./runs');
const pool = require('../data/daily-levels'),
  CFG = require('../data/config');
function day() {
  return progress
    .day()
    .split('-')
    .map((n, i) => (i ? String(n).padStart(2, '0') : n))
    .join('-');
}
function history() {
  const raw = store.state.dailyHistory;
  return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
}
function current() {
  progress.sync();
  const date = day();
  let seed = 2166136261;
  for (const ch of date) {
    seed ^= ch.charCodeAt(0);
    seed = Math.imul(seed, 16777619) >>> 0;
  }
  const level = pool[seed % pool.length],
    record = history()[date];
  return { day: date, level, rewarded: !!(record && record.rewarded === true), blocked: progress.clock().blocked };
}
function readRun(level, date) {
  const raw = store.state.dailyRun;
  if (!raw || raw.day !== date || raw.levelId !== level.id) return null;
  return runs.read(level, raw.run || null);
}
function saveRun(level, date, data) {
  if (date !== day()) return;
  store.state.dailyRun = { day: date, levelId: level.id, run: runs.encode(level, data) };
  store.save();
}
function clearRun(level, date) {
  const raw = store.state.dailyRun;
  if (raw && raw.day === date && raw.levelId === level.id) {
    delete store.state.dailyRun;
    store.save();
    store.flush();
  }
}
function complete(level, date, stars, sec) {
  if (!Number.isInteger(stars) || stars < 1 || stars > 3 || !Number.isFinite(sec) || sec < 0) return 0;
  const today = current();
  if (today.blocked || today.day !== date || today.level.id !== level.id) return 0;
  const all = history(),
    old = all[date],
    reward = old && old.rewarded === true ? 0 : CFG.DAILY_REWARD;
  all[date] = {
    levelId: level.id,
    rewarded: true,
    stars: Math.max(old && Number.isInteger(old.stars) ? old.stars : 0, stars),
    sec: old && Number.isFinite(old.sec) ? Math.min(old.sec, sec) : sec,
  };
  for (const key of Object.keys(all).sort().slice(0, -60)) delete all[key];
  store.state.dailyHistory = all;
  store.state.coins += reward;
  store.save();
  store.flush();
  return reward;
}
function rewardNote(date, reward) {
  if (reward) return '今日奖励已领取，再练不会重复发放';
  if (progress.clock().blocked) return '设备时间异常，本次仅作练习';
  if (date !== day()) return '题目已跨日，返回每日挑战查看今日题';
  return '今日奖励已领取，本次不重复发放';
}
function bestSec(date, fallback) {
  const record = history()[date];
  return record && Number.isFinite(record.sec) ? record.sec : fallback;
}
module.exports = { day, current, readRun, saveRun, clearRun, complete, rewardNote, bestSec };
