const store = require('./storage');
let defaultLarge;
function systemDefault() {
  if (defaultLarge !== undefined) return defaultLarge;
  // Checked 2026-10-30 in official minigame-api-typings: fontSizeSetting, reference size 16.
  // https://developers.weixin.qq.com/minigame/dev/api/base/system/wx.getAppBaseInfo.html
  let size = 16;
  try {
    const api = wx.getAppBaseInfo || wx.getSystemInfoSync,
      info = typeof api === 'function' && api.call(wx);
    if (info && Number.isFinite(info.fontSizeSetting)) size = info.fontSizeSetting;
  } catch (e) {}
  defaultLarge = size >= 20;
  return defaultLarge;
}
function enabled() {
  const s = store.state.settings;
  return s && typeof s.largeText === 'boolean' ? s.largeText : systemDefault();
}
function settings() {
  return {
    ...store.state.settings,
    largeText: enabled(),
    highContrast: !!(store.state.settings && store.state.settings.highContrast === true),
  };
}
function set(key, value) {
  const s = store.state.settings || (store.state.settings = {});
  s[key] = !!value;
}
const colors = {
  '#94b0c2': '#ffffff',
  '#b5c9d6': '#ffffff',
  '#b3b9d1': '#ffffff',
  '#f4f4f4': '#ffffff',
  '#333c57': '#101827',
  '#73464c': '#1a1c2c',
};
function color(value) {
  return store.state.settings && store.state.settings.highContrast === true ? colors[value] || value : value;
}
module.exports = { settings, set, color, enabled };
