// Canvas overlays share input and pause handling; no native dialog dependency.
const { W, H, DPR, contentTop, safeBottom } = require('./canvas');
const ui = require('./ui');
const accessible = require('./accessibility-preferences');
let page = 0;
let model = null,
  hooks = {};
function configure(value) {
  hooks = value;
}
function open(value) {
  const first = !model;
  model = value;
  page = 0;
  if (first && hooks.pause) hooks.pause();
  if (hooks.invalidate) hooks.invalidate();
}
function close(resume = true) {
  if (!model) return;
  model = null;
  if (resume && hooks.resume) hooks.resume();
  if (hooks.invalidate) hooks.invalidate();
}
function layout() {
  const h = Math.min(340 * DPR, H - safeBottom - contentTop - 12 * DPR);
  return { x: W * 0.06, y: contentTop + (H - safeBottom - contentTop - h) / 2, w: W * 0.88, h };
}
function lines() {
  if (!model) return [];
  if (!accessible.enabled()) return model.lines || [];
  const count = Math.max(4, Math.floor((layout().w - 32 * DPR) / (16 * DPR)) * 2),
    result = [];
  for (const text of model.lines || []) {
    const chars = Array.from(String(text));
    for (let i = 0; i < chars.length; i += count) result.push(chars.slice(i, i + count).join(''));
  }
  return result;
}
function buttons() {
  if (!model) return [];
  const m = layout(),
    actions = model.actions || [{ label: '知道了' }],
    gap = 8 * DPR;
  const w = (m.w - 32 * DPR - gap * (actions.length - 1)) / actions.length;
  const result = actions.map((a, i) => ({
    ...a,
    x: m.x + 16 * DPR + i * (w + gap),
    y: m.y + m.h - 60 * DPR,
    w,
    h: 44 * DPR,
    fs: accessible.enabled() ? 16 * DPR : undefined,
  }));
  if (accessible.enabled() && lines().length > 3) {
    const pages = Math.ceil(lines().length / 3);
    result.push({
      label: '下一段 ' + (page + 1) + '/' + pages,
      x: m.x + 16 * DPR,
      y: m.y + 212 * DPR,
      w: m.w - 32 * DPR,
      h: 44 * DPR,
      fs: 16 * DPR,
      keep: true,
      run: () => {
        page = (page + 1) % pages;
        if (hooks.invalidate) hooks.invalidate();
      },
    });
  }
  return result;
}
function draw(g) {
  if (!model) return;
  const m = layout();
  g.fillStyle = 'rgba(10,10,20,.88)';
  g.fillRect(0, 0, W, H);
  ui.panel(g, m.x, m.y, m.w, m.h, 2 * DPR);
  ui.text(g, model.title, W / 2, m.y + 30 * DPR, 20 * DPR, '#ffcd75');
  const large = accessible.enabled(),
    body = large ? lines().slice(page * 3, page * 3 + 3) : lines();
  body.forEach((line, i) =>
    ui.wrapped(g, line, W / 2, m.y + (76 + i * (large ? 44 : 36)) * DPR, m.w - 32 * DPR, (large ? 16 : 12) * DPR, '#f4f4f4'),
  );
  buttons().forEach((b) => ui.btn(g, b, 2 * DPR));
}
const surface = {
  onTap(x, y) {
    const b = ui.hit(buttons(), x, y);
    if (!b) return;
    if (!b.keep) close();
    if (b.run) b.run();
  },
  onLong: () => false,
};
module.exports = { configure, open, close, layout, buttons, draw, surface, isOpen: () => !!model };
