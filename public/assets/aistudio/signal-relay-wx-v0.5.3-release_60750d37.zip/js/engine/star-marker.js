const { bake } = require('../data/sprites');
// Large centered silhouette stays behind pipes, so it never turns into a tiny badge.
function draw(g, x, y, cs, occupied, collected) {
  const size = Math.min(cs, 8 * Math.max(1, Math.floor((cs * 0.92) / 8)));
  const smoothing = g.imageSmoothingEnabled;
  g.imageSmoothingEnabled = false;
  g.drawImage(bake('starPoint', 1, !collected), Math.round(x + (cs - size) / 2), Math.round(y + (cs - size) / 2), size, size);
  g.imageSmoothingEnabled = smoothing;
}
module.exports = { draw };
