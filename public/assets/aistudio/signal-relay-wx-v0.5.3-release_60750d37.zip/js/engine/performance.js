const store = require('./storage');
const events = require('./events');
const ui = require('./ui');
let visible = false,
  taps = 0,
  lastTap = -Infinity,
  lastHud = -Infinity;
let clock = Date.now,
  collecting = false,
  calls = 0,
  started = 0,
  exact = true;
let previousDemand = false,
  windowMs = 0,
  windowFrames = 0,
  fps = null;
let lastCalls = 0,
  bytes = 0,
  lastSize = -Infinity;
const costs = [],
  intervals = [];
const settings = () => store.state.settings || (store.state.settings = {});
function attach(g) {
  // Checked 2026-10-30 in official minigame-api-typings; now() measures elapsed milliseconds.
  // https://developers.weixin.qq.com/minigame/dev/api/base/performance/wx.getPerformance.html
  try {
    const p = typeof wx.getPerformance === 'function' && wx.getPerformance();
    if (p && typeof p.now === 'function') clock = () => p.now();
  } catch (e) {}
  for (const name of ['clearRect', 'fillRect', 'strokeRect', 'fillText', 'strokeText', 'drawImage', 'fill', 'stroke', 'putImageData']) {
    try {
      const original = g[name];
      if (typeof original !== 'function') continue;
      const wrapped = function (...args) {
        if (collecting) calls++;
        return original.apply(this, args);
      };
      g[name] = wrapped;
      if (g[name] !== wrapped) exact = false;
    } catch (e) {
      exact = false;
    }
  }
}
function setLowEffects(value) {
  settings().lowEffects = !!value;
  store.save();
  events.emit('invalidate');
}
function degrade() {
  if (settings().lowEffects) return;
  settings().lowEffects = true;
  settings().flow = 30;
  store.save();
  events.emit('invalidate');
}
function observe(dt, demand) {
  if (!demand || !previousDemand || !Number.isFinite(dt) || dt <= 0 || dt > 1000) {
    windowMs = 0;
    windowFrames = 0;
    if (!demand) {
      intervals.length = 0;
      fps = null;
    }
    previousDemand = !!demand;
    return;
  }
  intervals.push(dt);
  if (intervals.length > 60) intervals.shift();
  fps = (intervals.length * 1000) / intervals.reduce((a, b) => a + b, 0);
  windowMs += dt;
  windowFrames++;
  if (windowMs >= 2000) {
    if ((windowFrames * 1000) / windowMs < 40) degrade();
    windowMs = 0;
    windowFrames = 0;
  }
}
function readClock() {
  try {
    const value = clock();
    return Number.isFinite(value) ? value : Date.now();
  } catch (e) {
    return Date.now();
  }
}
function begin() {
  calls = 0;
  started = readClock();
  collecting = true;
}
function end() {
  collecting = false;
  lastCalls = calls;
  const cost = Math.max(0, readClock() - started);
  if (Number.isFinite(cost)) {
    costs.push(cost);
    if (costs.length > 60) costs.shift();
  }
}
function storageBytes() {
  let count = 0;
  try {
    for (const ch of JSON.stringify(store.state)) {
      const n = ch.codePointAt(0);
      count += n <= 0x7f ? 1 : n <= 0x7ff ? 2 : n <= 0xffff ? 3 : 4;
    }
  } catch (e) {}
  return count;
}
function snapshot(now = Date.now()) {
  if (now - lastSize >= 1000 || now < lastSize) {
    bytes = storageBytes();
    lastSize = now;
  }
  return {
    fps,
    calls: exact ? lastCalls : null,
    slowestMs: Math.max(0, ...costs),
    storageBytes: bytes,
    lowEffects: !!settings().lowEffects,
    visible,
  };
}
function tapVersion(now = Date.now()) {
  taps = now - lastTap <= 2000 && now >= lastTap ? taps + 1 : 1;
  lastTap = now;
  if (taps >= 5) {
    visible = !visible;
    taps = 0;
    events.emit('invalidate');
  }
}
function draw(g, { W, DPR, contentTop }) {
  if (!visible) return;
  lastHud = Date.now();
  const s = snapshot(),
    x = W * 0.05,
    y = contentTop + 44 * DPR,
    w = W * 0.9;
  ui.panel(g, x, y, w, 132 * DPR, 2 * DPR);
  const lines = [
    '调试面板 · 版本连点五次关闭',
    'FPS ' + (s.fps === null ? '静止/等待动画' : s.fps.toFixed(1)) + ' · 绘制 ' + (s.calls === null ? '不可计数' : s.calls) + ' 次',
    '60帧绘制最慢 ' + s.slowestMs.toFixed(2) + ' ms',
    '存档 ' + (s.storageBytes / 1024).toFixed(1) + ' KiB · 装饰' + (s.lowEffects ? '精简' : '完整'),
    '仅运行时观测 · 不含调试面板绘制',
  ];
  lines.forEach((line, i) => ui.text(g, line, W / 2, y + (20 + i * 23) * DPR, i ? 11 * DPR : 12 * DPR, i ? '#f4f4f4' : '#ffcd75'));
}
module.exports = {
  attach,
  observe,
  begin,
  end,
  draw,
  snapshot,
  setLowEffects,
  tapVersion,
  needsFrame: (now) => visible && (now - lastHud >= 200 || now < lastHud),
  isVisible: () => visible,
};
