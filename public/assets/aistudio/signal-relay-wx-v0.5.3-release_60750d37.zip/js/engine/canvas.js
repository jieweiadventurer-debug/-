// 主画布与像素单位。第一次 wx.createCanvas() 得到的就是主屏画布
const sys = wx.getSystemInfoSync();
const canvas = wx.createCanvas();
const ctx = canvas.getContext('2d');
const DPR = sys.pixelRatio || 1;
canvas.width = Math.round(sys.windowWidth * DPR);
canvas.height = Math.round(sys.windowHeight * DPR);
const W = canvas.width,
  H = canvas.height;
// 每个「游戏像素」占多少设备像素，保证 cols 列棋盘（16 单位一格）整数放大
const unitFor = (cols) => Math.max(2, Math.floor((W * 0.92) / (cols * 16)));
const safeTop = ((sys.safeArea && sys.safeArea.top) || 0) * DPR;
let menu = null;
try {
  if (wx.getMenuButtonBoundingClientRect) menu = wx.getMenuButtonBoundingClientRect();
} catch (e) {}
const menuBottom = menu && Number.isFinite(menu.bottom) ? menu.bottom * DPR : safeTop + 36 * DPR;
const contentTop = Math.max(safeTop, menuBottom) + 12 * DPR;
const safeBottom = Math.max(16 * DPR, sys.safeArea && Number.isFinite(sys.safeArea.bottom) ? H - sys.safeArea.bottom * DPR : 0);
module.exports = { canvas, ctx, DPR, W, H, unitFor, safeTop, contentTop, safeBottom };
