const store = require('./storage');
const CFG = require('../data/config');
const LV = require('../data/levels');
const runs = require('./runs');
const events = require('./events');
const S = store.state;
let checkpoint = -Infinity;
function clock(raw = Date.now()) {
  const previous = Number.isFinite(S.lastSeenTime) ? S.lastSeenTime : raw;
  S.lastSeenTime = Math.max(previous, raw);
  return { now: S.lastSeenTime, blocked: raw < previous - 5 * 60000 };
}
const day = (now = clock().now) => {
  const d = new Date(now);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};
function sync(raw = Date.now()) {
  const { now, blocked } = clock(raw);
  if (now - checkpoint >= 60000) {
    checkpoint = now;
    store.save();
  }
  const previousEnergy = S.energy;
  if (!Number.isFinite(S.energy)) S.energy = CFG.MAXE;
  S.energy = Math.max(0, Math.min(CFG.MAXE, S.energy));
  if (!Number.isFinite(S.et) || S.et > now) S.et = now;
  if (S.energy >= CFG.MAXE) S.et = now;
  else if (!blocked) {
    const n = Math.floor((now - S.et) / CFG.ENERGY_MS);
    if (n > 0) {
      S.energy = Math.min(CFG.MAXE, S.energy + n);
      S.et = S.energy === CFG.MAXE ? now : S.et + n * CFG.ENERGY_MS;
    }
  }
  if (!S.tasks || (!blocked && S.tasks.day !== day(now))) S.tasks = { day: day(now), clear: 0, par: 0, claimed: {} };
  if (!S.settings || typeof S.settings !== 'object') S.settings = {};
  if (typeof S.settings.reduceMotion !== 'boolean') S.settings.reduceMotion = false;
  if (typeof S.settings.sound !== 'boolean') S.settings.sound = true;
  if (!['low', 'mid', 'high'].includes(S.settings.volumeLevel)) S.settings.volumeLevel = 'mid';
  if (typeof S.settings.vibration !== 'boolean') S.settings.vibration = true;
  if (![30, 60, 120].includes(S.settings.flow)) S.settings.flow = 60;
  if (!S.tasks.claimed || typeof S.tasks.claimed !== 'object') S.tasks.claimed = {};
  for (const k of ['clear', 'par']) if (!Number.isFinite(S.tasks[k])) S.tasks[k] = 0;
  if (S.energy !== previousEnergy) {
    store.save();
    store.flush();
  }
  return S;
}
function spend() {
  sync();
  if (S.energy <= 0) return false;
  if (S.energy === CFG.MAXE) S.et = clock().now;
  S.energy--;
  store.save();
  store.flush();
  return true;
}
function buy() {
  sync();
  if (S.energy >= CFG.MAXE) return '体力已满';
  if (S.coins < 50) return '金币不足';
  S.coins -= 50;
  S.energy = Math.min(CFG.MAXE, S.energy + 5);
  store.save();
  store.flush();
  return '兑换成功，体力 +5';
}
function sign() {
  sync();
  if (clock().blocked) return '设备时间异常，请恢复时间后再签到';
  if (S.signDay === day()) return '今天已经签到';
  S.signDay = day();
  S.coins += 100;
  store.save();
  store.flush();
  return '签到成功，金币 +100';
}
const tasks = [
  { id: 'clear', title: '每日连接', goal: 3, reward: 100 },
  { id: 'par', title: '精打细算', goal: 2, reward: 80 },
];
function claimTask(id) {
  sync();
  if (clock().blocked) return false;
  const t = tasks.find((t) => t.id === id);
  if (!t || S.tasks.claimed[id] || S.tasks[id] < t.goal) return false;
  S.tasks.claimed[id] = true;
  S.coins += t.reward;
  store.save();
  store.flush();
  return true;
}
const achievements = [
  { id: 'first', title: '初次点亮', goal: 1, reward: 100, value: () => Object.keys(S.stars).length },
  { id: 'ten', title: '接力达人', goal: 10, reward: 300, value: () => Object.keys(S.stars).length },
  { id: 'stars', title: '星光收藏家', goal: 30, reward: 300, value: () => Object.values(S.stars).reduce((a, b) => a + b, 0) },
];
function claimAchievement(id) {
  const a = achievements.find((a) => a.id === id);
  if (!a || S.ach[id] || a.value() < a.goal) return false;
  S.ach[id] = true;
  S.coins += a.reward;
  store.save();
  store.flush();
  return true;
}
function cleared(id, stars, sec, par) {
  sync();
  const old = S.stars[id] || 0;
  S.stars[id] = Math.max(old, stars);
  const reward = old === 0 ? 200 : stars > old ? 50 : 0;
  S.coins += reward;
  S.stat.clear++;
  if (par) S.stat.par++;
  S.tasks.clear++;
  if (par) S.tasks.par++;
  const best = S.best[id];
  if (!best || sec < best.sec) S.best[id] = { sec };
  store.save();
  store.flush();
  events.emit('cleared', { id, stars: S.stars[id], sec, reward });
  return reward;
}
function remaining() {
  sync();
  return S.energy >= CFG.MAXE ? 0 : Math.max(0, CFG.ENERGY_MS - (clock().now - S.et));
}
function enterLevel(i) {
  const level = LV[i];
  return !!runs.read(level) || spend();
}
module.exports = { sync, spend, enterLevel, buy, sign, tasks, claimTask, achievements, claimAchievement, cleared, remaining, day, clock };
