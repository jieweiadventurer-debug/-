const store = require('./storage');
const LV = require('../data/levels');
const events = require('./events');
const analytics = require('./analytics');
let timelineLevel = null,
  timelinePlatform;
events.on('scene_change', () => {
  timelineLevel = null;
});
events.on('cleared', () => upload());
const SCORE_KEY = 'sr_score_v1';
let initialized = false,
  invite = null;
function readInvite(options) {
  const q = options && options.query;
  if (q && ['share', 'timeline'].includes(q.from) && LV.some((l) => l.id === q.level)) invite = q.level;
}
function consumeInvite() {
  const value = invite;
  invite = null;
  return value;
}
function shareOptions(level) {
  return {
    title: level ? '我接通了第 ' + level + ' 关，来试试你的接力路线！' : '信号接力：把每一束光送到同色终点',
    imageUrl: 'images/share-card.png',
    query: 'from=share' + (level ? '&level=' + encodeURIComponent(level) : ''),
  };
}
function init() {
  if (initialized) return;
  initialized = true;
  try {
    if (wx.getLaunchOptionsSync) readInvite(wx.getLaunchOptionsSync());
    if (wx.onShow) wx.onShow(readInvite);
    if (wx.showShareMenu) wx.showShareMenu({ menus: timelineAvailable() ? ['shareAppMessage', 'shareTimeline'] : ['shareAppMessage'] });
    if (wx.onShareAppMessage) wx.onShareAppMessage(() => shareOptions());
    if (timelineAvailable())
      wx.onShareTimeline(() => {
        analytics.track('share');
        return timelineOptions();
      });
  } catch (e) {}
}
function share(level) {
  init();
  if (!wx.shareAppMessage) return false;
  try {
    wx.shareAppMessage(shareOptions(level));
    analytics.track('share');
    return true;
  } catch (e) {
    return false;
  }
}
function timelineAvailable() {
  // Checked 2026-10-30: official minigame-api-typings marks this API Android-only Beta.
  // https://developers.weixin.qq.com/minigame/dev/api/share/wx.onShareTimeline.html
  // https://developers.weixin.qq.com/minigame/dev/api/share/wx.showShareMenu.html
  if (typeof wx.onShareTimeline !== 'function' || typeof wx.showShareMenu !== 'function') return false;
  if (timelinePlatform === undefined) {
    try {
      const api = wx.getDeviceInfo || wx.getSystemInfoSync,
        info = typeof api === 'function' && api.call(wx);
      timelinePlatform = (info && info.platform) || 'unknown';
    } catch (e) {
      timelinePlatform = 'unknown';
    }
  }
  return timelinePlatform === 'android';
}
function timelineOptions() {
  const options = shareOptions(timelineLevel);
  options.query = 'from=timeline' + (timelineLevel ? '&level=' + encodeURIComponent(timelineLevel) : '');
  return options;
}
function prepareTimeline(level) {
  if (!timelineAvailable()) return false;
  init();
  timelineLevel = LV.some((l) => l.id === level) ? level : null;
  try {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  } catch (e) {
    events.emit('notice', { title: '暂时无法分享', lines: ['请稍后在微信右上角菜单重试。'] });
    return false;
  }
  events.emit('notice', {
    title: '分享到朋友圈',
    lines: ['分享内容已准备好。', '点击右上角“···”，选择“分享到朋友圈”。', '分享不发放游戏奖励，也不影响通关。'],
  });
  return true;
}
function score() {
  const stars = LV.map((l) => store.state.stars[l.id]).reduce((n, s) => n + (Number.isInteger(s) && s >= 1 && s <= 3 ? s : 0), 0),
    cleared = LV.map((l) => store.state.stars[l.id]).filter((s) => Number.isInteger(s) && s >= 1 && s <= 3).length;
  return { v: 1, stars, cleared, updatedAt: Date.now() };
}
function upload(done = () => {}) {
  if (!store.state.socialEnabled || !wx.setUserCloudStorage) {
    done(false);
    return;
  }
  let settled = false;
  const timer = setTimeout(() => finish(false), 10000);
  function finish(ok) {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    done(ok);
  }
  try {
    wx.setUserCloudStorage({
      KVDataList: [{ key: SCORE_KEY, value: JSON.stringify(score()) }],
      success: () => finish(true),
      fail: () => finish(false),
    });
  } catch (e) {
    finish(false);
  }
}
module.exports = {
  init,
  readInvite,
  consumeInvite,
  share,
  shareOptions,
  score,
  upload,
  SCORE_KEY,
  timelineAvailable,
  timelineOptions,
  prepareTimeline,
};
