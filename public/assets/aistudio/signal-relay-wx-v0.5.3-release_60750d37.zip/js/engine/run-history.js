// Undo entries store one changed cell and the inverse inventory delta.
const copy = (v) => JSON.parse(JSON.stringify(v));
function capture(board, inv, r, c) {
  return { r, c, p: board[r][c] ? { ...board[r][c] } : null, i: { ...inv } };
}
function seal(entry, inv) {
  if (!entry || !entry.i) return;
  entry.d = {};
  for (const t of ['s', 'c', 't', 'a']) {
    const delta = entry.i[t] - inv[t];
    if (delta) entry.d[t] = delta;
  }
  delete entry.i;
}
function undo(board, inv, entry) {
  if (!entry || !Number.isInteger(entry.r) || !Number.isInteger(entry.c)) throw Error('Invalid undo cell');
  if (!board[entry.r] || entry.c < 0 || entry.c >= board[entry.r].length || !entry.d) throw Error('Invalid undo');
  if (Object.keys(entry.d).some((t) => !['s', 'c', 't', 'a'].includes(t) || !Number.isInteger(entry.d[t])))
    throw Error('Invalid inventory delta');
  board[entry.r][entry.c] = entry.p === null ? null : { ...entry.p };
  for (const [t, delta] of Object.entries(entry.d)) inv[t] += delta;
}
function migrate(hist, board, inv, valid) {
  const b = copy(board),
    i = { ...inv },
    result = [];
  for (let n = hist.length - 1; n >= 0; n--) {
    const old = JSON.parse(hist[n]);
    if (!valid(old.b, old.i)) throw Error('Invalid legacy state');
    const changed = [];
    b.forEach((row, r) =>
      row.forEach((p, c) => {
        if (JSON.stringify(p) !== JSON.stringify(old.b[r][c])) changed.push([r, c]);
      }),
    );
    if (changed.length !== 1) throw Error('Legacy history is not a single-cell change');
    const [r, c] = changed[0],
      entry = capture(old.b, old.i, r, c);
    seal(entry, i);
    result.unshift(entry);
    undo(b, i, entry);
  }
  return result;
}
module.exports = { capture, seal, undo, migrate };
