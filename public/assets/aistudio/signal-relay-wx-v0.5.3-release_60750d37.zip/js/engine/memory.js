const sprites = require('../data/sprites'),
  accessibility = require('./accessibility'),
  ui = require('./ui');
const music = require('./music'),
  events = require('./events'),
  analytics = require('./analytics');
let initialized = false,
  reported = false;
function release() {
  sprites.clearCache();
  accessibility.release();
  ui.clearCaches();
  music.release();
  events.emit('memory_warning');
  events.emit('invalidate');
  if (!reported && analytics.enabled()) {
    reported = true;
    analytics.track('memory_warning');
  }
}
function init() {
  if (initialized) return;
  initialized = true;
  // Checked 2026-10-30: official minigame-api-typings, available since 2.0.2.
  // https://developers.weixin.qq.com/minigame/dev/api/device/memory/wx.onMemoryWarning.html
  if (typeof wx.onMemoryWarning === 'function') {
    try {
      wx.onMemoryWarning(release);
    } catch (e) {}
  }
}
module.exports = { init, release };
