const { ctx, W, H, DPR, contentTop } = require('./canvas');
const store = require('./storage');
const notice = require('./notice');
const wellbeing = require('./wellbeing');
const updates = require('./updates');
const events = require('./events');
const perf = require('./performance');
const accessibility = require('./accessibility');
perf.attach(ctx);
events.on('invalidate', () => invalidate());
events.on('notice', (value) => notice.open(value));
const scenes = {};
let current = null,
  currentName = '',
  last = Date.now(),
  dirty = true,
  continuousUntil = 0,
  wasAnimating = false,
  nextWake = Infinity,
  active = true,
  running = false;
const register = (name, scene) => {
  scenes[name] = scene;
};
function invalidate(ms = 0) {
  dirty = true;
  if (Number.isFinite(ms) && ms > 0) continuousUntil = Math.max(continuousUntil, Date.now() + ms);
}
const go = (name, arg) => {
  events.emit('scene_change');
  notice.close(false);
  updates.offer(false);
  if (current && current.leave) current.leave();
  store.flush();
  current = scenes[name];
  currentName = name;
  accessibility.reset(current);
  continuousUntil = 0;
  wasAnimating = false;
  nextWake = Infinity;
  if (current.enter) current.enter(arg);
  store.flush();
  invalidate();
};
const cur = () => (notice.isOpen() ? notice.surface : current && accessibility.enabled() ? accessibility.surface(current) : current);
notice.configure({
  invalidate,
  pause: () => {
    if (current && current.pause) current.pause();
  },
  resume: () => {
    if (active && current && current.resume) current.resume();
  },
});
function setActive(value) {
  active = !!value;
  perf.observe(0, false);
  last = Date.now();
  if (active) invalidate();
}
// Explicit frame() remains a forced inspection render; the rAF loop uses frame(false).
function frame(force = true) {
  const now = Date.now(),
    dt = now - last;
  last = now;
  if (!active) return false;
  wellbeing.tick(dt, current === scenes.game && !current.won);
  updates.offer(current === scenes.home || !!(current && current.canUpdate && current.canUpdate(now)));
  const animating = !!(current && current.animating && current.animating(now));
  perf.observe(dt, (animating || now < continuousUntil) && !notice.isOpen());
  const draw = force || dirty || animating || wasAnimating || now >= nextWake || now < continuousUntil || perf.needsFrame(now);
  wasAnimating = animating;
  if (!draw) return false;
  dirty = false;
  perf.begin();
  ctx.clearRect(0, 0, W, H);
  if (current) {
    if (accessibility.enabled()) accessibility.draw(ctx, current, currentName, dt);
    else current.draw(ctx, dt);
  }
  if (current && current.afterDraw) {
    current.afterDraw(notice.isOpen() ? [] : accessibility.enabled() ? accessibility.buttons(current) : null);
  }
  notice.draw(ctx);
  perf.end();
  perf.draw(ctx, { W, DPR, contentTop });
  const deadline = current && current.nextFrameAt ? current.nextFrameAt(now) : Infinity;
  nextWake = Number.isFinite(deadline) && deadline > now ? deadline : Infinity;
  return true;
}
function start() {
  if (running) return;
  running = true;
  last = Date.now();
  (function loop() {
    frame(false);
    requestAnimationFrame(loop);
  })();
}
module.exports = { register, go, cur, frame, start, invalidate, setActive };
