// Warn before a new campaign attempt can displace an unfinished run.
const LV = require('../data/levels'),
  runs = require('./runs'),
  progress = require('./progress');
const notice = require('./notice'),
  events = require('./events');
let pending = null;
events.on('scene_change', () => {
  pending = null;
});
function enter(index, start, exhausted) {
  const level = LV[index];
  if (!level) return false;
  const saved = runs.read(level);
  if (!saved && progress.sync().energy <= 0) {
    exhausted();
    return false;
  }
  const victim = runs.replacement(level);
  if (saved || !victim) {
    if (progress.enterLevel(index)) start();
    else exhausted();
    return true;
  }
  const ticket = {};
  pending = ticket;
  notice.open({
    title: '保存位置已满',
    lines: ['已保存5个未完成关卡。', '继续将替换第 ' + victim + ' 关的未完成进度。', '该关星级与最佳成绩不会受影响。'],
    actions: [
      {
        label: '保留进度',
        run: () => {
          if (pending === ticket) pending = null;
        },
      },
      {
        label: '继续挑战',
        primary: true,
        run: () => {
          if (pending !== ticket) return;
          pending = null;
          if (runs.replacement(level) !== victim) {
            enter(index, start, exhausted);
            return;
          }
          if (progress.enterLevel(index)) start();
          else exhausted();
        },
      },
    ],
  });
  return false;
}
module.exports = { enter };
