// A reward requires the platform's explicit completed-playback callback.
const CFG = require('../data/config'),
  store = require('./storage'),
  progress = require('./progress'),
  analytics = require('./analytics');
let ad = null,
  pending = null,
  serial = 0;
function available() {
  return /^adunit-[A-Za-z0-9_-]+$/.test(CFG.REWARDED_AD_UNIT_ID || '') && typeof wx.createRewardedVideoAd === 'function';
}
function finish(id, code) {
  if (!pending || pending.id !== id) return;
  const p = pending;
  pending = null;
  try {
    if (ad.offClose) ad.offClose(p.close);
    if (ad.offError) ad.offError(p.error);
  } catch (e) {}
  let gained = 0;
  if (code === 'reward') {
    const S = progress.sync();
    gained = Math.min(5, CFG.MAXE - S.energy);
    S.energy += gained;
    if (S.energy === CFG.MAXE) S.et = Date.now();
    store.save();
    store.flush();
  }
  analytics.track('ad_result', { result: code === 'reward' ? 'completed' : code === 'cancelled' ? 'cancelled' : 'error' });
  p.resolve({ code, gained });
}
function watch() {
  if (pending) return Promise.resolve({ code: 'busy', gained: 0 });
  if (progress.sync().energy >= CFG.MAXE) return Promise.resolve({ code: 'full', gained: 0 });
  if (!available()) return Promise.resolve({ code: 'unavailable', gained: 0 });
  try {
    if (!ad) ad = wx.createRewardedVideoAd({ adUnitId: CFG.REWARDED_AD_UNIT_ID });
  } catch (e) {
    ad = null;
    analytics.track('ad_result', { result: 'error' });
    return Promise.resolve({ code: 'error', gained: 0 });
  }
  return new Promise((resolve) => {
    const id = ++serial,
      valid = () => pending && pending.id === id;
    const close = (res) => {
        if (valid() && pending.showing) finish(id, res && res.isEnded === true ? 'reward' : 'cancelled');
      },
      error = () => finish(id, 'error');
    pending = { id, resolve, close, error, showing: true };
    try {
      ad.onClose(close);
      ad.onError(error);
      Promise.resolve()
        .then(() => ad.show())
        .then(() => {
          if (valid()) analytics.track('ad_result', { result: 'shown' });
        })
        .catch(() => {
          if (!valid()) return;
          pending.showing = false;
          return Promise.resolve()
            .then(() => ad.load())
            .then(() => {
              if (valid()) {
                pending.showing = true;
                return Promise.resolve(ad.show()).then(() => {
                  if (valid()) analytics.track('ad_result', { result: 'shown' });
                });
              }
            })
            .catch(() => {
              if (valid()) finish(id, 'error');
            });
        });
    } catch (e) {
      finish(id, 'error');
    }
  });
}
function message(result) {
  return {
    reward: '观看完成，体力 +' + result.gained,
    cancelled: '未完整观看，本次未发放体力',
    error: '广告暂时无法播放，请稍后重试',
    unavailable: '视频补给暂未开放',
    busy: '广告正在加载或播放',
    full: '体力已满',
  }[result.code];
}
module.exports = { available, watch, message };
