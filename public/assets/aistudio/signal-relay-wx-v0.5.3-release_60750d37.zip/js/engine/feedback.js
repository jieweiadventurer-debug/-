const progress = require('./progress');
const volume = require('./volume');
const sounds = {};
const NAMES = ['place', 'rotate', 'win', 'reward', 'sign'];
function createVoice(name) {
  try {
    const audio = wx.createInnerAudioContext();
    // 真机教训：InnerAudioContext 默认 obeyMuteSwitch=true，iPhone 静音拨片开着就全程无声，游戏音效须显式关掉。
    try {
      audio.obeyMuteSwitch = false;
    } catch (e) {}
    const voice = { audio, failed: false, ready: false, wantPlay: false, pendingVolume: 1 };
    if (typeof audio.onError === 'function')
      audio.onError(() => {
        voice.failed = true;
      });
    if (typeof audio.onCanplay === 'function') {
      audio.onCanplay(() => {
        voice.ready = true;
        // 真机教训：刚设 src 同一拍就 play 常被吞（尚未解码），解码就绪后把挂起的第一次播放补上。
        if (voice.wantPlay && !voice.failed) {
          voice.wantPlay = false;
          voice.audio.volume = voice.pendingVolume;
          try {
            voice.audio.play();
          } catch (e) {
            voice.failed = true;
          }
        }
      });
    } else voice.ready = true;
    audio.src = 'audio/' + name + '.wav';
    return voice;
  } catch (e) {
    return null;
  }
}
function poolFor(name) {
  return sounds[name] || (sounds[name] = { voices: [createVoice(name), createVoice(name)].filter(Boolean), next: 0 });
}
function preload() {
  // 启动即预建实例让音频提前解码，避免首个音效与设 src 撞在同一拍。
  NAMES.forEach((name) => poolFor(name));
}
function vibrate(settings) {
  if (!settings.vibration || typeof wx.vibrateShort !== 'function') return;
  try {
    wx.vibrateShort({ type: 'light' });
  } catch (e) {
    /* Unsupported feedback must not block play. */
  }
}
function attempt(voice) {
  try {
    if (typeof voice.audio.seek === 'function') voice.audio.seek(0);
    const result = voice.audio.play();
    if (result && typeof result.catch === 'function')
      result.catch(() => {
        voice.failed = true;
      });
    return true;
  } catch (e) {
    voice.failed = true;
    return false;
  }
}
function play(name) {
  const settings = progress.sync().settings;
  vibrate(settings);
  if (!settings.sound || typeof wx.createInnerAudioContext !== 'function') return;
  const pool = poolFor(name);
  for (let i = 0; i < pool.voices.length; i++) {
    const idx = pool.next++ % pool.voices.length;
    const voice = pool.voices[idx];
    if (voice.failed) continue;
    voice.audio.volume = volume.sfx(settings);
    if (!voice.ready) {
      voice.wantPlay = true;
      voice.pendingVolume = voice.audio.volume;
      return;
    }
    if (attempt(voice)) return;
  }
}
module.exports = { play, preload };
