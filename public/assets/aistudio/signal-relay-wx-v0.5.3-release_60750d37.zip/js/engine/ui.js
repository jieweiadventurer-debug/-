// 极简像素 UI：文字、按钮、点击检测。中文像素字体到位后，在 FONT 里替换
const { DPR } = require('./canvas');
const store = require('./storage');
const accessible = require('./accessibility-preferences');
let touch = null;
const FONT = '"PingFang SC","Microsoft YaHei",sans-serif';
function text(ctx, s, x, y, px, color, align) {
  ctx.font = 'bold ' + Math.round(Math.max(10 * DPR, px)) + 'px ' + FONT;
  ctx.fillStyle = accessible.color(color || '#f4f4f4');
  ctx.textAlign = align || 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(s, x, y);
}
function pressed(b) {
  return !!(touch && touch.x >= b.x && touch.x <= b.x + b.w && touch.y >= b.y && touch.y <= b.y + b.h);
}
function btn(ctx, b, u) {
  const t = Math.max(2, Math.round(2 * DPR)),
    isPressed = pressed(b);
  if (isPressed) b = Object.assign({}, b, { y: b.y + t });
  ctx.fillStyle = '#0b0c15';
  ctx.fillRect(b.x, b.y + t * 2, b.w, b.h);
  ctx.fillStyle = '#1a1c2c';
  ctx.fillRect(b.x, b.y, b.w, b.h);
  ctx.fillStyle = b.primary ? '#ffcd75' : accessible.color('#333c57');
  ctx.fillRect(b.x + t, b.y + t, b.w - 2 * t, b.h - 2 * t);
  text(
    ctx,
    b.label,
    b.x + b.w / 2,
    b.y + b.h / 2,
    Math.min(b.fs || 14 * DPR, (b.w / Math.max(2, String(b.label).length)) * 0.8),
    b.primary ? '#1a1c2c' : '#f4f4f4',
  );
}
const hit = (btns, x, y) => btns.find((b) => !b.hidden && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h);
function background(g, W, H) {
  if (accessible.settings().highContrast) g.fillStyle = '#101827';
  else if (g.createLinearGradient) {
    const grad = g.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#1a1c2c');
    grad.addColorStop(1, '#242d50');
    g.fillStyle = grad;
  } else g.fillStyle = '#1a1c2c';
  g.fillRect(0, 0, W, H);
  if (accessible.settings().highContrast || (store.state.settings && store.state.settings.lowEffects)) return;
  g.fillStyle = 'rgba(255,255,255,.018)';
  const step = Math.max(4, Math.round(W / 50));
  for (let y = 0; y < H; y += step) g.fillRect(0, y, W, step / 2);
}
function panel(g, x, y, w, h, u) {
  g.fillStyle = '#0b0c15';
  g.fillRect(x, y + u * 2, w, h);
  g.fillStyle = '#1a1c2c';
  g.fillRect(x, y, w, h);
  g.fillStyle = accessible.color('#333c57');
  g.fillRect(x + u, y + u, w - u * 2, h - u * 2);
}
let widthCaches = new WeakMap();
function measuredWidth(g, value, size) {
  const font = 'bold ' + Math.round(Math.max(10 * DPR, size)) + 'px ' + FONT;
  g.font = font;
  let cache = widthCaches.get(g);
  if (!cache) {
    cache = new Map();
    widthCaches.set(g, cache);
  }
  const key = font + '\0' + value;
  if (cache.has(key)) return cache.get(key);
  const metrics = g.measureText && g.measureText(value);
  if (!metrics || !Number.isFinite(metrics.width)) return Array.from(value).length * size;
  if (cache.size >= 1024) cache.clear();
  cache.set(key, metrics.width);
  return metrics.width;
}
function wrapped(g, s, x, y, maxWidth, px, color, align) {
  const size = Math.max(11 * DPR, px),
    lines = [];
  let line = '';
  for (const ch of String(s)) {
    const next = line + ch;
    if (measuredWidth(g, next, size) > maxWidth && line) {
      lines.push(line);
      line = ch;
    } else line = next;
  }
  if (line) lines.push(line);
  if (lines.length === 2 && Array.from(lines[1]).length < 4) {
    const first = Array.from(lines[0]),
      second = Array.from(lines[1]);
    const n = 4 - second.length;
    const tail = first.slice(-n).join('') + lines[1];
    if (first.length > n && measuredWidth(g, tail, size) <= maxWidth) {
      lines[1] = tail;
      lines[0] = first.slice(0, -n).join('');
    }
  }
  lines.slice(0, 2).forEach((v, i) => text(g, v, x, y + (i - (Math.min(2, lines.length) - 1) / 2) * size * 1.5, size, color, align));
}

function touchAt(p) {
  touch = p;
}
module.exports = {
  clearCaches: () => {
    widthCaches = new WeakMap();
  },
  pressed,
  wrapped,
  touchAt,
  text,
  btn,
  hit,
  FONT,
  background,
  panel,
};
