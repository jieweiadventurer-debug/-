const notice = require('./notice');
const store = require('./storage');
const events = require('./events');
let manager = null,
  ready = false,
  offered = false,
  initialized = false;
function init() {
  if (initialized) return;
  initialized = true;
  // Checked 2026-10-30 in official minigame-api-typings. WeChat checks/downloads automatically.
  // https://developers.weixin.qq.com/minigame/dev/api/base/update/wx.getUpdateManager.html
  try {
    if (typeof wx.getUpdateManager !== 'function') return;
    manager = wx.getUpdateManager();
    if (manager && typeof manager.onUpdateReady === 'function')
      manager.onUpdateReady(() => {
        ready = true;
        offered = false;
        events.emit('invalidate');
      });
    if (manager && typeof manager.onUpdateFailed === 'function')
      manager.onUpdateFailed(() => {
        ready = false;
      });
  } catch (e) {
    manager = null;
  }
}
function apply() {
  if (!store.flush()) {
    notice.open({ title: '暂未重启', lines: ['最新进度尚未写入本机。', '请稍后返回首页重试。'] });
    return;
  }
  try {
    if (ready && manager && typeof manager.applyUpdate === 'function') {
      manager.applyUpdate();
      return;
    }
  } catch (e) {}
  notice.open({ title: '暂未重启', lines: ['更新暂时无法应用，请稍后重试。'] });
}
function offer(safe) {
  if (!safe) {
    offered = false;
    return;
  }
  if (!ready || offered || notice.isOpen()) return;
  offered = true;
  notice.open({
    title: '新版本已就绪',
    lines: ['这一程已妥善保存。', '可以现在重启，也可以稍后再更新。'],
    actions: [{ label: '稍后' }, { label: '保存并重启', run: apply }],
  });
}
module.exports = { init, offer };
