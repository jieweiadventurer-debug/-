const store = require('./storage');
const notice = require('./notice');
const INTERVAL = 40 * 60 * 1000;
let played = 0;
function enabled() {
  return !store.state.settings || store.state.settings.restReminders !== false;
}
function tick(dt, playing) {
  if (!playing || notice.isOpen() || !Number.isFinite(dt) || dt <= 0) return;
  played += dt;
  if (played < INTERVAL) return;
  played %= INTERVAL;
  if (enabled()) show();
}
function show() {
  notice.open({
    title: '适度游戏提示',
    lines: ['让眼睛休息一下，也让思路换口气。', '进度已保存在本机，随时可以回来。', '提醒期间不计入本关用时。', '提示文案需用户确认'],
    actions: [{ label: '继续接力' }],
  });
}
module.exports = { tick, show, enabled, INTERVAL };
