// Shared badge geometry keeps drawing, icon centering and touch targets aligned.
const { W, DPR, contentTop } = require('./canvas'),
  ui = require('./ui'),
  { SPR, bake } = require('../data/sprites');
function layout() {
  const pad = W * 0.05,
    gap = 8 * DPR,
    w = (W * 0.9 - gap * 2) / 3;
  return ['rank', 'energy', 'coins'].map((id, i) => ({ id: 'hud:' + id, x: pad + i * (w + gap), y: contentTop, w, h: 32 * DPR }));
}
function compact(n) {
  n = Math.max(0, Math.floor(Number(n) || 0));
  if (n >= 1e8) return Math.floor(n / 1e7) / 10 + '亿';
  if (n >= 1e4) return Math.floor(n / 1e3) / 10 + '万';
  return String(n);
}
function icon(g, name, cx, cy, size) {
  const d = SPR[name],
    u = Math.max(1, Math.round(2 * DPR));
  let minX = Infinity,
    minY = Infinity,
    maxX = 0,
    maxY = 0;
  d.r.forEach((row, y) =>
    [...row].forEach((ch, x) => {
      if (ch !== '.') {
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
      }
    }),
  );
  const sw = maxX - minX + 1,
    sh = maxY - minY + 1,
    scale = size / Math.max(sw, sh),
    smoothing = g.imageSmoothingEnabled;
  g.imageSmoothingEnabled = false;
  g.drawImage(
    bake(name, u),
    minX * u,
    minY * u,
    sw * u,
    sh * u,
    Math.round(cx - (sw * scale) / 2),
    Math.round(cy - (sh * scale) / 2),
    sw * scale,
    sh * scale,
  );
  g.imageSmoothingEnabled = smoothing;
}
function draw(g, state) {
  const values = ['Lv.' + (1 + Math.floor(state.stat.clear / 10)), state.energy + '/30', compact(state.coins)],
    names = ['robot', 'bolt', 'coin'];
  layout().forEach((b, i) => {
    ui.btn(g, Object.assign({}, b, { label: '' }), 2 * DPR);
    const size = 18 * DPR,
      gap = 6 * DPR,
      dy = ui.pressed(b) ? Math.max(2, Math.round(2 * DPR)) : 0;
    let fs = 12 * DPR;
    const width = () => {
      g.font = 'bold ' + Math.round(fs) + 'px ' + ui.FONT;
      const m = g.measureText && g.measureText(values[i]);
      return m && Number.isFinite(m.width) ? m.width : values[i].length * fs * 0.65;
    };
    let tw = width();
    while (fs > 10 * DPR && size + gap + tw > b.w - 12 * DPR) {
      fs -= DPR;
      tw = width();
    }
    const x = b.x + (b.w - size - gap - tw) / 2,
      cy = b.y + b.h / 2 + dy;
    icon(g, names[i], x + size / 2, cy, size);
    ui.text(g, values[i], x + size + gap, cy, fs, '#f4f4f4', 'left');
  });
}
module.exports = { layout, draw, icon, compact };
