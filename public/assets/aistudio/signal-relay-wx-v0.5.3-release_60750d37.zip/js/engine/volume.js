// 音量档位：低/中/高，音效与音乐共用一档。默认中：音效 0.6、音乐 0.35（v0.5.3 起音乐素材已归一化增益，乘数同步上调）。
const LEVELS = [
  { id: 'low', label: '低', sfx: 0.3, music: 0.18 },
  { id: 'mid', label: '中', sfx: 0.6, music: 0.35 },
  { id: 'high', label: '高', sfx: 1, music: 0.55 },
];
function current(settings) {
  const id = settings && settings.volumeLevel;
  return LEVELS.find((l) => l.id === id) || LEVELS[1];
}
function cycle(settings) {
  const next = LEVELS[(LEVELS.indexOf(current(settings)) + 1) % LEVELS.length];
  settings.volumeLevel = next.id;
  return next;
}
module.exports = {
  LEVELS,
  current,
  cycle,
  label: (settings) => current(settings).label,
  sfx: (settings) => current(settings).sfx,
  music: (settings) => current(settings).music,
};
