const { DPR } = require('./canvas');
const { cur, invalidate, setActive } = require('./scene-manager');
const ui = require('./ui');
const store = require('./storage');
let press = null;
const clear = () => {
  if (press) clearTimeout(press.timer);
  press = null;
  ui.touchAt(null);
  invalidate();
};
wx.onTouchStart((e) => {
  clear();
  if (!e.touches || e.touches.length !== 1) return;
  const t = e.touches[0],
    scene = cur();
  press = {
    x: (t.clientX === undefined ? t.x : t.clientX) * DPR,
    y: (t.clientY === undefined ? t.y : t.clientY) * DPR,
    long: false,
    scene,
  };
  ui.touchAt(press);
  invalidate(100);
  const p = press;
  p.timer = setTimeout(() => {
    if (press !== p || cur() !== scene) return;
    if (scene && scene.onLong) p.long = scene.onLong(p.x, p.y) !== false;
    invalidate(200);
  }, 450);
});
if (wx.onTouchMove)
  wx.onTouchMove((e) => {
    if (!press || !e.touches || e.touches.length !== 1) {
      clear();
      return;
    }
    const t = e.touches[0],
      x = (t.clientX === undefined ? t.x : t.clientX) * DPR,
      y = (t.clientY === undefined ? t.y : t.clientY) * DPR;
    if (Math.hypot(x - press.x, y - press.y) > 12 * DPR) clear();
  });
wx.onTouchEnd(() => {
  if (!press) return;
  const p = press;
  clear();
  if (!p.long && p.scene === cur() && p.scene && p.scene.onTap) p.scene.onTap(p.x, p.y);
  invalidate(220);
});
if (wx.onTouchCancel) wx.onTouchCancel(clear);
if (wx.onHide)
  wx.onHide(() => {
    clear();
    const s = cur();
    if (s && s.pause) s.pause();
    store.flush();
    setActive(false);
  });
if (wx.onShow)
  wx.onShow(() => {
    const s = cur();
    if (s && s.resume) s.resume();
    setActive(true);
  });
