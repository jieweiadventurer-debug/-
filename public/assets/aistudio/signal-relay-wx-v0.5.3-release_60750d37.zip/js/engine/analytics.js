const store = require('./storage');
const CFG = require('../data/config');
const ids = new Set([...require('../data/levels'), ...require('../data/daily-levels')].map((l) => l.id));
const level = (v) => typeof v === 'string' && ids.has(v);
const num = (v) => Number.isFinite(v) && v >= 0 && v <= 1e9;
const schemas = {
  level_start: { id: level },
  level_win: {
    id: level,
    stars: (v) => [1, 2, 3].includes(v),
    sec: num,
    used: num,
    par: (v) => typeof v === 'boolean',
    undo: num,
    hints: num,
  },
  level_quit: { id: level, sec: num, used: num },
  hint_used: { phase: (v) => [0, 1, 2].includes(v) },
  inspect_used: {},
  practice_enter: { topic: (v) => ['basics', 'colors', 'bridge', 'split', 'range', 'stars'].includes(v) },
  memory_warning: {},
  shop_open: {},
  ad_result: { result: (v) => ['shown', 'completed', 'cancelled', 'error'].includes(v) },
  share: {},
  rank_opt: { on: (v) => typeof v === 'boolean' },
  runtime_error: { kind: (v) => ['runtime', 'promise'].includes(v) },
};
let initialized = false,
  timer = null,
  logger = null;
const queue = [],
  recent = new Map();
function enabled() {
  return (store.state.settings && store.state.settings.analytics === true) || false;
}
function diagnostics() {
  return (store.state.settings && store.state.settings.diagnostics === true) || false;
}
function schedule() {
  if (timer === null && queue.length) timer = setTimeout(flush, 0);
}
function flush() {
  if (timer !== null) clearTimeout(timer);
  timer = null;
  for (const event of queue.splice(0, 4)) {
    try {
      if (enabled() && typeof wx.reportEvent === 'function') wx.reportEvent(event.name, event.data);
    } catch (e) {}
    try {
      if (diagnostics() && logger) {
        const method = event.name === 'runtime_error' ? 'error' : 'info';
        if (typeof logger[method] === 'function') logger[method](event.name, event.data);
      }
    } catch (e) {}
  }
  schedule();
}
function eventData(name, params) {
  try {
    if (!Object.prototype.hasOwnProperty.call(schemas, name) || !params || typeof params !== 'object') return null;
    const schema = schemas[name],
      data = { version: CFG.VERSION };
    for (const key of Object.keys(schema)) {
      const value = params[key];
      if (!schema[key](value)) return null;
      data[key] = value;
    }
    return data;
  } catch (e) {
    return null;
  }
}
function track(name, params = {}) {
  if (!enabled() && !diagnostics()) return false;
  const data = eventData(name, params);
  if (!data) return false;
  const key = name + JSON.stringify(data),
    now = Date.now(),
    previous = recent.get(key);
  if (previous !== undefined && now - previous >= 0 && now - previous < 1000) return false;
  if (recent.size >= 256) recent.clear();
  recent.set(key, now);
  if (queue.length >= 64) queue.shift();
  queue.push({ name, data });
  schedule();
  return true;
}
function init() {
  if (initialized) return;
  initialized = true;
  // Checked 2026-10-30 against official minigame-api-typings (generated from these API pages).
  // https://developers.weixin.qq.com/minigame/dev/api/data-analysis/wx.reportEvent.html
  // https://developers.weixin.qq.com/minigame/dev/api/base/app/app-event/wx.onError.html
  // https://developers.weixin.qq.com/minigame/dev/api/base/app/app-event/wx.onUnhandledRejection.html
  // https://developers.weixin.qq.com/minigame/dev/api/base/debug/wx.getRealtimeLogManager.html
  // Deliberately discard raw error messages/stacks: they can contain identifiers or user data.
  try {
    if (typeof wx.onError === 'function') wx.onError(() => track('runtime_error', { kind: 'runtime' }));
  } catch (e) {}
  try {
    if (typeof wx.onUnhandledRejection === 'function') wx.onUnhandledRejection(() => track('runtime_error', { kind: 'promise' }));
  } catch (e) {}
}
function refreshLogger() {
  queue.length = 0;
  recent.clear();
  if (timer !== null) clearTimeout(timer);
  timer = null;
  logger = null;
  try {
    if (diagnostics() && typeof wx.getRealtimeLogManager === 'function') logger = wx.getRealtimeLogManager();
  } catch (e) {}
}
module.exports = { track, init, flush, enabled, diagnostics, refreshLogger };
