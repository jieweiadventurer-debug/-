const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas');
const { register, go } = require('../engine/scene-manager');
const ui = require('../engine/ui'),
  daily = require('../engine/daily'),
  CFG = require('../data/config');
function buttons() {
  const today = daily.current(),
    saved = daily.readRun(today.level, today.day);
  return [
    { id: 'home', label: '← 首页', x: W * 0.05, y: contentTop, w: 90 * DPR, h: 44 * DPR },
    {
      id: 'start',
      label: saved ? '继续今日挑战' : today.rewarded ? '再练一次' : '开始今日挑战',
      x: W * 0.08,
      y: H - safeBottom - 116 * DPR,
      w: W * 0.84,
      h: 60 * DPR,
      primary: true,
    },
  ];
}
register('daily', {
  nextFrameAt(now) {
    const d = new Date(now);
    d.setHours(24, 0, 0, 0);
    return d.getTime() + 1;
  },
  draw(g) {
    const today = daily.current();
    ui.background(g, W, H);
    ui.text(g, '每日挑战', W / 2, contentTop + 76 * DPR, 28 * DPR, '#ffcd75');
    ui.text(g, today.day, W / 2, contentTop + 116 * DPR, 16 * DPR, '#b5c9d6');
    ui.panel(g, W * 0.06, contentTop + 158 * DPR, W * 0.88, 168 * DPR, 2 * DPR);
    ui.text(g, '每天一题 · 不消耗体力', W / 2, contentTop + 192 * DPR, 18 * DPR, '#f4f4f4');
    ui.text(g, '首次接通 · 金币 +' + CFG.DAILY_REWARD, W / 2, contentTop + 232 * DPR, 18 * DPR, '#ffcd75');
    ui.wrapped(
      g,
      today.blocked ? '设备时间异常，本次仅供练习' : today.rewarded ? '今日奖励已领取，可继续练习' : '接通全部同色目标即可领取',
      W / 2,
      contentTop + 278 * DPR,
      W * 0.78,
      13 * DPR,
      '#b5c9d6',
    );
    buttons().forEach((b) => ui.btn(g, b, 2 * DPR));
    ui.text(g, '每天奖励一次 · 不计主线星数与好友榜', W / 2, H - safeBottom - 30 * DPR, 11 * DPR, '#94b0c2');
  },
  onTap(x, y) {
    const b = ui.hit(buttons(), x, y);
    if (!b) return;
    if (b.id === 'home') go('home');
    else go('game', { daily: true, resume: true });
  },
});
