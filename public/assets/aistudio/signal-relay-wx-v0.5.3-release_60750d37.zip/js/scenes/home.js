const { W, H, safeTop, DPR, contentTop, safeBottom } = require('../engine/canvas');
const { register, go, invalidate } = require('../engine/scene-manager');
const ui = require('../engine/ui');
const { bake } = require('../data/sprites');
const SCN = require('../data/scene');
const store = require('../engine/storage');
const LV = require('../data/levels');
const CFG = require('../data/config');
const S = store.state;
const runs = require('../engine/runs');
const progress = require('../engine/progress');
const ads = require('../engine/ads');
const social = require('../engine/social');
const hud = require('../engine/hud');
const feedback = require('../engine/feedback');
const analytics = require('../engine/analytics');
const daily = require('../engine/daily');
const entry = require('../engine/level-entry');
let resumeIndex = -1;
let btns = [],
  layers = {},
  su,
  sx,
  sy,
  modal = null;
require('../engine/events').on('memory_warning', () => {
  for (const c of Object.values(layers)) {
    c.width = 0;
    c.height = 0;
  }
  layers = {};
});
function layer(key) {
  if (layers[key]) return layers[key];
  const c = wx.createCanvas();
  c.width = 40 * su;
  c.height = 36 * su;
  const g = c.getContext('2d');
  (SCN[key] || []).forEach((row, y) =>
    [...row].forEach((ch, x) => {
      if (ch !== '.') {
        g.fillStyle = SCN.P[ch];
        g.fillRect(x * su, y * su, su, su);
      }
    }),
  );
  return (layers[key] = c);
}
function modalLayout() {
  const count = ((modal && modal.actions) || []).length;
  const desired = modal && modal.title === '体力商店' ? (212 + count * 48) * DPR : Math.max(360 * DPR, (212 + count * 48) * DPR);
  const h = Math.min(H - safeTop - 32 * DPR, desired);
  return { y: (H - h) / 2, h };
}
function next() {
  const saved = resumeIndex;
  if (saved >= 0) return saved;
  const i = LV.findIndex((l) => !S.stars[l.id]);
  return i < 0 ? 0 : i;
}
function recoveryLine() {
  if (progress.clock().blocked) return '设备时间回拨，自动恢复暂缓';
  const sec = Math.ceil(progress.remaining() / 1000);
  return sec ? '下点体力约 ' + Math.ceil(sec / 60) + ' 分钟恢复' : '体力已满';
}
function nextHomeFrame(now) {
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  const nextDay = midnight.getTime();
  if (S.energy >= CFG.MAXE) return nextDay;
  const recoveryAt = S.et + CFG.ENERGY_MS;
  if (recoveryAt <= now) return now + 1;
  const energyWake = modal && modal.title === '体力商店' ? Math.min(recoveryAt, now + ((recoveryAt - now) % 60000 || 60000)) : recoveryAt;
  return Math.min(nextDay, energyWake);
}
register('home', {
  accessibilityButtons: (all) => (modal ? all.slice(-((modal.actions || []).length + 1)) : all),
  animating: () => {
    const s = progress.sync().settings;
    return !s.reduceMotion && !s.lowEffects;
  },
  nextFrameAt: nextHomeFrame,
  enter() {
    progress.sync();
    resumeIndex = runs.active();
    modal = null;
    layers = {};
    const invite = social.consumeInvite();
    if (invite) {
      const i = LV.findIndex((l) => l.id === invite),
        open = i === 0 || (S.stars[LV[i - 1].id] || 0) > 0;
      modal = {
        title: '来自好友的接力',
        lines: ['好友邀请你挑战第 ' + invite + ' 关', open ? '选择自己的路线，接通同色信号' : '这关尚未解锁，先完成前面的接力'],
        actions: open
          ? [
              {
                label: '挑战第 ' + invite + ' 关',
                run: () => {
                  entry.enter(
                    i,
                    () => go('game', { index: i, resume: true }),
                    () => {
                      modal = { title: '体力不足', lines: ['请稍候恢复或在商店兑换体力'] };
                    },
                  );
                },
              },
            ]
          : [],
      };
    }
    sy = contentTop + 128 * DPR;
    su = Math.max(1, Math.floor(Math.min((W * 0.9) / 40, (H - sy - safeBottom - 224 * DPR) / 36)));
    sx = (W - 40 * su) / 2;
    const y = sy + 36 * su + 24 * DPR,
      pad = W * 0.05,
      gap = 8 * DPR,
      w = W * 0.9;
    btns = [{ id: 'start', x: pad, y, w, h: 80 * DPR, label: '开始游戏', primary: true, fs: 24 * DPR }];
    ['每日任务', '成就', '修复地图', '签到', '商店', '设置'].forEach((label, i) => {
      const count = i < 2 ? 2 : 4,
        col = i < 2 ? i : i - 2;
      btns.push({
        id: label,
        x: pad + (col * (w + gap)) / count,
        y: i < 2 ? y + 96 * DPR : y + 148 * DPR,
        w: (w - gap * (count - 1)) / count,
        h: 40 * DPR,
        label,
        fs: 12 * DPR,
      });
    });
  },
  draw(g) {
    progress.sync();
    ui.background(g, W, H);
    const u = Math.max(2, Math.round(W / 140));
    hud.draw(g, S);
    ui.text(g, '信号接力', W / 2 + u * 2, contentTop + 64 * DPR + u * 2, Math.min(W * 0.11, 40 * DPR), '#0b0c15');
    ui.text(g, '信号接力', W / 2 + u, contentTop + 64 * DPR + u, Math.min(W * 0.11, 40 * DPR), '#b13e53');
    ui.text(g, '信号接力', W / 2, contentTop + 64 * DPR, Math.min(W * 0.11, 40 * DPR), '#ffcd75');
    ui.text(g, '连接每一个节点 · 让信号抵达远方', W / 2, contentTop + 104 * DPR, 11 * DPR, '#94b0c2');
    ui.panel(g, sx - u * 2, sy - u * 2, 40 * su + u * 4, 36 * su + u * 4, u);
    g.drawImage(layer('base'), sx, sy);
    const t = S.settings.reduceMotion || S.settings.lowEffects ? 0 : Date.now();
    g.globalAlpha = t % 3000 < 1800 ? 0.3 : 0;
    if (!S.settings.lowEffects) g.drawImage(layer('beam'), sx, sy);
    g.globalAlpha = 1;
    g.drawImage(layer(t % 1200 < 600 ? 'wA' : 'wB'), sx, sy);
    if (t % 1200 < 600) g.drawImage(layer('sig'), sx, sy);
    const bob = t % 1600 < 800 ? 0 : -su;
    g.drawImage(bake('robot', su), sx + 18 * su, sy + 12 * su + bob);
    btns.forEach((b) => {
      if (b.id !== 'start') {
        ui.btn(g, b.id === '签到' && S.signDay === progress.day() ? Object.assign({}, b, { label: '已签到' }) : b, u);
        return;
      }
      ui.btn(g, Object.assign({}, b, { label: '' }), u);
      ui.text(g, resumeIndex >= 0 ? '继续游戏' : '开始游戏', b.x + b.w / 2, b.y + 28 * DPR, 24 * DPR, '#1a1c2c');
    });
    const i = next();
    ui.text(
      g,
      '第 ' +
        (Math.floor(i / 10) + 1) +
        ' 章 · ' +
        CFG.CHAPTERS[Math.floor(i / 10)] +
        ' · ' +
        LV[i].id +
        (resumeIndex >= 0 ? ' · 已保存' : ''),
      W / 2,
      btns[0].y + 57 * DPR,
      11 * DPR,
      '#73464c',
    );
    const pending = progress.tasks.some((t) => S.tasks[t.id] >= t.goal && !S.tasks.claimed[t.id]);
    if (pending) {
      g.fillStyle = '#ef4b5c';
      const b = btns[1];
      g.fillRect(b.x + b.w - W * 0.025, b.y, W * 0.025, W * 0.025);
    }
    if (modal) {
      if (modal.title === '体力商店') {
        const messages = modal.lines.slice(2);
        showShop();
        modal.lines.push(...messages);
      }
      g.fillStyle = 'rgba(10,10,20,.85)';
      g.fillRect(0, 0, W, H);
      const m = modalLayout();
      ui.panel(g, W * 0.06, m.y, W * 0.88, m.h, u);
      ui.text(g, modal.title, W / 2, m.y + 32 * DPR, 22 * DPR, '#ffcd75');
      if (modal.reward) {
        hud.icon(g, 'coin', W / 2, m.y + 88 * DPR, 40 * DPR);
        ui.text(g, '+100 金币', W / 2, m.y + 140 * DPR, 24 * DPR, '#ffcd75');
        ui.text(g, '今日已领取 · 明日再来', W / 2, m.y + 178 * DPR, 12 * DPR, '#b5c9d6');
        ui.text(g, '当前金币 ' + S.coins, W / 2, m.y + 206 * DPR, 12 * DPR, '#94b0c2');
      } else modal.lines.forEach((s, i) => ui.text(g, s, W / 2, m.y + (70 + i * 22) * DPR, 12 * DPR));
      (modal.actions || []).forEach((a, i) => {
        g.globalAlpha = a.disabled ? 0.5 : 1;
        ui.btn(
          g,
          { x: W * 0.13, y: m.y + (140 + i * 48) * DPR, w: W * 0.74, h: 40 * DPR, label: a.label, primary: !a.disabled, fs: 13 * DPR },
          u,
        );
        g.globalAlpha = 1;
      });
      ui.btn(g, { x: W * 0.3, y: m.y + m.h - 56 * DPR, w: W * 0.4, h: 40 * DPR, label: '关闭' }, u);
    }
  },
  onTap(x, y) {
    if (modal) {
      const m = modalLayout(),
        i = Math.floor((y - m.y - 140 * DPR) / (48 * DPR));
      if (x >= W * 0.13 && x <= W * 0.87 && i >= 0 && i < (modal.actions || []).length && y < m.y + (140 + i * 48 + 40) * DPR) {
        if (!modal.actions[i].disabled) modal.actions[i].run();
        return;
      }
      if (x >= W * 0.3 && x <= W * 0.7 && y >= m.y + m.h - 56 * DPR && y <= m.y + m.h - 16 * DPR) modal = null;
      return;
    }
    const badge = ui.hit(hud.layout(), x, y);
    if (badge) {
      if (badge.id === 'hud:rank') go('rank');
      else {
        analytics.track('shop_open');
        showShop();
      }
      return;
    }
    const b = ui.hit(btns, x, y);
    if (!b) return;
    if (b.id === 'start') {
      const i = next();
      entry.enter(
        i,
        () => go('game', { index: i, resume: true }),
        () => {
          modal = { title: '体力不足', lines: ['每 5 分钟恢复 1 点体力', '也可在商店使用金币兑换'] };
        },
      );
    } else if (b.id === '修复地图') go('world');
    else if (b.id === '签到') {
      const message = progress.sign(),
        success = message.startsWith('签到成功');
      if (success) feedback.play('sign');
      modal = success
        ? { title: '签到成功', reward: true, lines: [] }
        : { title: progress.clock().blocked ? '时间校验' : '今日已签到', lines: [message, '当前金币 ' + S.coins] };
    } else if (b.id === '成就') showAchievements();
    else if (b.id === '每日任务') showTasks();
    else if (b.id === '商店') {
      analytics.track('shop_open');
      showShop();
    } else if (b.id === '设置') showSettings();
  },
});
function showTasks() {
  progress.sync();
  modal = {
    title: '每日任务',
    lines: ['每日零点更新 · 完成后领取金币'],
    actions: [
      { label: '今日挑战 · 不耗体力' + (daily.current().rewarded ? ' · 已领奖' : ''), run: () => go('daily') },
      ...progress.tasks.map((t) => ({
        disabled: !!S.tasks.claimed[t.id] || S.tasks[t.id] < t.goal,
        label:
          t.title +
          ' ' +
          Math.min(t.goal, S.tasks[t.id]) +
          '/' +
          t.goal +
          ' · ' +
          (S.tasks.claimed[t.id] ? '已领取' : S.tasks[t.id] < t.goal ? '未完成' : '领取 ' + t.reward + '金币'),
        run: () => {
          if (progress.claimTask(t.id)) feedback.play('reward');
          showTasks();
        },
      })),
    ],
  };
}
function showAchievements() {
  modal = {
    title: '成就',
    lines: ['探索关卡，收集星光'],
    actions: progress.achievements.map((a) => ({
      disabled: !!S.ach[a.id] || a.value() < a.goal,
      label:
        a.title +
        ' ' +
        Math.min(a.value(), a.goal) +
        '/' +
        a.goal +
        ' · ' +
        (S.ach[a.id] ? '已领取' : a.value() < a.goal ? '未完成' : '领取 ' + a.reward + '金币'),
      run: () => {
        if (progress.claimAchievement(a.id)) feedback.play('reward');
        showAchievements();
      },
    })),
  };
}
function showShop() {
  progress.sync();
  modal = {
    title: '体力商店',
    lines: ['金币 ' + S.coins + ' · 体力 ' + S.energy + '/30', recoveryLine()],
    actions: [
      {
        label: '50 金币兑换 5 体力',
        disabled: S.energy >= CFG.MAXE || S.coins < 50,
        run: () => {
          const msg = progress.buy();
          if (msg.startsWith('兑换成功')) feedback.play('reward');
          showShop();
          modal.lines.push(msg);
        },
      },
      ...(ads.available()
        ? [
            {
              label: '完整观看视频 · 体力 +5',
              disabled: S.energy >= CFG.MAXE,
              run: () => {
                modal = { title: '视频补给', lines: ['正在加载，请稍候…'] };
                ads.watch().then((result) => {
                  if (modal && modal.title === '视频补给') {
                    if (result.code === 'reward') feedback.play('reward');
                    showShop();
                    modal.lines.push(ads.message(result));
                    invalidate();
                  }
                });
              },
            },
          ]
        : []),
    ],
  };
}
function showSettings() {
  const o = progress.sync().settings;
  modal = {
    title: '游戏设置',
    lines: ['设置会自动保存在本机'],
    actions: [
      { label: '协议与适度游戏', run: () => go('settings') },
      {
        label: '音效：' + (o.sound ? '开' : '关'),
        run: () => {
          o.sound = !o.sound;
          store.save();
          showSettings();
        },
      },
      {
        label: '震动：' + (o.vibration ? '开' : '关'),
        run: () => {
          o.vibration = !o.vibration;
          store.save();
          showSettings();
        },
      },
      {
        label: '信号速度：' + o.flow + 'ms / 格',
        run: () => {
          o.flow = o.flow === 60 ? 120 : o.flow === 120 ? 30 : 60;
          store.save();
          showSettings();
        },
      },
      {
        label: '减少动效：' + (o.reduceMotion ? '开' : '关'),
        run: () => {
          o.reduceMotion = !o.reduceMotion;
          store.save();
          showSettings();
        },
      },
    ],
  };
}
