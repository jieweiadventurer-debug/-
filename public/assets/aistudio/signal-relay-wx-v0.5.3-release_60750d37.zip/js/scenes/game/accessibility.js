const marks = { red: '红色 R', blue: '蓝色 B', green: '绿色 G', yellow: '黄色 Y' };
const kinds = { s: '直线', c: '拐角', t: '三通', a: '增幅器' };
function summary(context) {
  const { state, starGoals } = context;
  if (state.won)
    return [
      '★'.repeat(state.won.n) + '☆'.repeat(3 - state.won.n),
      state.dailyDate ? '每日挑战 · 接力成功' : '第 ' + state.L.id + ' 关 · 接力成功',
      '用时 ' + state.won.sec + ' 秒 · 金币 +' + state.reward,
    ];
  if (state.lesson) {
    const s = state.lesson,
      step = s.example.steps[s.step];
    return [
      s.example.title,
      step ? step[4] : '练习已完成',
      Math.min(s.step + 1, s.example.steps.length) + ' / ' + s.example.steps.length + ' 步',
    ];
  }
  if (state.hintOpen)
    return [
      '机器人提示',
      state.hintStage ? '第 ' + (state.hint.r + 1) + ' 行、第 ' + (state.hint.c + 1) + ' 列' : '先看看第 ' + (state.hint.r + 1) + ' 行',
      '点“说明”阅读完整提示',
    ];
  if (state.guideTab) {
    const t = state.guideTopics[state.guideIndex];
    return [t.title, ...t.lines.slice(0, 2)];
  }
  return starGoals().map((g) => (g.ok ? '已达成：' : '目标：') + g.text);
}
function info(context, scene) {
  const { state, practice } = context;
  const scope = state.lesson ? 'practice' : state.goalsOpen ? 'goals' : state.hintOpen ? 'hint' : state.won ? 'win' : 'board';
  return {
    scope,
    summary: scope === 'board' ? null : summary(context),
    R: state.R,
    C: state.C,
    operable: scope === 'board',
    rect: { x: state.bx, y: state.by, w: state.C * state.cs, h: state.R * state.cs },
    describe(r, c) {
      const f = state.fix[r][c],
        p = state.board[r][c],
        lit = state.res.lit.get(r + ',' + c);
      const fixed = f
        ? f.k === 'src'
          ? '发射端 ' + marks[f.col] + ' 出口' + context.directions[f.d]
          : f.k === 'tgt'
            ? '接收端 ' + marks[f.col] + ' 入口' + context.directions[f.d]
            : f.k === 'star'
              ? '星点'
              : f.k === 'bridge'
                ? '桥'
                : '障碍'
        : '空地';
      return (
        `第${r + 1}行 第${c + 1}列 · ${fixed}` +
        (p
          ? ' · ' +
            kinds[p.t] +
            ' 向' +
            context
              .portsOf(p)
              .map((d) => context.directions[d])
              .join('/')
          : '') +
        (f && f.k === 'tgt' ? (state.res.reached.has(r + ',' + c) ? ' · 已接通' : ' · 未接通') : lit ? ' · ' + marks[lit] + '已点亮' : '')
      );
    },
    activate(r, c) {
      const p = scene.cellXY(r, c);
      scene.onTap(p.x, p.y);
    },
    remove(r, c) {
      const p = scene.cellXY(r, c);
      scene.onLong(p.x, p.y);
    },
    practice: state.lesson
      ? () => {
          const s = state.lesson,
            step = s.example.steps[s.step];
          if (!step) return;
          const p = practice.geometry();
          practice.tap(s, p.x + (step[1] + 0.5) * p.cs, p.y + (step[0] + 0.5) * p.cs);
        }
      : null,
  };
}
function buttons(context, all) {
  const { state, guideButtons, winButtons } = context;
  if (state.lesson) return all.slice(-1);
  if (state.goalsOpen) return all.slice(-guideButtons().length);
  if (state.hintOpen) return all.slice(-3);
  if (state.won) return all.slice(-winButtons().length);
  return all.map((b) =>
    b.id && b.id.startsWith('tool:')
      ? { ...b, label: kinds[b.id.slice(5)] + ' 剩余' + state.inv[b.id.slice(5)] + (state.sel === b.id.slice(5) ? ' · 已选' : '') }
      : b,
  );
}
module.exports = { info, buttons };
