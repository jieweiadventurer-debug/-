function _drawInspection(context, g) {
  const { state, diagnose, used, DPR, ui, W, bake } = context;

  const last = state.btns[state.btns.length - 1];
  const problem = diagnose(state.res, state.fix);
  const tips =
    Date.now() < state.inspectionUntil
      ? state.inspection
      : problem
        ? problem.message
        : Date.now() < state.coachUntil
          ? state.coach
          : state.L.id === '1-1'
            ? used() === 0
              ? '我是接力机器人。点源右边的空格放置直线管'
              : '继续连接红色起点与终点；点管件可以旋转'
            : state.L.id === '1-2'
              ? '信号向下走：放好直线管，再点一次转为竖直'
              : state.L.inv.a
                ? '增幅器会恢复射程，放在信号耗尽之前'
                : state.L.inv.t
                  ? '三通可以把同色信号分成多条路线'
                  : '同色同字母相连 · 空心框是接收端';
  const cy = last.y + last.h + 16 * DPR;
  ui.panel(g, W * 0.04, cy, W * 0.92, 60 * DPR, 2 * DPR);
  const robotSize = 24 * DPR,
    rx = W * 0.04 + 14 * DPR;
  g.drawImage(bake('robot', Math.max(1, Math.floor(3 * DPR))), rx, cy + 18 * DPR, robotSize, robotSize);
  const tx = rx + robotSize + 12 * DPR,
    tw = W * 0.96 - 14 * DPR - tx;
  ui.wrapped(g, tips, tx, cy + 30 * DPR, tw, 12 * DPR, '#b5c9d6', 'left');
}

function _inspectFixed(context, f) {
  const { state, say, colorNames, colorMarks, directions } = context;

  if (f.k === 'src' || f.k === 'tgt') state.selectedColor = f.col;
  say(
    f.k === 'obs'
      ? '障碍物不能放置管件，试着绕过去'
      : f.k === 'bridge'
        ? '桥的横向与纵向各自直通，不能在桥上转弯'
        : f.k === 'src'
          ? colorNames[f.col] + '色 ' + colorMarks[f.col] + ' 是发射端，请连接同色同字母空心接收端'
          : colorNames[f.col] + '色 ' + colorMarks[f.col] + ' 接收端：从' + directions[f.d] + '侧白箭头接入同色信号',
    true,
  );
  return;
}
module.exports = (context) => ({
  drawInspection: (...args) => _drawInspection(context, ...args),
  inspectFixed: (...args) => _inspectFixed(context, ...args),
});
