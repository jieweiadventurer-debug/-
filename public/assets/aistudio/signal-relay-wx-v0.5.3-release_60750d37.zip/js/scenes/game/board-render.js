const accessible = require('../../engine/accessibility-preferences');
function _pipe(context, g, x, y, ports, color) {
  const { state } = context;

  const rect = {
    U: (a, b, w) => [x + a, y, w, 8 * state.u + b],
    D: (a, b, w) => [x + a, y + 8 * state.u - b, w, 8 * state.u + b],
    L: (a, b, w) => [x, y + a, 8 * state.u + b, w],
    R: (a, b, w) => [x + 8 * state.u - b, y + a, 8 * state.u + b, w],
  };
  const horiz = (d) => d === 'L' || d === 'R';
  [
    [5, 3, 6, '#1a1c2c'],
    [6, 2, 4, '#b3b9d1'],
    [7, 1, 2, color],
  ].forEach(([a, b, w, fill]) => {
    if (!fill) return;
    g.fillStyle = fill;
    ports.forEach((d) => {
      const r = rect[d](a * state.u, b * state.u, w * state.u);
      g.fillRect(r[0], r[1], r[2], r[3]);
    });
  });
  if (color && accessible.settings().highContrast) _texture(context, g, x, y, ports, color);
}

function _texture(context, g, x, y, ports, color) {
  const { state, CFG, DV } = context,
    u = state.u;
  const kind = Object.keys(CFG.COLORS).find((k) => CFG.COLORS[k] === color);
  g.fillStyle = '#ffffff';
  for (const d of ports) {
    const [dy, dx] = DV[d];
    for (const n of [3, 6]) {
      const a = x + (8 + dx * n) * u,
        b = y + (8 + dy * n) * u;
      if (kind === 'red') g.fillRect(a - u / 2, b - u, u, 2 * u);
      else if (kind === 'blue') g.fillRect(a - u, b - u / 2, 2 * u, u);
      else if (kind === 'green') {
        g.fillRect(a - u, b - u, u, u);
        g.fillRect(a, b, u, u);
      } else {
        g.fillRect(a - u, b - u, u, u);
        g.fillRect(a + u / 2, b - u, u, u);
      }
    }
  }
}

function _drawBoard(context, g) {
  const { flowMs, state, bake, pipe, CFG, drawEndpoint, starMarker, S, portsOf, ui, DPR } = context;

  const now = Date.now(),
    speed = flowMs();
  g.fillStyle = '#1a1c2c';
  g.fillRect(state.bx - state.u * 2, state.by - state.u * 2, state.C * state.cs + state.u * 4, state.R * state.cs + state.u * 4);
  for (let r = 0; r < state.R; r++)
    for (let c = 0; c < state.C; c++) {
      const x = state.bx + c * state.cs,
        y = state.by + r * state.cs,
        f = state.fix[r][c],
        pc = state.board[r][c],
        key = r + ',' + c,
        lit = now - state.flowAt >= (state.res.depth.get(key) || 0) * speed && state.res.lit.get(key);
      g.fillStyle = (r + c) % 2 ? '#4a5d78' : '#566c86';
      g.fillRect(x, y, state.cs, state.cs);
      g.strokeStyle = 'rgba(0,0,0,.25)';
      g.lineWidth = 1;
      g.strokeRect(x, y, state.cs, state.cs);
      if (f && f.k === 'obs') g.drawImage(bake(f.e, state.u * 2), x, y);
      else if (f && f.k === 'bridge') {
        g.fillStyle = '#a8714f';
        g.fillRect(x, y, state.cs, state.cs);
        g.fillStyle = '#73464c';
        for (let i = 0; i < 16; i += 4) g.fillRect(x, y + (i + 3) * state.u, state.cs, state.u);
        const raw = state.res.br.get(key) || {},
          b = {};
        for (const ax of ['h', 'v']) if (now - state.flowAt >= (state.res.bridgeDepth.get(key + ax) || 0) * speed) b[ax] = raw[ax];
        pipe(g, x, y, ['L', 'R'], b.h && CFG.COLORS[b.h]);
        pipe(g, x, y, ['U', 'D'], b.v && CFG.COLORS[b.v]);
      } else if (f && (f.k === 'src' || f.k === 'tgt')) drawEndpoint(g, x, y, f, lit, key);
      if (f && f.k === 'star') starMarker.draw(g, x, y, state.cs, !!pc, !!lit);
      if (pc) {
        const active = state.change && state.change.r === r && state.change.c === c;
        const elapsed = active ? Date.now() - state.change.at : 999;
        const duration = state.change && state.change.kind === 'rotate' ? 140 : 180;
        if (active && elapsed < duration && g.save && !S.settings.reduceMotion) {
          const f = Math.min(1, elapsed / duration),
            scale = state.change.kind === 'pop' ? 0.3 + 0.7 * f : 1;
          g.save();
          g.translate(x + state.cs / 2, y + state.cs / 2);
          if (state.change.kind === 'rotate') g.rotate((-(1 - f) * Math.PI) / 2);
          g.scale(scale, scale);
          pipe(g, -state.cs / 2, -state.cs / 2, portsOf(pc), lit && CFG.COLORS[lit]);
          g.restore();
        } else pipe(g, x, y, portsOf(pc), lit && CFG.COLORS[lit]);
        if (pc.t === 'a') ui.text(g, '+', x + state.cs / 2, y + state.cs / 2, state.cs * 0.45, '#ffcd75');
      }
      if (state.hint && !state.hintOpen && r === state.hint.r && (state.hintStage === 0 || c === state.hint.c)) {
        g.strokeStyle = '#ffcd75';
        g.lineWidth = 2 * DPR;
        g.strokeRect(x + 2 * DPR, y + 2 * DPR, state.cs - 4 * DPR, state.cs - 4 * DPR);
      }
      if (state.res.exhausted.has(key)) {
        g.strokeStyle = '#ffcd75';
        g.lineWidth = 2 * DPR;
        g.strokeRect(x + 2 * DPR, y + 2 * DPR, state.cs - 4 * DPR, state.cs - 4 * DPR);
        ui.text(g, '!', x + state.cs - 5 * state.u, y + 4 * state.u, Math.max(10 * DPR, 5 * state.u), '#ffcd75');
      }
      if (Date.now() < state.checkUntil && state.checkCells.includes(key)) {
        g.strokeStyle = '#73eff7';
        g.lineWidth = 2 * DPR;
        g.strokeRect(x + DPR, y + DPR, state.cs - 2 * DPR, state.cs - 2 * DPR);
      }
      if (state.res.bad.has(key)) {
        g.strokeStyle = '#ef4b5c';
        g.lineWidth = state.u;
        g.strokeRect(x + state.u / 2, y + state.u / 2, state.cs - state.u, state.cs - state.u);
      }
    }
}

function _drawEndpoint(context, g, x, y, f, lit, key) {
  const { pipe, CFG, DV, state, colorMarks } = context;

  const on = f.k === 'src' || lit;
  pipe(g, x, y, [f.d], CFG.COLORS[f.col]);
  // 白色像素箭头始终朝向接收端中心，位置随入口方向旋转。
  if (f.k === 'tgt') {
    const [dy, dx] = DV[f.d];
    g.fillStyle = '#ffffff';
    for (let step = 0; step < 3; step++)
      for (const side of step ? [-1, 1] : [0]) {
        const a = 5 + step,
          b = step * side;
        g.fillRect(
          Math.round(x + (8 + dx * a - dy * b) * state.u - state.u / 2),
          Math.round(y + (8 + dy * a + dx * b) * state.u - state.u / 2),
          state.u,
          state.u,
        );
      }
  }
  g.fillStyle = '#1a1c2c';
  g.fillRect(x + 3 * state.u, y + 3 * state.u, 10 * state.u, 10 * state.u);
  g.fillStyle = CFG.COLORS[f.col];
  g.fillRect(x + 4 * state.u, y + 4 * state.u, 8 * state.u, 8 * state.u);
  g.fillStyle = on ? '#ffffff' : '#1a1c2c';
  g.fillRect(x + 5 * state.u, y + 5 * state.u, 6 * state.u, 6 * state.u);
  // 同色字母配对：实心为发射端，空心为接收端，未接通也保留颜色。
  g.font = 'bold ' + Math.max(1, 5 * state.u) + 'px sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillStyle = on ? '#1a1c2c' : '#ffffff';
  g.fillText(colorMarks[f.col], x + 8 * state.u, y + 8 * state.u);
  if (state.selectedColor === f.col) {
    g.strokeStyle = '#ffffff';
    g.lineWidth = state.u;
    g.strokeRect(x + state.u, y + state.u, 14 * state.u, 14 * state.u);
  }
  if (state.res.targetIssues.has(key) && !state.res.reached.has(key)) {
    g.strokeStyle = '#ffcd75';
    g.lineWidth = state.u;
    g.strokeRect(x + 2 * state.u, y + 2 * state.u, 12 * state.u, 12 * state.u);
  }
}
module.exports = (context) => ({
  pipe: (...args) => _pipe(context, ...args),
  drawBoard: (...args) => _drawBoard(context, ...args),
  drawEndpoint: (...args) => _drawEndpoint(context, ...args),
});
