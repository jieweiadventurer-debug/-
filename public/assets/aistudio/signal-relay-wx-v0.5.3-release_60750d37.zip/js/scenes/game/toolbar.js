function _layout(context) {
  const { state, contentTop, DPR, H, safeBottom, unitFor, W, NAMES } = context;

  state.by = Math.round(contentTop + 100 * DPR);
  // Reserve vertical space for both tool rows, gaps, shadows and the home indicator.
  const heightUnit = Math.floor((H - state.by - safeBottom - 204 * DPR) / (state.R * 16 + 8));
  state.u = Math.max(1, Math.min(unitFor(state.C), heightUnit));
  state.cs = 16 * state.u;
  state.bx = Math.round((W - state.C * state.cs) / 2);
  state.btns = [];
  const ks = ['s', 'c', 't', 'a'].filter((k) => state.L.inv[k] > 0 || k === 's');
  const gap = 12 * DPR,
    bw = (W * 0.92 - gap * (ks.length - 1)) / ks.length,
    bh = 64 * DPR;
  const x0 = (W - (bw * ks.length + gap * (ks.length - 1))) / 2,
    ty = state.by + state.R * state.cs + 20 * DPR;
  ks.forEach((k, i) =>
    state.btns.push({
      id: 'tool:' + k,
      x: x0 + i * (bw + gap),
      y: ty,
      w: bw,
      h: bh,
      label: NAMES[k] + ' ' + state.inv[k],
      primary: state.sel === k,
      fs: bh * 0.3,
    }),
  );
  const aw = (W * 0.92 - W * 0.04) / 3,
    ay = ty + bh + 16 * DPR;
  [
    ['undo', '撤回'],
    ['reset', '重置'],
    ['replay', '回放信号'],
  ].forEach(([id, label], i) => state.btns.push({ id, x: W * 0.04 + i * (aw + W * 0.02), y: ay, w: aw, h: 40 * DPR, label }));
}

function _navigation(context) {
  const { W, contentTop, DPR, state } = context;

  return [
    { id: 'home', x: W * 0.04, w: W * 0.18, label: '主页' },
    { id: 'levels', x: W * 0.24, w: W * 0.18, label: state.dailyDate ? '每日挑战' : '选关' },
    { id: 'hint', x: W * 0.44, w: W * 0.27, label: '机器人提示' },
    { id: 'goals', x: W * 0.73, w: W * 0.23, label: '三星目标' },
  ].map((b) => Object.assign(b, { y: contentTop, h: 36 * DPR, fs: 11 * DPR }));
}

function _toolIcon(context, g, kind, cx, cy) {
  const { state, DPR, BASE, pipe, ui } = context;

  const old = state.u;
  state.u = Math.max(1, Math.floor(2 * DPR));
  const ports = BASE[kind],
    left = ports.includes('L') ? 0 : 5,
    right = ports.includes('R') ? 16 : 11;
  const top = ports.includes('U') ? 0 : 5,
    bottom = ports.includes('D') ? 16 : 11;
  pipe(g, cx - ((left + right) * state.u) / 2, cy - ((top + bottom) * state.u) / 2, ports, null);
  if (kind === 'a') ui.text(g, '+', cx, cy, 14 * DPR, '#ffcd75');
  state.u = old;
}

function _drawToolbar(context, g) {
  const { state, ui, toolIcon, DPR, NAMES } = context;

  state.btns.forEach((b) => {
    if (!b.id.startsWith('tool:')) {
      ui.btn(g, b, state.u);
      return;
    }
    const kind = b.id.slice(5);
    g.globalAlpha = state.inv[kind] > 0 ? 1 : 0.45;
    ui.btn(g, Object.assign({}, b, { label: '' }), state.u);
    toolIcon(g, kind, b.x + b.w / 2, b.y + 24 * DPR);
    ui.text(g, NAMES[kind], b.x + b.w / 2, b.y + 50 * DPR, 12 * DPR, b.primary ? '#1a1c2c' : '#f4f4f4');
    const size = 18 * DPR;
    g.fillStyle = '#ef4b5c';
    g.fillRect(b.x + b.w - size - 4 * DPR, b.y + 4 * DPR, size, size);
    ui.text(g, String(state.inv[kind]), b.x + b.w - size / 2 - 4 * DPR, b.y + 13 * DPR, size * 0.65);
    g.globalAlpha = 1;
  });
}
module.exports = (context) => ({
  layout: (...args) => _layout(context, ...args),
  navigation: (...args) => _navigation(context, ...args),
  toolIcon: (...args) => _toolIcon(context, ...args),
  drawToolbar: (...args) => _drawToolbar(context, ...args),
});
