function _goalsBox(context) {
  const { DPR, W, contentTop, H } = context;

  const h = 360 * DPR;
  return { x: W * 0.07, y: Math.max(contentTop + 8 * DPR, (H - h) / 2), w: W * 0.86, h };
}

function _guideButtons(context) {
  const { goalsBox, DPR, state } = context;

  const m = goalsBox(),
    gap = 8 * DPR,
    w = (m.w - 32 * DPR - gap) / 2;
  const list = [
    { id: 'goalTab', label: '三星目标', primary: !state.guideTab, x: m.x + 16 * DPR },
    { id: 'guideTab', label: '玩法说明', primary: state.guideTab, x: m.x + 16 * DPR + w + gap },
  ].map((b) => Object.assign(b, { y: m.y + 52 * DPR, w, h: 32 * DPR, fs: 11 * DPR }));
  if (state.guideTab && state.guideTopics.length > 1) {
    list.push(
      { id: 'guidePrev', label: '上一条', x: m.x + 16 * DPR, y: m.y + 222 * DPR, w, h: 32 * DPR, fs: 11 * DPR },
      { id: 'guideNext', label: '下一条', x: m.x + 16 * DPR + w + gap, y: m.y + 222 * DPR, w, h: 32 * DPR, fs: 11 * DPR },
    );
  }
  if (state.guideTab)
    list.push({
      id: 'practice',
      x: m.x + 16 * DPR,
      y: m.y + 264 * DPR,
      w: m.w - 32 * DPR,
      h: 28 * DPR,
      label: '动手练习 · 不改本关',
      fs: 11 * DPR,
    });
  list.push({
    id: 'guideClose',
    x: m.x + 16 * DPR,
    y: m.y + m.h - 58 * DPR,
    w: m.w - 32 * DPR,
    h: 40 * DPR,
    label: '继续接力',
    primary: true,
  });
  return list;
}

function _drawGoals(context, g) {
  const { goalsBox, W, H, ui, DPR, state, starGoals, guideButtons } = context;

  const m = goalsBox();
  g.fillStyle = 'rgba(10,10,20,.85)';
  g.fillRect(0, 0, W, H);
  ui.panel(g, m.x, m.y, m.w, m.h, 2 * DPR);
  ui.text(g, '本关说明', W / 2, m.y + 26 * DPR, 22 * DPR, '#ffcd75');
  if (state.guideTab) {
    const topic = state.guideTopics[state.guideIndex];
    ui.text(g, topic.title, W / 2, m.y + 112 * DPR, 14 * DPR, '#ffcd75');
    topic.lines.forEach((s, i) => ui.text(g, s, m.x + 16 * DPR, m.y + (140 + i * 23) * DPR, 11 * DPR, '#f4f4f4', 'left'));
    ui.text(g, state.guideIndex + 1 + ' / ' + state.guideTopics.length, W / 2, m.y + 208 * DPR, 10 * DPR, '#94b0c2');
  } else {
    starGoals().forEach((a, i) =>
      ui.text(g, (a.ok ? '✓ ' : '☆ ') + a.text, m.x + 16 * DPR, m.y + (116 + i * 34) * DPR, 11 * DPR, a.ok ? '#a7f070' : '#f4f4f4', 'left'),
    );
    ui.text(g, '每项各得一星 · 用时不影响星级', W / 2, m.y + 224 * DPR, 11 * DPR, '#94b0c2');
  }
  guideButtons().forEach((b) => ui.btn(g, b, 2 * DPR));
}

function _guideTap(context, x, y) {
  const { ui, guideButtons, state, practice, S, store, analytics } = context;

  const b = ui.hit(guideButtons(), x, y);
  if (!b) return;
  if (b.id === 'practice') {
    analytics.track('practice_enter', { topic: state.guideTopics[state.guideIndex].id });
    state.lesson = practice.create(state.guideTopics[state.guideIndex].id);
    return;
  }
  if (state.guideTab) {
    S.seen['tutorial:' + state.guideTopics[state.guideIndex].id] = true;
    store.save();
  }
  if (b.id === 'goalTab') state.guideTab = false;
  else if (b.id === 'guideTab') state.guideTab = true;
  else if (b.id === 'guidePrev') state.guideIndex = (state.guideIndex + state.guideTopics.length - 1) % state.guideTopics.length;
  else if (b.id === 'guideNext') state.guideIndex = (state.guideIndex + 1) % state.guideTopics.length;
  else state.goalsOpen = false;
}
module.exports = (context) => ({
  goalsBox: (...args) => _goalsBox(context, ...args),
  guideButtons: (...args) => _guideButtons(context, ...args),
  drawGoals: (...args) => _drawGoals(context, ...args),
  guideTap: (...args) => _guideTap(context, ...args),
});
