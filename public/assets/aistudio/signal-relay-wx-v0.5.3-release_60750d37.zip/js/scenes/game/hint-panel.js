function _hintBox(context) {
  const { DPR, W, contentTop, H } = context;

  const h = 228 * DPR;
  return { x: W * 0.07, y: Math.max(contentTop + 44 * DPR, (H - h) / 2), w: W * 0.86, h };
}

function _drawHint(context, g) {
  const { hintBox, W, H, ui, DPR, state, NAMES, portsOf, directions } = context;

  const m = hintBox();
  g.fillStyle = 'rgba(10,10,20,.78)';
  g.fillRect(0, 0, W, H);
  ui.panel(g, m.x, m.y, m.w, m.h, 2 * DPR);
  ui.text(g, '机器人提示 · ' + (state.hintStage + 1) + '/2', W / 2, m.y + 28 * DPR, 18 * DPR, '#ffcd75');
  const text =
    state.hintStage === 0
      ? '先看看第 ' + (state.hint.r + 1) + ' 行。沿着信号找空缺，也可以尝试自己的路线。'
      : state.hint.kind === 'remove'
        ? '取回第 ' + (state.hint.r + 1) + ' 行、第 ' + (state.hint.c + 1) + ' 列的管件，为后续路线腾出库存。'
        : '第 ' +
          (state.hint.r + 1) +
          ' 行、第 ' +
          (state.hint.c + 1) +
          ' 列：' +
          (state.hint.kind === 'rotate' ? '旋转' : '放置') +
          NAMES[state.hint.piece.t] +
          '，端口朝' +
          portsOf(state.hint.piece)
            .map((d) => directions[d])
            .join('、') +
          '。';
  ui.wrapped(g, text, m.x + 18 * DPR, m.y + 82 * DPR, m.w - 36 * DPR, 13 * DPR, '#f4f4f4', 'left');
  ui.btn(
    g,
    {
      id: 'checkRoute',
      x: m.x + 18 * DPR,
      y: m.y + 118 * DPR,
      w: m.w - 36 * DPR,
      h: 28 * DPR,
      label: '检查线路 · 不改棋盘',
      fs: 11 * DPR,
    },
    2 * DPR,
  );
  const y = m.y + m.h - 62 * DPR;
  ui.btn(g, { x: m.x + 12 * DPR, y, w: m.w * 0.39, h: 40 * DPR, label: '自己试试' }, 2 * DPR);
  ui.btn(
    g,
    { x: m.x + m.w * 0.46, y, w: m.w * 0.5 - 12 * DPR, h: 40 * DPR, label: state.hintStage ? '应用这一步' : '再详细一点', primary: true },
    2 * DPR,
  );
}

function _hintTap(context, x, y) {
  const { hintBox, DPR, checkRoute, state, say, nextHint, snap, applyHint, feedback, afterChange, analytics } = context;

  const m = hintBox();
  if (x >= m.x + 18 * DPR && x <= m.x + m.w - 18 * DPR && y >= m.y + 118 * DPR && y <= m.y + 146 * DPR) {
    const check = checkRoute(state.res, state.fix);
    state.hintOpen = false;
    state.hint = null;
    state.checkCells = check.cells;
    state.checkUntil = Date.now() + 5000;
    say(check.message, true);
    return;
  }
  const ay = m.y + m.h - 62 * DPR;
  if (y < ay || y > ay + 40 * DPR) return;
  if (x >= m.x + 12 * DPR && x <= m.x + 12 * DPR + m.w * 0.39) {
    state.hintOpen = false;
    return;
  }
  if (x < m.x + m.w * 0.46 || x > m.x + m.w * 0.96 - 12 * DPR) return;
  if (state.hintStage === 0) {
    state.hintStage = 1;
    analytics.track('hint_used', { phase: 1 });
    return;
  }
  const fresh = nextHint(state.L, state.board);
  if (JSON.stringify(fresh) !== JSON.stringify(state.hint)) {
    state.hint = fresh;
    state.hintStage = 0;
    if (!state.hint) state.hintOpen = false;
    return;
  }
  const dropped = snap(state.hint.r, state.hint.c);
  if (applyHint(state.board, state.inv, state.hint)) {
    state.sel = ['s', 'c', 't', 'a'].find((k) => state.inv[k] > 0) || state.sel;
    analytics.track('hint_used', { phase: 2 });
    feedback.play('place');
    afterChange();
    say('这一步已调整。沿着信号继续试试吧');
  } else {
    state.hist.pop();
    if (dropped) state.hist.unshift(dropped);
    state.hintOpen = false;
    say('先取回多余管件，再试这一步');
  }
}
module.exports = (context) => ({
  hintBox: (...args) => _hintBox(context, ...args),
  drawHint: (...args) => _drawHint(context, ...args),
  hintTap: (...args) => _hintTap(context, ...args),
});
