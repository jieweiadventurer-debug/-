const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas');
const { register, go, invalidate } = require('../engine/scene-manager'),
  ui = require('../engine/ui');
const feedback = require('../engine/player-feedback');
function buttons() {
  return [
    { id: 'back', label: '← 设置', x: W * 0.05, y: contentTop, w: 100 * DPR, h: 44 * DPR },
    {
      id: 'feedback',
      label: feedback.available() ? '打开微信反馈' : '查看反馈方式',
      x: W * 0.08,
      y: H - safeBottom - 116 * DPR,
      w: W * 0.84,
      h: 52 * DPR,
      primary: true,
    },
  ];
}
const scene = {
  leave: feedback.destroy,
  pause: feedback.destroy,
  resume: () => invalidate(),
  afterDraw(mapped) {
    const b = (mapped || buttons()).find((b) => b.id === 'feedback' || b.label === '打开微信反馈');
    feedback.sync(b);
  },
  draw(g) {
    ui.background(g, W, H);
    ui.text(g, '意见反馈', W / 2, contentTop + 76 * DPR, 28 * DPR, '#ffcd75');
    ui.wrapped(g, '遇到问题时，请说明关卡编号与操作步骤。', W / 2, contentTop + 140 * DPR, W * 0.82, 16 * DPR, '#f4f4f4');
    ui.wrapped(
      g,
      '本游戏不另行保存或上传反馈内容。微信反馈页的信息按平台规则处理，请避免填写个人敏感信息。',
      W / 2,
      contentTop + 222 * DPR,
      W * 0.82,
      13 * DPR,
      '#b5c9d6',
    );
    buttons().forEach((b) => ui.btn(g, b, 2 * DPR));
  },
  onTap(x, y) {
    const b = ui.hit(buttons(), x, y);
    if (!b) return;
    if (b.id === 'back') go('settings');
    else if (!feedback.available()) feedback.fallback();
  },
};
register('player-feedback', scene);
