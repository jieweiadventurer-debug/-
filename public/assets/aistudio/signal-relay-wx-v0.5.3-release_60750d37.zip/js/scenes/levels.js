const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas');
const { register, go } = require('../engine/scene-manager');
const ui = require('../engine/ui');
const store = require('../engine/storage');
const CFG = require('../data/config');
const LV = require('../data/levels');
const S = store.state;
const runs = require('../engine/runs');
const entry = require('../engine/level-entry');
let btns = [],
  filter = 'all',
  visible = [],
  footerY = 0,
  cardY = 0;
const unlocked = (i) => CFG.DEV_UNLOCK || i === 0 || (S.stars[LV[i - 1].id] || 0) > 0;
const filters = [
  ['all', '全部'],
  ['stars', '补星'],
  ['resume', '续玩'],
];
function matches(i, kind) {
  const n = S.stars[LV[i].id] || 0;
  return kind === 'all' || (unlocked(i) && (kind === 'stars' ? n > 0 && n < 3 : !!runs.read(LV[i])));
}
function timeLabel(sec) {
  return (
    Math.floor(sec / 60)
      .toString()
      .padStart(2, '0') +
    ':' +
    (sec % 60).toString().padStart(2, '0')
  );
}
function layout() {
  btns = [{ id: 'home', x: W * 0.05, y: contentTop, w: W * 0.2, h: Math.max(28 * DPR, H * 0.035), label: '← 地图', fs: W * 0.03 }];
  const pad = W * 0.05,
    tw = (W * 0.9) / CFG.CHAPTERS.length,
    th = Math.max(44 * DPR, H * 0.05);
  CFG.CHAPTERS.forEach((n, i) =>
    btns.push({
      id: 'ch:' + i,
      x: pad + i * tw,
      y: contentTop + H * 0.08,
      w: tw - 4 * DPR,
      h: th,
      label: String(i + 1),
      primary: i === S.ch,
      fs: th * 0.5,
    }),
  );
  const indices = Array.from({ length: 10 }, (_, k) => S.ch * 10 + k),
    fy = Math.max(contentTop + H * 0.145, contentTop + H * 0.08 + th + 10 * DPR),
    fw = (W * 0.9 - 16 * DPR) / 3;
  filters.forEach(([id, label], i) =>
    btns.push({
      id: 'filter:' + id,
      x: pad + i * (fw + 8 * DPR),
      y: fy,
      w: fw,
      h: 28 * DPR,
      label: label + ' ' + indices.filter((j) => matches(j, id)).length,
      primary: filter === id,
      fs: 11 * DPR,
    }),
  );
  visible = indices.filter((i) => matches(i, filter));
  cardY = fy + 40 * DPR;
  const ch = Math.min(66 * DPR, (H - safeBottom - cardY - 46 * DPR) / 5 - 10 * DPR);
  visible.forEach((i, k) =>
    btns.push({
      id: 'lv:' + i,
      x: pad + (k % 2) * W * 0.46,
      y: cardY + Math.floor(k / 2) * (ch + 10 * DPR),
      w: W * 0.44,
      h: ch,
      label: LV[i].id,
      locked: !unlocked(i),
      resume: !!runs.read(LV[i]),
    }),
  );
  footerY = cardY + (visible.length ? Math.ceil(visible.length / 2) * (ch + 10 * DPR) : 90 * DPR) + 10 * DPR;
}
register('levels', {
  enter() {
    layout();
  },
  draw(g) {
    ui.background(g, W, H);
    ui.text(g, '第 ' + (S.ch + 1) + ' 章 · ' + CFG.CHAPTERS[S.ch], W / 2, contentTop + H * 0.065, W * 0.05, '#ffcd75');
    btns.forEach((b) => {
      const level = b.id.startsWith('lv:');
      if (b.locked) g.globalAlpha = 0.55;
      ui.btn(g, Object.assign({}, b, { label: level ? '' : b.label }), 4);
      if (level) {
        const n = S.stars[b.label] || 0,
          best = S.best[b.label];
        ui.text(g, b.label, b.x + b.w * 0.25, b.y + b.h * 0.34, 18 * DPR, b.locked ? '#94b0c2' : '#f4f4f4');
        ui.text(g, b.locked ? '锁' : '★'.repeat(n) + '☆'.repeat(3 - n), b.x + b.w * 0.72, b.y + b.h * 0.36, 12 * DPR, '#ffcd75');
        const detail = b.locked
          ? '通关上一关解锁'
          : b.resume
            ? '续玩 · 不耗体力'
            : best && Number.isFinite(best.sec)
              ? '最佳 ' + timeLabel(best.sec)
              : n > 0
                ? '已通关'
                : '未挑战';
        ui.text(g, detail, b.x + b.w / 2, b.y + b.h * 0.77, 10 * DPR, b.resume ? '#a7f070' : '#b5c9d6');
      }
      g.globalAlpha = 1;
    });
    if (!visible.length) {
      ui.text(
        g,
        filter === 'stars' ? '本章暂无需要补星的已通关关卡' : '本章没有未完成的存档',
        W / 2,
        cardY + 28 * DPR,
        12 * DPR,
        '#b5c9d6',
      );
      ui.text(g, '切换“全部”，继续新的接力', W / 2, cardY + 54 * DPR, 11 * DPR, '#94b0c2');
    }
    const total = LV.slice(S.ch * 10, S.ch * 10 + 10).reduce((n, l) => n + (S.stars[l.id] || 0), 0);
    ui.panel(g, W * 0.05, footerY, W * 0.65, H * 0.025, 3);
    g.fillStyle = '#ffcd75';
    g.fillRect(W * 0.05 + 4, footerY + 4, ((W * 0.65 - 8) * total) / 30, Math.max(0, H * 0.025 - 8));
    ui.text(g, total + ' / 30 ★', W * 0.83, footerY + H * 0.013, W * 0.033, '#ffcd75');
  },
  onTap(x, y) {
    const b = ui.hit(btns, x, y);
    if (!b) return;
    if (b.id === 'home') go('world');
    else if (b.id.startsWith('ch:')) {
      S.ch = +b.id.slice(3);
      layout();
    } else if (b.id.startsWith('filter:')) {
      filter = b.id.slice(7);
      layout();
    } else if (b.id.startsWith('lv:') && !b.locked) {
      const i = +b.id.slice(3);
      entry.enter(
        i,
        () => go('game', { index: i, resume: true }),
        () => {
          if (wx.showToast) wx.showToast({ title: '体力不足，返回首页商店兑换', icon: 'none' });
        },
      );
    }
  },
});
