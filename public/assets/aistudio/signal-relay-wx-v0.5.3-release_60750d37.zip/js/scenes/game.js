// Compatibility entry for the directory-based game scene.
require('./game/index');
