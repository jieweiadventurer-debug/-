const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas'),
  { register, go } = require('../engine/scene-manager'),
  ui = require('../engine/ui'),
  { bake } = require('../data/sprites'),
  CFG = require('../data/config'),
  LV = require('../data/levels'),
  store = require('../engine/storage'),
  social = require('../engine/social');
let chapter = 0,
  at = 0;
function buttons() {
  const y = H - safeBottom - 112 * DPR,
    w = (W * 0.9 - 8 * DPR) / 2;
  return [
    { id: 'map', label: '查看修复地图', x: W * 0.05, y, w, h: 44 * DPR, primary: true },
    { id: 'levels', label: '返回选关', x: W * 0.05 + w + 8 * DPR, y, w, h: 44 * DPR },
    { id: 'share', label: '分享这一程', x: W * 0.05, y: y + 60 * DPR, w: W * (social.timelineAvailable() ? 0.44 : 0.9), h: 44 * DPR },
    ...(social.timelineAvailable()
      ? [{ id: 'timeline', label: '分享到朋友圈', x: W * 0.51, y: y + 60 * DPR, w: W * 0.44, h: 44 * DPR }]
      : []),
  ];
}
register('celebration', {
  animating: (now) => !(store.state.settings && store.state.settings.reduceMotion) && now < at + 1600,
  enter(arg) {
    chapter = Math.max(0, Math.min(CFG.CHAPTERS.length - 1, Number(arg) || 0));
    at = Date.now();
  },
  draw(g) {
    ui.background(g, W, H);
    const all = LV.every((l) => (store.state.stars[l.id] || 0) > 0),
      age = store.state.settings && store.state.settings.reduceMotion ? 1 : Math.min(1, (Date.now() - at) / 1600);
    ui.text(g, all ? '全域接通 · 星光相连' : '第 ' + (chapter + 1) + ' 章 · 接力完成', W / 2, contentTop + 40 * DPR, 22 * DPR, '#ffcd75');
    ui.text(g, CFG.CHAPTERS[chapter] + '重新亮起了', W / 2, contentTop + 76 * DPR, 13 * DPR, '#b5c9d6');
    const top = contentTop + 112 * DPR,
      bottom = H - safeBottom - 164 * DPR,
      u = Math.max(1, Math.floor(Math.min(W / 78, (bottom - top) / 68))),
      x = W / 2,
      center = top + (bottom - top) / 2 + 2 * u;
    g.fillStyle = '#1a1c2c';
    g.fillRect(x - 16 * u, center - 24 * u, 32 * u, 47 * u);
    for (let i = 0; i < 5; i++) {
      g.fillStyle = age > i / 6 ? ['#a7f070', '#5fe36c', '#73eff7', '#ef7d57', '#b3a6ff', '#41a6f6'][chapter] : '#333c57';
      g.fillRect(x - 12 * u, center + (14 - i * 8) * u, 24 * u, 6 * u);
    }
    if (age > 0.65) {
      g.drawImage(bake('star', u), x - 4 * u, center - 36 * u);
      g.globalAlpha = store.state.settings && store.state.settings.lowEffects ? 0 : 0.25;
      g.fillStyle = '#ffcd75';
      if (!(store.state.settings && store.state.settings.lowEffects)) g.fillRect(x - 24 * u, center - 27 * u, 48 * u, 6 * u);
      g.globalAlpha = 1;
    }
    g.drawImage(bake('robot', u), x - 4 * u, center + 23 * u);
    ui.text(g, all ? '每一束信号，都找到了归处' : '下一程，继续把光送向远方', W / 2, H - safeBottom - 142 * DPR, 12 * DPR, '#94b0c2');
    buttons().forEach((b) => ui.btn(g, b, 2 * DPR));
  },
  onTap(x, y) {
    const b = ui.hit(buttons(), x, y);
    if (!b) return;
    if (b.id === 'map') go('world');
    else if (b.id === 'levels') {
      store.state.ch = chapter;
      go('levels');
    } else if (b.id === 'timeline') social.prepareTimeline(chapter + 1 + '-10');
    else social.share(chapter + 1 + '-10');
  },
});
