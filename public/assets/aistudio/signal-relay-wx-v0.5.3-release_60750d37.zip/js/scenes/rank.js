const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas'),
  { register, go, invalidate } = require('../engine/scene-manager'),
  ui = require('../engine/ui'),
  store = require('../engine/storage'),
  social = require('../engine/social'),
  LV = require('../data/levels'),
  notice = require('../engine/notice'),
  analytics = require('../engine/analytics');
let context = null,
  active = false,
  status = '',
  uploading = false,
  token = 0,
  liveUntil = 0;
const board = () => ({
  x: W * 0.05,
  y: contentTop + 132 * DPR,
  w: W * 0.9,
  h: Math.max(120 * DPR, H - safeBottom - contentTop - 246 * DPR),
});
function buttons() {
  const y = H - safeBottom - 94 * DPR,
    w = (W * 0.9 - 16 * DPR) / 3;
  return [
    { id: 'back', label: '← 首页', x: W * 0.05, y: contentTop, w: 90 * DPR, h: 36 * DPR },
    { id: 'share', label: '邀请接力', x: W * 0.7, y: contentTop, w: W * 0.25, h: 36 * DPR },
    ...['上一页', '刷新', '下一页'].map((label, i) => ({
      id: ['prev', 'refresh', 'next'][i],
      label,
      x: W * 0.05 + i * (w + 8 * DPR),
      y,
      w,
      h: 36 * DPR,
    })),
    {
      id: 'enable',
      label: store.state.socialEnabled ? '关闭成绩同步' : '开启好友榜',
      x: W * 0.2,
      y: y + 50 * DPR,
      w: W * 0.6,
      h: 36 * DPR,
      primary: !store.state.socialEnabled,
    },
  ];
}
function load() {
  if (!store.state.socialEnabled) {
    status = '开启后同步星数与通关数';
    return;
  }
  status = '正在同步成绩…';
  uploading = true;
  const id = ++token;
  social.upload((ok) => {
    if (!active || id !== token) return;
    uploading = false;
    status = ok ? '按总星数排序 · 每页五位' : '成绩同步失败，可点击刷新重试';
    try {
      if (wx.getOpenDataContext) {
        context = wx.getOpenDataContext();
        const b = board();
        context.canvas.width = Math.round(b.w);
        context.canvas.height = Math.round(b.h);
        context.postMessage({ type: 'show', width: b.w, height: b.h });
        liveUntil = Date.now() + 11000;
      } else status = '当前环境不支持好友榜';
    } catch (e) {
      context = null;
      status = '好友榜暂不可用，请稍后重试';
    }
    invalidate();
  });
}
function authorize() {
  const done = () => {
    if (!active) return;
    store.state.socialEnabled = true;
    analytics.track('rank_opt', { on: true });
    store.save();
    load();
  };
  if (wx.authorize)
    wx.authorize({
      scope: 'scope.WxFriendInteraction',
      success: done,
      fail: () => {
        if (active) {
          status = '未获授权，可在微信设置中允许后重试';
          invalidate();
        }
      },
    });
  else done();
}
function enable() {
  notice.open({
    title: '开启成绩同步？',
    lines: ['仅上传总星数、通关数、', '数据版本和更新时间。', '不上传本地棋盘或金币。', '可随时关闭同步；云端旧成绩会保留。'],
    actions: [{ label: '暂不开启' }, { label: '同意并开启', run: authorize }],
  });
}
register('rank', {
  animating: (now) => !!context && now < liveUntil,
  enter() {
    active = true;
    liveUntil = 0;
    context = null;
    uploading = false;
    load();
  },
  leave() {
    active = false;
    token++;
    if (context)
      try {
        context.postMessage({ type: 'hide' });
      } catch (e) {}
    context = null;
  },
  draw(g) {
    ui.background(g, W, H);
    ui.text(g, '好友星光榜', W / 2, contentTop + 58 * DPR, 22 * DPR, '#ffcd75');
    const s = social.score();
    ui.text(g, '我的星光 ' + s.stars + ' ★ · ' + s.cleared + '/' + LV.length + ' 关', W / 2, contentTop + 89 * DPR, 12 * DPR, '#f4f4f4');
    ui.text(g, status, W / 2, contentTop + 113 * DPR, 10 * DPR, '#94b0c2');
    const b = board();
    ui.panel(g, b.x, b.y, b.w, b.h, 2 * DPR);
    if (context) g.drawImage(context.canvas, b.x, b.y, b.w, b.h);
    else {
      ui.text(g, '只展示同玩好友的已同步成绩', W / 2, b.y + b.h * 0.4, 12 * DPR, '#b5c9d6');
      ui.text(g, '昵称与排行在微信开放数据域展示', W / 2, b.y + b.h * 0.55, 10 * DPR, '#94b0c2');
    }
    buttons().forEach((b) => ui.btn(g, b, 2 * DPR));
  },
  onTap(x, y) {
    const b = ui.hit(buttons(), x, y);
    if (!b) return;
    if (b.id === 'back') {
      go('home');
      return;
    }
    if (b.id === 'share') {
      if (!social.share()) status = '当前环境不支持分享';
      return;
    }
    if (b.id === 'enable') {
      if (store.state.socialEnabled) {
        store.state.socialEnabled = false;
        analytics.track('rank_opt', { on: false });
        store.save();
        token++;
        uploading = false;
        if (context)
          try {
            context.postMessage({ type: 'hide' });
          } catch (e) {}
        context = null;
        status = '已关闭同步，云端历史成绩仍保留';
      } else enable();
      return;
    }
    if (!store.state.socialEnabled || uploading) return;
    if (b.id === 'refresh') {
      load();
      return;
    }
    if (context) {
      context.postMessage({ type: 'page', direction: b.id === 'next' ? 1 : -1 });
      liveUntil = Date.now() + 500;
    }
  },
});
