const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas');
const { register, go } = require('../engine/scene-manager');
const ui = require('../engine/ui');
const store = require('../engine/storage');
const policy = require('../engine/policy');
const wellbeing = require('../engine/wellbeing');
const analytics = require('../engine/analytics');
const perf = require('../engine/performance');
const CFG = require('../data/config');
const accessible = require('../engine/accessibility-preferences');
const notice = require('../engine/notice');
const music = require('../engine/music');
const feedback = require('../engine/feedback');
const volume = require('../engine/volume');
let page = 0;
function toggleReporting(key) {
  const settings = store.state.settings || (store.state.settings = {});
  settings[key] = !settings[key];
  store.save();
  analytics.refreshLogger();
}
function items() {
  return [
    { label: '用户协议', run: () => policy.show('agreement') },
    { label: '隐私保护指引', run: () => policy.show('privacy') },
    { label: '适度游戏提示', run: () => wellbeing.show() },
    {
      label: '休息提醒：' + (wellbeing.enabled() ? '开' : '静默'),
      run: () => {
        const s = store.state.settings || (store.state.settings = {});
        s.restReminders = !wellbeing.enabled();
        store.save();
      },
    },
    { label: '匿名玩法统计：' + (analytics.enabled() ? '开' : '关'), run: () => toggleReporting('analytics') },
    { label: '诊断日志：' + (analytics.diagnostics() ? '开' : '关'), run: () => toggleReporting('diagnostics') },
    {
      label: '画面装饰：' + (store.state.settings && store.state.settings.lowEffects ? '精简' : '完整'),
      run: () => perf.setLowEffects(!(store.state.settings && store.state.settings.lowEffects)),
    },
    { label: '统计与诊断说明', run: () => policy.reporting() },
    {
      label: '大字与大触控：' + (accessible.settings().largeText ? '开' : '关'),
      run: () => {
        accessible.set('largeText', !accessible.settings().largeText);
        store.save();
      },
    },
    {
      label: '高对比与颜色纹理：' + (accessible.settings().highContrast ? '开' : '关'),
      run: () => {
        accessible.set('highContrast', !accessible.settings().highContrast);
        store.save();
      },
    },
    {
      label: '大字与颜色辅助说明',
      run: () =>
        notice.open({
          title: '大字与颜色辅助',
          lines: [
            '大字操作台用大按钮选择菜单和棋盘格。',
            '逐格操作中，用行列按钮移动焦点。',
            '放置/旋转与取回都只操作当前格。',
            '红 R 竖纹 · 蓝 B 横纹',
            '绿 G 斜格 · 黄 Y 双点',
            '画面说明可分段阅读，随时返回标准布局。',
          ],
        }),
    },
    { label: '音乐：' + music.status(), run: () => music.setEnabled(!music.enabled()) },
    {
      label: '音量：' + volume.label(store.state.settings),
      run: () => {
        const s = store.state.settings || (store.state.settings = {});
        volume.cycle(s);
        store.save();
        feedback.play('place');
      },
    },
    { label: '意见反馈', run: () => go('player-feedback') },
  ];
}
function buttons() {
  const all = items(),
    pages = Math.ceil(all.length / 4);
  return [
    { id: 'home', label: '← 首页', x: W * 0.05, y: contentTop, w: 90 * DPR, h: 36 * DPR, run: () => go('home') },
    ...all
      .slice(page * 4, page * 4 + 4)
      .map((a, i) => ({ ...a, x: W * 0.08, y: contentTop + (92 + i * 54) * DPR, w: W * 0.84, h: 44 * DPR })),
    {
      id: 'version',
      label: 'v' + CFG.VERSION,
      x: W * 0.25,
      y: H - safeBottom - 58 * DPR,
      w: W * 0.5,
      h: 32 * DPR,
      run: () => perf.tapVersion(),
    },
    ...(pages > 1
      ? [
          {
            label: '上一页',
            x: W * 0.08,
            y: contentTop + 328 * DPR,
            w: W * 0.39,
            h: 40 * DPR,
            run: () => (page = (page + pages - 1) % pages),
          },
          { label: '下一页', x: W * 0.53, y: contentTop + 328 * DPR, w: W * 0.39, h: 40 * DPR, run: () => (page = (page + 1) % pages) },
        ]
      : []),
  ];
}
register('settings', {
  enter() {
    page = 0;
  },
  draw(g) {
    ui.background(g, W, H);
    ui.text(g, '协议与游戏偏好 · ' + (page + 1) + '/' + Math.ceil(items().length / 4), W / 2, contentTop + 62 * DPR, 20 * DPR, '#ffcd75');
    buttons().forEach((b) => ui.btn(g, b, 2 * DPR));
    ui.text(g, '本地存档 · 协议草案需确认', W / 2, H - safeBottom - 12 * DPR, 11 * DPR, '#94b0c2');
  },
  onTap(x, y) {
    const b = ui.hit(buttons(), x, y);
    if (b) b.run();
  },
});
