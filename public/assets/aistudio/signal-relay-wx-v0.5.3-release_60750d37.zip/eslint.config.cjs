// Verified 2026-10-30: https://eslint.org/docs/latest/use/configure/configuration-files
const runtimeGlobals = {
  wx: 'readonly',
  requestAnimationFrame: 'readonly',
  console: 'readonly',
  setTimeout: 'readonly',
  clearTimeout: 'readonly',
};
module.exports = [
  { ignores: ['node_modules/**', '.git/**'] },
  {
    files: ['**/*.js', '**/*.cjs'],
    languageOptions: { ecmaVersion: 2022, sourceType: 'commonjs', globals: runtimeGlobals },
    rules: {
      'no-undef': 'error',
      'no-dupe-keys': 'error',
      'no-unreachable': 'error',
      'valid-typeof': 'error',
    },
  },
  {
    files: ['js/**/*.js', 'open-data/**/*.js', 'music/**/*.js', 'game.js'],
    rules: {
      'no-restricted-syntax': [
        'error',
        ...['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].map((kind) => ({
          selector: kind + ' CallExpression[callee.name="require"]',
          message: 'Declare runtime dependencies at module scope.',
        })),
      ],
      'max-len': ['error', { code: 140, ignoreUrls: true }],
      'max-lines-per-function': ['error', { max: 80, skipBlankLines: true, skipComments: true }],
      'no-restricted-globals': ['error', 'window', 'document', 'localStorage', 'process', 'Buffer'],
      'no-restricted-modules': ['error', { patterns: ['node:*', 'fs', 'path', 'http', 'https', 'child_process', 'os', 'worker_threads'] }],
    },
  },
  {
    files: ['tools/**/*.js', '*.config.cjs'],
    languageOptions: {
      globals: { global: 'readonly', process: 'readonly', Buffer: 'readonly', __dirname: 'readonly' },
    },
  },
];
