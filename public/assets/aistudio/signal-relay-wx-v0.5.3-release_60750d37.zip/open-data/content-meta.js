// Generated content limits, shared-domain safe.
module.exports = { levelCount: 60 };
