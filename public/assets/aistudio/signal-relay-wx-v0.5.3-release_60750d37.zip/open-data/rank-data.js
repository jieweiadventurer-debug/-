const KEY = 'sr_score_v1';
const META = require('./content-meta');
function rows(data) {
  return (Array.isArray(data) ? data : [])
    .map((item) => {
      try {
        const kv = (item.KVDataList || []).find((v) => v.key === KEY),
          s = JSON.parse(kv.value);
        if (
          s.v !== 1 ||
          !Number.isInteger(s.stars) ||
          !Number.isInteger(s.cleared) ||
          s.cleared < 0 ||
          s.cleared > META.levelCount ||
          s.stars < s.cleared ||
          s.stars > s.cleared * 3
        )
          return null;
        return { name: String(item.nickname || '微信玩家').replace(/[\r\n\t]/g, ' '), stars: s.stars, cleared: s.cleared };
      } catch (e) {
        return null;
      }
    })
    .filter(Boolean)
    .sort((a, b) => b.stars - a.stars || b.cleared - a.cleared || a.name.localeCompare(b.name));
}
module.exports = { KEY, rows };
