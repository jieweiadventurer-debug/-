// Friend identities and scores never cross back into the main game context.
const { KEY, rows } = require('./rank-data');
const META = require('./content-meta');
const canvas = wx.getSharedCanvas(),
  g = canvas.getContext('2d');
let data = [],
  page = 0,
  active = false,
  request = 0,
  status = 'loading',
  timer = null;
function text(s, x, y, size, color, align = 'left') {
  g.font = 'bold ' + Math.round(size) + 'px sans-serif';
  g.fillStyle = color;
  g.textAlign = align;
  g.textBaseline = 'middle';
  g.fillText(s, x, y);
}
function draw() {
  const W = canvas.width,
    H = canvas.height,
    u = W / 300;
  g.clearRect(0, 0, W, H);
  g.fillStyle = '#333c57';
  g.fillRect(0, 0, W, H);
  if (status !== 'ready') {
    text(status === 'loading' ? '正在读取好友成绩…' : '暂时无法读取，请刷新重试', W / 2, H * 0.45, 12 * u, '#b5c9d6', 'center');
    return;
  }
  if (!data.length) {
    text('还没有可展示的好友成绩', W / 2, H * 0.4, 13 * u, '#b5c9d6', 'center');
    text('同玩好友开启榜单后才会出现', W / 2, H * 0.55, 11 * u, '#94b0c2', 'center');
    return;
  }
  const rh = H / 6;
  data.slice(page * 5, page * 5 + 5).forEach((r, i) => {
    const y = (i + 0.55) * rh;
    g.fillStyle = i % 2 ? '#333c57' : '#2a344e';
    g.fillRect(4 * u, i * rh, W - 8 * u, rh - 4 * u);
    text(String(page * 5 + i + 1), 18 * u, y, 13 * u, '#ffcd75');
    text([...r.name].slice(0, 8).join(''), 43 * u, y - 7 * u, 12 * u, '#f4f4f4');
    text(r.cleared + ' / ' + META.levelCount + ' 关', 43 * u, y + 11 * u, 10 * u, '#94b0c2');
    text(r.stars + ' ★', W - 16 * u, y, 14 * u, '#ffcd75', 'right');
  });
  text(page + 1 + ' / ' + Math.max(1, Math.ceil(data.length / 5)), W / 2, H - rh * 0.38, 11 * u, '#94b0c2', 'center');
}
wx.onMessage((m) => {
  if (m.type === 'hide') {
    clearTimeout(timer);
    active = false;
    request++;
    data = [];
    g.clearRect(0, 0, canvas.width, canvas.height);
    return;
  }
  if (m.type === 'page' && active) {
    page = Math.max(0, Math.min(Math.ceil(data.length / 5) - 1, page + (m.direction === 1 ? 1 : -1)));
    draw();
    return;
  }
  if (m.type !== 'show') return;
  // Shared canvas size is set in the main domain; open-data dimensions are read-only.
  clearTimeout(timer);
  active = true;
  page = 0;
  data = [];
  ((status = 'loading'), (timer = null));
  const id = ++request;
  draw();
  if (!wx.getFriendCloudStorage) {
    status = 'error';
    draw();
    return;
  }
  timer = setTimeout(() => {
    if (active && id === request) {
      status = 'error';
      request++;
      draw();
    }
  }, 10000);
  try {
    wx.getFriendCloudStorage({
      keyList: [KEY],
      success: (r) => {
        if (!active || id !== request) return;
        clearTimeout(timer);
        data = rows(r.data);
        status = 'ready';
        draw();
      },
      fail: () => {
        if (!active || id !== request) return;
        clearTimeout(timer);
        status = 'error';
        draw();
      },
    });
  } catch (e) {
    clearTimeout(timer);
    status = 'error';
    draw();
  }
});
