const store = require('./storage'),
  events = require('./events');
const volume = require('./volume');
let initialized = false,
  foreground = true,
  interrupted = false,
  loading = false,
  ready = false,
  audio = null,
  playing = false,
  realPlaying = false,
  wantPlay = false,
  memorySuspended = false;
const enabled = () => !!(store.state.settings && store.state.settings.music === true);
const status = () => (!enabled() ? '关' : loading ? '加载中' : playing ? '播放中' : '已暂停');
function changed() {
  events.emit('invalidate');
}
function fail() {
  loading = false;
  playing = false;
  realPlaying = false;
  wantPlay = false;
  if (audio) {
    const broken = audio;
    audio = null;
    try {
      if (typeof broken.destroy === 'function') broken.destroy();
    } catch (e) {}
    audio = null;
  }
  if (enabled()) {
    store.state.settings.music = false;
    store.save();
    events.emit('notice', { title: '音乐暂不可用', lines: ['本次未开启音乐，游戏可继续。', '联网后可在设置中重新开启。'] });
  }
  changed();
}
function play() {
  if (!enabled() || !foreground || interrupted || memorySuspended || !ready) return;
  try {
    if (!audio) {
      if (typeof wx.createInnerAudioContext !== 'function') {
        fail();
        return;
      }
      audio = wx.createInnerAudioContext();
      const voice = audio;
      // 真机教训：默认 obeyMuteSwitch=true 时 iPhone 静音拨片会把音乐也静掉，须显式关掉。
      try {
        voice.obeyMuteSwitch = false;
      } catch (e) {}
      if (typeof voice.onError === 'function')
        voice.onError(() => {
          if (audio === voice) fail();
        });
      // 真机教训：playing 不能只靠本地标志猜，要听真实播放/暂停事件，否则状态会显示「已暂停」却没人知道为什么。
      if (typeof voice.onPlay === 'function')
        voice.onPlay(() => {
          if (audio !== voice) return;
          realPlaying = true;
          playing = true;
          wantPlay = false;
          changed();
        });
      if (typeof voice.onPause === 'function')
        voice.onPause(() => {
          if (audio !== voice) return;
          realPlaying = false;
          playing = false;
          changed();
        });
      if (typeof voice.onCanplay === 'function')
        voice.onCanplay(() => {
          // 刚设 src 同一拍的 play 在真机常被吞，解码就绪且仍未真播时直接补播一次。
          if (audio !== voice || !wantPlay || realPlaying) return;
          if (!enabled() || !foreground || interrupted || memorySuspended) return;
          try {
            voice.play();
          } catch (e) {
            fail();
          }
        });
      voice.loop = true;
      voice.volume = volume.music(store.state.settings);
      voice.src = 'music/relay-loop.mp3';
    }
    if (playing) return;
    audio.volume = volume.music(store.state.settings);
    wantPlay = true;
    const promise = audio.play();
    playing = true;
    if (promise && typeof promise.catch === 'function') promise.catch(fail);
    changed();
  } catch (e) {
    fail();
  }
}
function ensure() {
  if (!enabled()) return;
  if (ready) {
    play();
    return;
  }
  if (loading) return;
  // Checked 2026-10-30 against official minigame-api-typings and linked API pages.
  // https://developers.weixin.qq.com/minigame/dev/api/base/subpackage/wx.loadSubpackage.html
  // https://developers.weixin.qq.com/minigame/dev/api/media/audio/wx.createInnerAudioContext.html
  if (typeof wx.loadSubpackage !== 'function') {
    fail();
    return;
  }
  loading = true;
  changed();
  try {
    wx.loadSubpackage({
      name: 'music',
      success() {
        loading = false;
        ready = true;
        play();
        changed();
      },
      fail,
    });
  } catch (e) {
    fail();
  }
}
function pause() {
  wantPlay = false;
  realPlaying = false;
  try {
    if (audio && typeof audio.pause === 'function') audio.pause();
  } catch (e) {}
  playing = false;
  changed();
}
function release() {
  memorySuspended = true;
  pause();
  const voice = audio;
  audio = null;
  try {
    if (voice && typeof voice.destroy === 'function') voice.destroy();
  } catch (e) {}
}
function setEnabled(value) {
  if (value) memorySuspended = false;
  if (!store.state.settings) store.state.settings = {};
  store.state.settings.music = !!value;
  store.save();
  if (value) ensure();
  else pause();
  changed();
}
function init() {
  if (initialized) return;
  initialized = true;
  if (typeof wx.onHide === 'function')
    wx.onHide(() => {
      foreground = false;
      pause();
    });
  if (typeof wx.onShow === 'function')
    wx.onShow(() => {
      foreground = true;
      memorySuspended = false;
      ensure();
    });
  if (typeof wx.onAudioInterruptionBegin === 'function')
    wx.onAudioInterruptionBegin(() => {
      interrupted = true;
      pause();
    });
  if (typeof wx.onAudioInterruptionEnd === 'function')
    wx.onAudioInterruptionEnd(() => {
      interrupted = false;
      ensure();
    });
  ensure();
}
function syncVolume() {
  if (!audio) return;
  try {
    audio.volume = volume.music(store.state.settings);
  } catch (e) {}
}
module.exports = { init, setEnabled, enabled, status, release, syncVolume };

