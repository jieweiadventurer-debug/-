// 未完成关卡快照：读取时校验棋盘、库存守恒和撤回记录。
const store = require('./storage');
const LV = require('../data/levels');
const MAX_HISTORY = 50;
const { parseLevel } = require('../core/propagate');
function validState(level, b, inv) {
  const { R, C, fix } = parseLevel(level),
    counts = { s: 0, c: 0, t: 0, a: 0 };
  if (!Array.isArray(b) || b.length !== R || !inv) return false;
  for (let r = 0; r < R; r++) {
    if (!Array.isArray(b[r]) || b[r].length !== C) return false;
    for (let c = 0; c < C; c++) {
      const p = b[r][c];
      if (p === null) continue;
      if (
        !p ||
        !Object.prototype.hasOwnProperty.call(counts, p.t) ||
        !Number.isInteger(p.k) ||
        p.k < 0 ||
        p.k > 3 ||
        (fix[r][c] && fix[r][c].k !== 'star')
      )
        return false;
      counts[p.t]++;
    }
  }
  return Object.keys(counts).every((k) => Number.isInteger(inv[k]) && inv[k] >= 0 && inv[k] + counts[k] === (level.inv[k] || 0));
}
const history = require('./run-history');
function read(level, r = store.state.runs && store.state.runs[level.id]) {
  if (
    !r ||
    ![1, 2].includes(r.version) ||
    r.signature !== JSON.stringify(level) ||
    !validState(level, r.board, r.inv) ||
    !Number.isInteger(r.undoUsed) ||
    r.undoUsed < 0 ||
    !Number.isFinite(r.elapsed) ||
    r.elapsed < 0
  )
    return null;
  let hist = Array.isArray(r.hist) ? r.hist.slice(-MAX_HISTORY) : [];
  try {
    if (r.version === 1) hist = history.migrate(hist, r.board, r.inv, (b, i) => validState(level, b, i));
    const b = JSON.parse(JSON.stringify(r.board)),
      i = { ...r.inv };
    for (let n = hist.length - 1; n >= 0; n--) {
      history.undo(b, i, hist[n]);
      if (!validState(level, b, i)) throw Error('Invalid undo state');
    }
  } catch (e) {
    hist = [];
  }
  return JSON.parse(JSON.stringify({ ...r, version: 2, hist }));
}
function encode(level, data) {
  return JSON.parse(
    JSON.stringify(
      Object.assign({ version: 2, signature: JSON.stringify(level) }, data, {
        hist: Array.isArray(data.hist) ? data.hist.slice(-MAX_HISTORY) : data.hist,
      }),
    ),
  );
}
function write(level, data) {
  if (!store.state.runs || typeof store.state.runs !== 'object' || Array.isArray(store.state.runs)) store.state.runs = {};
  store.state.runs[level.id] = encode(level, data);
  store.state.activeRun = level.id;
  const latest = store.state.runs[level.id];
  delete store.state.runs[level.id];
  store.state.runs[level.id] = latest;
  prune();
  store.save();
}
function replacement(level) {
  const all = store.state.runs || {};
  if (Object.prototype.hasOwnProperty.call(all, level.id) || Object.keys(all).length < 5) return null;
  return Object.keys(all).filter((id) => id !== store.state.activeRun)[0] || Object.keys(all)[0];
}
function prune() {
  const all = store.state.runs || {},
    keys = Object.keys(all).filter((id) => id !== store.state.activeRun);
  while (Object.keys(all).length > 5 && keys.length) delete all[keys.shift()];
}
function clear(level) {
  if (store.state.runs) delete store.state.runs[level.id];
  if (store.state.activeRun === level.id) delete store.state.activeRun;
  store.save();
  store.flush();
}
function active() {
  const i = LV.findIndex((l) => l.id === store.state.activeRun);
  return i >= 0 && read(LV[i]) ? i : -1;
}
prune();
module.exports = { read, write, clear, active, MAX_HISTORY, encode, replacement, ...history };
