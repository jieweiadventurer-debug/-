const { W, H, DPR, contentTop, safeBottom } = require('../engine/canvas');
const { register, go } = require('../engine/scene-manager');
const { chapters } = require('../core/world');
const LV = require('../data/levels');
const store = require('../engine/storage');
const ui = require('../engine/ui');
const { bake } = require('../data/sprites');
const colors = ['#a7f070', '#5fe36c', '#73eff7', '#ef7d57', '#b3a6ff', '#41a6f6'];
let rows = [],
  buttons = [];
function building(g, x, y, u, chapter) {
  const n = chapter.index,
    lit = chapter.cleared > 0,
    col = lit ? colors[n] : '#566c86';
  g.fillStyle = '#1a1c2c';
  g.fillRect(x - 14 * u, y - 18 * u, 28 * u, 32 * u);
  // Each region develops a distinct silhouette, with repair segments filling bottom-up.
  const width = n === 2 ? 12 : n === 4 ? 8 : 20;
  for (let j = 0; j < 4; j++) {
    const repaired = chapter.cleared > j * 2;
    g.fillStyle = repaired ? '#566c86' : '#333c57';
    g.fillRect(x - (width * u) / 2, y - j * 5 * u, width * u, 4 * u);
  }
  g.fillStyle = lit ? col : '#566c86';
  g.fillRect(x - 7 * u, y - 21 * u, 14 * u, 5 * u);
  g.fillStyle = lit ? '#f4f4f4' : '#333c57';
  g.fillRect(x - 3 * u, y - 20 * u, 6 * u, 3 * u);
  if (lit) {
    g.fillStyle = col;
    g.globalAlpha = 0.18;
    g.fillRect(x - 13 * u, y - 22 * u, 26 * u, 7 * u);
    g.globalAlpha = 1;
  }
  if (n === 1) {
    g.fillStyle = col;
    g.fillRect(x - 17 * u, y + 5 * u, 34 * u, 3 * u);
  }
  if (n === 3) {
    g.fillStyle = col;
    g.fillRect(x + 9 * u, y - 12 * u, 5 * u, 12 * u);
  }
  if (n === 5) {
    g.fillStyle = col;
    for (const d of [-1, 1]) {
      g.fillRect(x + d * 13 * u, y - 25 * u, 2 * u, 30 * u);
      g.fillRect(x + d * 13 * u - 3 * u, y - 28 * u, 8 * u, 3 * u);
    }
  }
  if (n === 4) {
    g.globalAlpha = lit ? 1 : 0.25;
    g.drawImage(bake('star', u), x - 4 * u, y - 30 * u);
    g.globalAlpha = 1;
  }
}
register('world', {
  enter() {
    rows = chapters(store.state.stars);
    buttons = [];
    buttons.push({ id: 'home', x: W * 0.05, y: contentTop, w: W * 0.22, h: 36 * DPR, label: '← 首页', fs: 12 * DPR });
    const y0 = contentTop + 104 * DPR,
      gap = 10 * DPR,
      rh = Math.min(112 * DPR, (H - safeBottom - y0 - (rows.length - 1) * gap) / rows.length);
    rows.forEach((r, i) =>
      buttons.push({ id: 'chapter:' + i, x: W * 0.05, y: y0 + i * (rh + gap), w: W * 0.9, h: rh, label: '', chapter: r }),
    );
  },
  draw(g) {
    ui.background(g, W, H);
    const total = rows.reduce((n, r) => n + r.cleared, 0);
    ui.text(g, '已接通 ' + total + ' / ' + LV.length, W * 0.95, contentTop + 18 * DPR, 12 * DPR, '#94b0c2', 'right');
    ui.text(g, '接力修复地图', W * 0.5, contentTop + 55 * DPR, 22 * DPR, '#ffcd75');
    ui.text(g, '每完成一关，世界就多一束光', W * 0.5, contentTop + 82 * DPR, 11 * DPR, '#94b0c2');
    buttons.forEach((b) => {
      if (!b.chapter) {
        ui.btn(g, b, 2 * DPR);
        return;
      }
      const r = b.chapter;
      ui.btn(g, b, 2 * DPR);
      if (r.unlocked && !r.restored) {
        g.fillStyle = colors[r.index];
        g.fillRect(b.x + 2 * DPR, b.y + 2 * DPR, 3 * DPR, b.h - 4 * DPR);
      }
      const u = Math.max(1, Math.floor(Math.min(b.h / 42, 2 * DPR)));
      building(g, b.x + 36 * DPR, b.y + b.h * 0.63, u, r);
      const x = b.x + 72 * DPR;
      ui.text(g, r.index + 1 + '  ' + r.name, x, b.y + b.h * 0.23, 14 * DPR, r.unlocked ? '#f4f4f4' : '#94b0c2', 'left');
      ui.text(
        g,
        r.unlocked
          ? r.restored
            ? '✓ 已修复 · ' + r.totalStars + '/30 星'
            : '下一关 ' + r.nextId + ' · ' + r.cleared + '/10 已接通'
          : '通关 ' + r.index + '-10 后解锁',
        x,
        b.y + b.h * 0.52,
        11 * DPR,
        r.restored ? colors[r.index] : '#94b0c2',
        'left',
      );
      const nodeGap = (b.w - 90 * DPR) / 10;
      for (let j = 0; j < 10; j++) {
        g.fillStyle = (store.state.stars[r.index + 1 + '-' + (j + 1)] || 0) > 0 ? colors[r.index] : '#1a1c2c';
        g.fillRect(x + j * nodeGap, b.y + b.h * 0.75, nodeGap - 4 * DPR, 5 * DPR);
      }
      ui.text(g, r.unlocked ? '进入' : '锁', b.x + b.w - 23 * DPR, b.y + b.h * 0.4, 11 * DPR, r.unlocked ? '#ffcd75' : '#94b0c2');
    });
  },
  onTap(x, y) {
    const b = ui.hit(buttons, x, y);
    if (!b) return;
    if (b.id === 'home') {
      go('home');
      return;
    }
    if (!b.chapter.unlocked) {
      if (wx.showToast) wx.showToast({ title: '先完成上一章，接通信号', icon: 'none' });
      return;
    }
    store.state.ch = b.chapter.index;
    store.save();
    go('levels');
  },
});
