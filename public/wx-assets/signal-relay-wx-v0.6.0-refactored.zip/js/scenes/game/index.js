const state = {
  dailyDate: null,
  hintsUsed: 0,
  lesson: null,
  hint: null,
  hintStage: 0,
  hintOpen: false,
  checkCells: [],
  checkUntil: 0,
  elapsedBase: 0,
  selectedColor: null,
  goalsOpen: false,
  guideTab: false,
  guideIndex: 0,
  guideTopics: [],
  reward: 0,
  introAt: 0,
  coach: '',
  coachUntil: 0,
  inspection: '',
  inspectionUntil: 0,
  flowAt: 0,
  change: null,
  winAt: 0,
  idx: undefined,
  L: undefined,
  fix: undefined,
  R: undefined,
  C: undefined,
  board: undefined,
  inv: undefined,
  sel: undefined,
  hist: undefined,
  res: undefined,
  u: undefined,
  cs: undefined,
  bx: undefined,
  by: undefined,
  btns: undefined,
  undoUsed: undefined,
  won: undefined,
  t0: undefined,
};
const { W, H, safeTop, unitFor, DPR, contentTop, safeBottom } = require('../../engine/canvas');
const { register, go } = require('../../engine/scene-manager');
const ui = require('../../engine/ui');
const store = require('../../engine/storage');
const CFG = require('../../data/config');
const LV = require('../../data/levels');
const { bake } = require('../../data/sprites');
const starMarker = require('../../engine/star-marker');
const { parseLevel, propagate, portsOf, DV } = require('../../core/propagate');
const S = store.state;
const { diagnose, checkRoute } = require('../../core/diagnostics');
const tutorial = require('../../core/tutorial');
const practice = require('../../core/practice');

const runs = require('../../engine/runs');
const progress = require('../../engine/progress');
const feedback = require('../../engine/feedback');
const analytics = require('../../engine/analytics');
const accessible = require('./accessibility');
const social = require('../../engine/social');
const daily = require('../../engine/daily');
const entry = require('../../engine/level-entry');
const { invalidate } = require('../../engine/scene-manager');
const { nextHint, applyHint } = require('../../core/hints');

const colorNames = { red: '红', blue: '蓝', green: '绿', yellow: '黄' };
const colorMarks = { red: 'R', blue: 'B', green: 'G', yellow: 'Y' };
const directions = { U: '上', R: '右', D: '下', L: '左' };
const flowMs = () => {
  const o = progress.sync().settings;
  return o.reduceMotion ? 0 : o.flow;
};

function elapsed() {
  return state.elapsedBase + (state.t0 ? Date.now() - state.t0 : 0);
}
function saveRun() {
  if (!state.L || state.won) return;
  const data = {
    board: state.board,
    inv: state.inv,
    hist: state.hist,
    undoUsed: state.undoUsed,
    hintsUsed: state.hintsUsed,
    sel: state.sel,
    elapsed: elapsed(),
    started: !!state.t0 || state.elapsedBase > 0,
  };
  if (state.dailyDate) daily.saveRun(state.L, state.dailyDate, data);
  else runs.write(state.L, data);
}
function resolveEntry(arg) {
  const today = arg && arg.daily ? daily.current() : null;
  const i = today ? 0 : typeof arg === 'object' ? arg.index : arg;
  const level = today ? today.level : LV[i || 0],
    resume = arg && arg.resume;
  return {
    i: i || 0,
    level,
    date: today ? today.day : null,
    saved: resume ? (today ? daily.readRun(level, today.day) : runs.read(level)) : null,
  };
}
function restart() {
  if (state.dailyDate && state.dailyDate !== daily.day()) {
    go('daily');
    return;
  }
  scene.enter(state.dailyDate ? { daily: true } : state.idx);
}
function starGoals() {
  const stars = state.fix.flat().filter((f) => f && f.k === 'star').length,
    collected = [...state.res.lit.keys()].filter((key) => {
      const [r, c] = key.split(',').map(Number);
      return state.fix[r][c] && state.fix[r][c].k === 'star';
    }).length;
  return [
    { ok: state.res.win, text: '接通全部同色接收端' },
    { ok: used() <= state.L.par, text: '管件不超过 ' + state.L.par + ' 个（当前 ' + used() + '）' },
    {
      ok: stars ? collected === stars : state.undoUsed === 0,
      text: stars ? '收集全部星点（' + collected + '/' + stars + '）' : '不使用撤回（已用 ' + state.undoUsed + ' 次）',
    },
  ];
}

const CHAPTER_LINES = [
  '让第一束信号穿过晨光草原',
  '穿过森林，接通彼此的颜色',
  '跨越海岸，让灯塔重新亮起',
  '用分流与增幅穿过峡谷',
  '把星光送到云端的星塔',
  '让极光穿过群岛，延续新的接力',
];
function say(s, inspect) {
  state.coach = s;
  state.coachUntil = Date.now() + 3500;
  if (inspect) {
    state.inspection = s;
    state.inspectionUntil = Date.now() + 5000;
  }
}
const BASE = { s: ['L', 'R'], c: ['L', 'U'], t: ['L', 'U', 'D'], a: ['L', 'R'] };
const NAMES = { s: '直线', c: '拐角', t: '三通', a: '增幅' };

// 工具图标以可见轮廓的包围盒居中，不使用棋盘格的中心。

function recalc() {
  state.flowAt = Date.now();
  state.res = propagate(state.R, state.C, state.fix, state.board, state.L.range === undefined ? null : state.L.range);
}
function snap(r, c) {
  state.hist.push(runs.capture(state.board, state.inv, r, c));
  const dropped = state.hist.length > runs.MAX_HISTORY ? state.hist.shift() : null;
  if (!state.t0) state.t0 = Date.now();
  return dropped;
}
function cellAt(x, y) {
  const c = Math.floor((x - state.bx) / state.cs),
    r = Math.floor((y - state.by) / state.cs);
  return r >= 0 && c >= 0 && r < state.R && c < state.C ? { r, c } : null;
}
function used() {
  return state.board.flat().filter(Boolean).length;
}
function afterChange() {
  runs.seal(state.hist[state.hist.length - 1], state.inv);
  if (state.inspection) {
    state.coach = '';
    state.coachUntil = 0;
  }
  state.inspection = '';
  state.inspectionUntil = 0;
  state.checkCells = [];
  state.checkUntil = 0;
  state.hint = null;
  state.hintOpen = false;
  recalc();
  layout();
  if (state.res.bad.size) say('信号冲突了，检查红框中的交叉连接');
  else if (state.res.win) say('全部节点已点亮！这一程接力完成了');
  else if (state.res.reached.size) say('节点已点亮！继续连接其余目标');
  if (state.res.win && !state.won) finish();
  saveRun();
}
function finish() {
  state.won = true;
  state.winAt = Date.now();
  let total = 0,
    collected = 0;
  state.fix.forEach((row, r) =>
    row.forEach((f, c) => {
      if (f && f.k === 'star') {
        total++;
        if (state.res.lit.has(r + ',' + c)) collected++;
      }
    }),
  );
  const ok2 = used() <= state.L.par,
    ok3 = total ? collected === total : state.undoUsed === 0;
  const n = 1 + (ok2 ? 1 : 0) + (ok3 ? 1 : 0);
  const sec = Math.round(elapsed() / 1000);
  state.reward = state.dailyDate ? daily.complete(state.L, state.dailyDate, n, sec) : progress.cleared(state.L.id, n, sec, ok2);
  analytics.track('level_win', { id: state.L.id, stars: n, sec, used: used(), par: ok2, undo: state.undoUsed, hints: state.hintsUsed });
  feedback.play('win');
  S.threeStarStreak = n === 3 ? (S.threeStarStreak || 0) + 1 : 0;
  const streakMaster = S.threeStarStreak >= 3;
  const streakBonus = streakMaster ? 50 : 0;
  if (streakBonus > 0) { S.coins = (S.coins || 0) + streakBonus; state.reward += streakBonus; }
  state.won = { n, sec, streakMaster, streakBonus, threeStarStreak: S.threeStarStreak };
  if (state.dailyDate) daily.clearRun(state.L, state.dailyDate);
  else runs.clear(state.L);
}

function act(k) {
  if (k === 'undo') {
    if (!state.hist.length) {
      say('已经没有可以撤回的操作');
      return;
    }
    runs.undo(state.board, state.inv, state.hist.pop());
    state.undoUsed++;
    state.won = false;
    afterChange();
  } else if (k === 'reset') {
    if (used() && wx.showModal)
      wx.showModal({
        title: '重新开始这一关？',
        content: '清空本关已放置的管件，不额外消耗体力。',
        confirmText: '重新开始',
        success: (r) => {
          if (r.confirm) {
            restart();
            invalidate();
          }
        },
      });
    else restart();
  } else if (k === 'back') go(state.dailyDate ? 'daily' : 'levels');
  else if (k === 'replay') {
    state.flowAt = Date.now();
    say('看，信号正沿着接通的路线前进');
  }
}
const context = {
  state,
  flowMs,
  bake,
  CFG,
  DV,
  colorMarks,
  starMarker,
  S,
  portsOf,
  ui,
  DPR,
  contentTop,
  H,
  safeBottom,
  unitFor,
  W,
  NAMES,
  BASE,
  directions,
  checkRoute,
  say,
  nextHint,
  snap,
  applyHint,
  feedback,
  afterChange,
  diagnose,
  used,
  colorNames,
  starGoals,
  practice,
  store,
  analytics,
  social,
  daily,
};
const { pipe, drawBoard, drawEndpoint } = require('./board-render')(context);
Object.assign(context, { pipe, drawBoard, drawEndpoint });
const { layout, navigation, toolIcon, drawToolbar } = require('./toolbar')(context);
Object.assign(context, { layout, navigation, toolIcon, drawToolbar });
const { hintBox, drawHint, hintTap } = require('./hint-panel')(context);
Object.assign(context, { hintBox, drawHint, hintTap });
const { drawInspection, inspectFixed } = require('./inspection')(context);
Object.assign(context, { drawInspection, inspectFixed });
const { goalsBox, guideButtons, drawGoals, guideTap } = require('./tutorial-ui')(context);
Object.assign(context, { goalsBox, guideButtons, drawGoals, guideTap });
const { winBox, winButtons, drawWin } = require('./win-overlay')(context);
Object.assign(context, { winBox, winButtons, drawWin });

function winRevealAt() {
  return state.winAt + Math.max(0, ...state.res.depth.values()) * flowMs() + 220;
}
function animating(now) {
  if (progress.sync().settings.reduceMotion) return false;
  const flowDuration = Math.max(0, ...state.res.depth.values(), ...state.res.bridgeDepth.values()) * flowMs();
  return !!(
    (flowDuration && now < state.flowAt + flowDuration) ||
    (state.change && now < state.change.at + (state.change.kind === 'rotate' ? 140 : 180)) ||
    (state.introAt && now < state.introAt + 1600) ||
    (state.won && now <= winRevealAt())
  );
}
function nextFrameAt(now) {
  const deadlines = [state.coachUntil, state.inspectionUntil, state.checkUntil];
  if (state.t0 && !state.won) deadlines.push(now + 1000 - (Math.max(0, elapsed()) % 1000));
  if (state.won) deadlines.push(winRevealAt() + 1);
  return Math.min(Infinity, ...deadlines.filter((time) => time > now));
}
const scene = {
  animating,
  nextFrameAt,
  canUpdate: (now) => !!state.won && now > winRevealAt(),
  leave() {
    if (!state.won) {
      state.elapsedBase = elapsed();
      state.t0 = 0;
    }
    if (!state.won) analytics.track('level_quit', { id: state.L.id, sec: Math.round(elapsed() / 1000), used: used() });
    saveRun();
  },
  pause() {
    if (!state.L || state.won) return;
    state.elapsedBase = elapsed();
    state.t0 = 0;
    saveRun();
  },
  resume() {
    if (!state.won && state.elapsedBase > 0 && !state.t0) state.t0 = Date.now();
  },
  enter(arg) {
    const { i, level, date, saved } = resolveEntry(arg);
    state.dailyDate = date;
    state.selectedColor = null;
    state.goalsOpen = false;
    state.guideTab = false;
    state.guideIndex = 0;
    state.guideTopics = tutorial.topics(level);
    state.elapsedBase = 0;
    state.hint = null;
    state.hintOpen = false;
    state.hintStage = 0;
    state.hintsUsed = saved && Number.isSafeInteger(saved.hintsUsed) && saved.hintsUsed >= 0 ? saved.hintsUsed : 0;
    state.checkCells = [];
    state.checkUntil = 0;
    state.lesson = null;
    state.idx = i;
    state.L = level;
    state.introAt = !state.dailyDate && i % 10 === 0 && !S.seen['chapter:' + Math.floor(i / 10)] ? Date.now() : 0;
    if (state.introAt) {
      S.seen['chapter:' + Math.floor(i / 10)] = true;
      store.save();
    }
    state.coach = '';
    state.coachUntil = 0;
    state.inspection = '';
    state.inspectionUntil = 0;
    ({ R: state.R, C: state.C, fix: state.fix } = parseLevel(state.L));
    state.board = state.fix.map((r) => r.map(() => null));
    state.inv = Object.assign({}, state.L.inv);
    state.hist = [];
    state.undoUsed = 0;
    state.won = false;
    state.t0 = 0;
    if (saved) {
      state.board = saved.board;
      state.inv = saved.inv;
      state.hist = saved.hist;
      state.undoUsed = saved.undoUsed;
      state.elapsedBase = saved.elapsed;
      state.t0 = saved.started ? Date.now() : 0;
    }
    state.change = null;
    state.sel = ['s', 'c', 't', 'a'].find((k) => state.inv[k] > 0);
    if (saved && state.inv[saved.sel] > 0) state.sel = saved.sel;
    recalc();
    layout();
    analytics.track('level_start', { id: state.L.id });
    saveRun();
    const topic = !saved && tutorial.firstUnread(state.L, S.seen);
    if (topic) {
      state.guideTab = true;
      state.guideIndex = state.guideTopics.findIndex((t) => t.id === topic.id);
      state.goalsOpen = true;
    }
    if (
      new Set(
        state.fix
          .flat()
          .filter((f) => f && f.k === 'src')
          .map((f) => f.col),
      ).size > 1 &&
      !S.seen.colorPairs
    ) {
      S.seen.colorPairs = true;
      store.save();
      say('同色同字母配对；点击端点，高亮它的同色伙伴');
      state.coachUntil = Date.now() + 8000;
    }
    store.flush();
  },
  draw(g) {
    ui.background(g, W, H);
    navigation().forEach((b) => ui.btn(g, b, 2 * DPR));
    ui.panel(g, W * 0.04, contentTop + 48 * DPR, W * 0.92, 36 * DPR, 2 * DPR);
    ui.text(
      g,
      (state.dailyDate ? '每日挑战 · ' : '第 ' + state.L.id + ' 关  ·  ') +
        '目标 ' +
        state.res.reached.size +
        '/' +
        state.res.total +
        (state.L.range ? '  射程 ' + state.L.range : ''),
      W * 0.06,
      contentTop + 66 * DPR,
      11 * DPR,
      '#f4f4f4',
      'left',
    );
    drawBoard(g);
    drawToolbar(g);
    drawInspection(g);
    if (state.introAt && Date.now() - state.introAt < 1600 && !S.settings.reduceMotion) {
      const age = Date.now() - state.introAt;
      g.globalAlpha = Math.min(1, age / 200, (1600 - age) / 250);
      ui.panel(g, W * 0.07, H * 0.32, W * 0.86, H * 0.22, Math.max(2, state.u));
      ui.text(g, 'CHAPTER ' + (Math.floor(state.idx / 10) + 1), W / 2, H * 0.36, W * 0.035, '#94b0c2');
      ui.text(g, CFG.CHAPTERS[Math.floor(state.idx / 10)], W / 2, H * 0.42, W * 0.08, '#ffcd75');
      ui.text(g, CHAPTER_LINES[Math.floor(state.idx / 10)], W / 2, H * 0.49, W * 0.03);
      g.globalAlpha = 1;
    }
    if (state.t0)
      ui.text(
        g,
        Math.floor((state.won ? state.won.sec * 1000 : elapsed()) / 60000)
          .toString()
          .padStart(2, '0') +
          ':' +
          (Math.floor((state.won ? state.won.sec * 1000 : elapsed()) / 1000) % 60).toString().padStart(2, '0'),
        W * 0.94,
        contentTop + 66 * DPR,
        11 * DPR,
        '#94b0c2',
        'right',
      );
    if (state.hintOpen && state.hint) drawHint(g);
    if (state.goalsOpen) drawGoals(g);
    if (state.lesson) practice.draw(g, state.lesson);
    if (state.won && Date.now() - state.winAt > Math.max(0, ...state.res.depth.values()) * flowMs() + 220) drawWin(g);
  },
  onTap(x, y) {
    state.introAt = 0;
    if (state.lesson) {
      if (practice.tap(state.lesson, x, y)) {
        state.lesson = null;
      }
      return;
    }
    if (state.goalsOpen) {
      guideTap(x, y);
      return;
    }
    if (state.hintOpen) {
      hintTap(x, y);
      return;
    }
    if (state.won) {
      handleWinTap(x, y);
      return;
    }
    const nav = ui.hit(navigation(), x, y);
    if (nav && nav.id === 'goals') {
      state.guideTab = false;
      state.goalsOpen = true;
      return;
    }
    if (nav && nav.id === 'home') {
      go('home');
      return;
    }
    if (nav && nav.id === 'levels') {
      if (!state.dailyDate) S.ch = Math.floor(state.idx / 10);
      go(state.dailyDate ? 'daily' : 'levels');
      return;
    }
    if (!state.won && nav && nav.id === 'hint') {
      openHint();
      return;
    }
    const b = ui.hit(state.btns, x, y);
    if (b) {
      if (b.id.startsWith('tool:')) {
        const k = b.id.slice(5);
        selectTool(k);
      } else act(b.id);
      return;
    }
    const p = cellAt(x, y);
    if (!p) return;
    const f = state.fix[p.r][p.c],
      pc = state.board[p.r][p.c];
    if (f && f.k !== 'star') {
      analytics.track('inspect_used');
      inspectFixed(f);
      return;
    }
    if (pc) {
      snap(p.r, p.c);
      feedback.play('rotate');
      state.change = { r: p.r, c: p.c, at: Date.now(), kind: 'rotate' };
      pc.k = (pc.k + 1) % 4;
      afterChange();
      return;
    }
    if (!state.sel || state.inv[state.sel] <= 0) {
      say('管件用完了：长按取回，或撤回上一步');
      return;
    }
    snap(p.r, p.c);
    feedback.play('place');
    state.change = { r: p.r, c: p.c, at: Date.now(), kind: 'pop' };
    state.board[p.r][p.c] = { t: state.sel, k: 0 };
    state.inv[state.sel]--;
    if (state.inv[state.sel] === 0) state.sel = ['s', 'c', 't', 'a'].find((k) => state.inv[k] > 0) || state.sel;
    afterChange();
  },
  onLong(x, y) {
    if (state.won || state.hintOpen || state.goalsOpen || state.lesson) return false;
    const p = cellAt(x, y);
    if (!p) return false;
    const pc = state.board[p.r][p.c];
    if (!pc) return false;
    snap(p.r, p.c);
    state.inv[pc.t]++;
    state.board[p.r][p.c] = null;
    state.sel = state.sel && state.inv[state.sel] > 0 ? state.sel : pc.t;
    afterChange();
  },
  cellXY(r, c) {
    return { x: state.bx + c * state.cs + state.cs / 2, y: state.by + r * state.cs + state.cs / 2 };
  },
  get won() {
    return state.won;
  },
};
scene.accessibilityInfo = () => accessible.info(context, scene);
scene.accessibilityButtons = (all) => accessible.buttons({ ...context, guideButtons, winButtons }, all);
register('game', scene);

function handleWinTap(x, y) {
  if (Date.now() - state.winAt <= Math.max(0, ...state.res.depth.values()) * flowMs() + 220) return;
  const action = ui.hit(winButtons(), x, y);
  if (action) {
    if (state.dailyDate) {
      if (action.id === 'retry') restart();
      else go(action.id === 'levels' ? 'daily' : 'home');
      return;
    }
    if (action.id === 'timeline') {
      social.prepareTimeline(state.L.id);
      return;
    }
    if (action.id === 'levels') {
      S.ch = Math.floor(state.idx / 10);
      go('levels');
    } else if (action.id === 'retry') {
      scene.enter(state.idx);
      say('新一轮开始了，试试拿满三星吧');
    } else if (state.idx % 10 === 9 || state.idx + 1 >= LV.length) go('celebration', Math.floor(state.idx / 10));
    else {
      const index = state.idx + 1;
      entry.enter(
        index,
        () => scene.enter({ index, resume: true }),
        () => {
          if (wx.showToast) wx.showToast({ title: '体力不足，请返回首页兑换', icon: 'none' });
        },
      );
    }
  }
  return;
}

function selectTool(k) {
  if (state.inv[k] > 0) {
    state.sel = k;
    layout();
  }
}

function openHint() {
  state.hint = nextHint(state.L, state.board);
  state.hintStage = 0;
  state.hintOpen = !!state.hint;
  if (state.hint) {
    state.hintsUsed++;
    analytics.track('hint_used', { phase: 0 });
  } else say('当前路线已完整，检查信号是否抵达目标');
}
