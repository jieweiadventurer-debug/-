function _winBox(context) {
  const { DPR, H, contentTop, safeBottom, W, state, social } = context;
  const h = Math.min(
    (state.won && !state.dailyDate && state.won.n === 3 && social.timelineAvailable() ? 400 : 340) * DPR,
    H - contentTop - safeBottom - 16 * DPR,
  );
  return { x: W * 0.07, y: Math.max(contentTop, (H - h) / 2), w: W * 0.86, h };
}
function _winButtons(context) {
  const { winBox, DPR, state, social } = context;
  const m = winBox(),
    gap = 8 * DPR,
    w = (m.w - 32 * DPR - 2 * gap) / 3;
  return [
    { id: "levels", label: state.dailyDate ? "每日挑战" : "选关" },
    { id: "retry", label: state.dailyDate ? "再练一次" : "再挑战" },
    { id: "next", label: state.dailyDate ? "返回首页" : state.idx % 10 === 9 ? "查看修复" : "下一关", primary: true },
  ]
    .map((b, i) => Object.assign(b, { x: m.x + 16 * DPR + i * (w + gap), y: m.y + m.h - 60 * DPR, w, h: 42 * DPR, fs: 11 * DPR }))
    .concat(
      state.won && !state.dailyDate && state.won.n === 3 && social.timelineAvailable()
        ? [
            {
              id: "timeline",
              label: "分享到朋友圈",
              x: m.x + 16 * DPR,
              y: m.y + m.h - 110 * DPR,
              w: m.w - 32 * DPR,
              h: 42 * DPR,
              fs: 13 * DPR,
            },
          ]
        : [],
    );
}
function _drawWin(context, g) {
  const { winBox, W, H, ui, DPR, state, starGoals, S, winButtons, daily } = context;
  const m = winBox();
  g.fillStyle = "rgba(10,10,20,.82)";
  g.fillRect(0, 0, W, H);
  ui.panel(g, m.x, m.y, m.w, m.h, 2 * DPR);
  // Temporary Win Streak Countdown Banner at Top of Victory Modal
  const remainSec = Math.max(0, 15 - Math.floor((Date.now() - (state.winAt || Date.now())) / 1000));
  g.fillStyle = "#132238";
  g.fillRect(m.x + 10 * DPR, m.y + 8 * DPR, m.w - 20 * DPR, 22 * DPR);
  g.fillStyle = "#73eff7";
  g.fillRect(m.x + 10 * DPR, m.y + 28 * DPR, ((m.w - 20 * DPR) * Math.max(8, (remainSec / 15) * 100)) / 100, 2 * DPR);
  ui.text(g, "连胜倒计时 " + remainSec + "s · 下一关再次 3★ 奖 +50 金币", W / 2, m.y + 19 * DPR, 9.5 * DPR, "#73eff7");
  ui.text(g, "挑战成功", W / 2, m.y + 48 * DPR, 22 * DPR, "#ffcd75");
  ui.text(g, "★".repeat(state.won.n) + "☆".repeat(3 - state.won.n), W / 2, m.y + 84 * DPR, 26 * DPR, "#ffcd75");
  if (state.won.streakMaster) {
    ui.text(g, "🏆 连胜大师 · 连续3关3星 +" + (state.won.streakBonus || 50) + " 金币", W / 2, m.y + 110 * DPR, 10.5 * DPR, "#ffcd75");
  }
  starGoals().forEach((a, i) =>
    ui.text(
      g,
      (a.ok ? "已达成 · " : "未达成 · ") + a.text,
      m.x + 16 * DPR,
      m.y + (134 + i * 24) * DPR,
      10.5 * DPR,
      a.ok ? "#a7f070" : "#ffcd75",
      "left",
    ),
  );
  ui.text(
    g,
    "用时 " +
      state.won.sec +
      "s · 金币 +" +
      state.reward +
      " · 最佳 " +
      (state.dailyDate ? daily.bestSec(state.dailyDate, state.won.sec) : S.best[state.L.id].sec) +
      "s",
    W / 2,
    m.y + 214 * DPR,
    10.5 * DPR,
    "#94b0c2",
  );
  if (state.dailyDate)
    ui.wrapped(g, daily.rewardNote(state.dailyDate, state.reward), W / 2, m.y + 236 * DPR, m.w - 32 * DPR, 10.5 * DPR, "#94b0c2");
  else ui.text(g, "再挑战不消耗体力", W / 2, m.y + 236 * DPR, 10 * DPR, "#94b0c2");
  winButtons().forEach((b) => ui.btn(g, b, 2 * DPR));
}
module.exports = (context) => ({
  winBox: (...args) => _winBox(context, ...args),
  winButtons: (...args) => _winButtons(context, ...args),
  drawWin: (...args) => _drawWin(context, ...args),
});
