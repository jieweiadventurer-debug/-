const { DPR, W, H, contentTop, safeBottom } = require("../engine/canvas");
const ui = require("../engine/ui");
const { register, go } = require("../engine/scene-manager");
const store = require("../engine/storage");
const CFG = require("../data/config");
const LV = require("../data/levels");
const S = store.state;
const runs = require("../engine/runs");
const entry = require("../engine/level-entry");
let btns = [],
  filter = "all",
  sortBy = "default",
  visible = [],
  footerY = 0,
  cardY = 0,
  enterAt = 0;
const unlocked = (i) => CFG.DEV_UNLOCK || i === 0 || (S.stars[LV[i - 1].id] || 0) > 0;
const filters = [
  ["all", "全部"],
  ["stars", "补星"],
  ["resume", "续玩"],
];
const sorts = [
  ["default", "默认"],
  ["difficulty", "按难度排序"],
  ["fastest", "按完成时间（最快）"],
];
function diffScore(lv) {
  const inv = lv.inv || {};
  const v = [inv.s || 0, inv.c || 0, inv.t || 0, inv.a || 0].filter((n) => n > 0).length;
  return lv.par + v * 1.4 + (inv.t > 0 ? 2.5 + inv.t * 0.8 : 0) + (inv.a > 0 ? 4.5 + inv.a * 1.2 : 0) + (typeof lv.range === "number" ? 1.5 : 0);
}
function efficiencyPct(lv, best) {
  if (!best || !Number.isFinite(best.sec) || best.sec <= 0) return 0;
  const opt = Math.max(3, lv.par * 3);
  return Math.max(1, Math.min(100, Math.round((opt / best.sec) * 100)));
}
function matches(i, kind) {
  const n = S.stars[LV[i].id] || 0;
  return kind === "all" || (unlocked(i) && (kind === "stars" ? n > 0 && n < 3 : !!runs.read(LV[i])));
}
function timeLabel(sec) {
  return (
    Math.floor(sec / 60)
      .toString()
      .padStart(2, "0") +
    ":" +
    (sec % 60).toString().padStart(2, "0")
  );
}
function layout() {
  enterAt = Date.now();
  btns = [{ id: "home", x: W * 0.05, y: contentTop, w: W * 0.2, h: Math.max(28 * DPR, H * 0.035), label: "← 地图", fs: W * 0.03 }];
  const pad = W * 0.05,
    tw = (W * 0.9) / CFG.CHAPTERS.length,
    th = Math.max(40 * DPR, H * 0.046);
  CFG.CHAPTERS.forEach((n, i) =>
    btns.push({
      id: "ch:" + i,
      x: pad + i * tw,
      y: contentTop + H * 0.075,
      w: tw - 4 * DPR,
      h: th,
      label: String(i + 1),
      primary: i === S.ch,
      fs: th * 0.48,
    }),
  );
  const indices = Array.from({ length: 10 }, (_, k) => S.ch * 10 + k),
    fy = Math.max(contentTop + H * 0.135, contentTop + H * 0.075 + th + 8 * DPR),
    fw = (W * 0.9 - 16 * DPR) / 3;
  filters.forEach(([id, label], i) =>
    btns.push({
      id: "filter:" + id,
      x: pad + i * (fw + 8 * DPR),
      y: fy,
      w: fw,
      h: 24 * DPR,
      label: label + " " + indices.filter((j) => matches(j, id)).length,
      primary: filter === id,
      fs: 10 * DPR,
    }),
  );
  const sy = fy + 28 * DPR;
  sorts.forEach(([id, label], i) =>
    btns.push({
      id: "sort:" + id,
      x: pad + i * (fw + 8 * DPR),
      y: sy,
      w: fw,
      h: 22 * DPR,
      label,
      primary: sortBy === id,
      fs: 9 * DPR,
    }),
  );
  visible = indices.filter((i) => matches(i, filter));
  if (sortBy === "difficulty") {
    visible.sort((a, b) => diffScore(LV[b]) - diffScore(LV[a]) || a - b);
  } else if (sortBy === "fastest") {
    visible.sort((a, b) => {
      const ba = S.best[LV[a].id], bb = S.best[LV[b].id];
      const ha = ba && Number.isFinite(ba.sec) && ba.sec > 0;
      const hb = bb && Number.isFinite(bb.sec) && bb.sec > 0;
      if (ha && hb) return ba.sec - bb.sec || a - b;
      if (ha) return -1;
      if (hb) return 1;
      return a - b;
    });
  }
  cardY = sy + 28 * DPR;
  const ch = Math.min(62 * DPR, (H - safeBottom - cardY - 42 * DPR) / 5 - 8 * DPR);
  visible.forEach((i, k) =>
    btns.push({
      id: "lv:" + i,
      x: pad + (k % 2) * W * 0.46,
      y: cardY + Math.floor(k / 2) * (ch + 8 * DPR),
      w: W * 0.44,
      h: ch,
      label: LV[i].id,
      locked: !unlocked(i),
      resume: !!runs.read(LV[i]),
    }),
  );
  footerY = cardY + (visible.length ? Math.ceil(visible.length / 2) * (ch + 8 * DPR) : 85 * DPR) + 8 * DPR;
}
register("levels", {
  enter() {
    layout();
  },
  draw(g) {
    ui.background(g, W, H);
    ui.text(g, "第 " + (S.ch + 1) + " 章 · " + CFG.CHAPTERS[S.ch], W / 2, contentTop + H * 0.06, W * 0.048, "#ffcd75");
    btns.forEach((b) => {
      const level = b.id.startsWith("lv:");
      if (b.locked) g.globalAlpha = 0.55;
      ui.btn(g, Object.assign({}, b, { label: level ? "" : b.label }), 4);
      if (level) {
        const idx = +b.id.slice(3),
          lv = LV[idx],
          n = S.stars[b.label] || 0,
          best = S.best[b.label],
          eff = efficiencyPct(lv, best),
          age = Math.max(0, Date.now() - enterAt),
          pop = n > 0 && !(S.settings && S.settings.reduceMotion) && age < 260 ? 0.94 + 0.06 * Math.min(1, age / 260) : 1;
        if (pop !== 1 && g.save && g.translate && g.scale && g.restore) {
          const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
          g.save();
          g.translate(cx, cy);
          g.scale(pop, pop);
          g.translate(-cx, -cy);
        }
        if (n > 0) {
          g.fillStyle = n === 3 ? "#ffcd75" : "#5fe36c";
          g.fillRect(b.x + 3 * DPR, b.y + 3 * DPR, 3 * DPR, b.h - 6 * DPR);
          ui.text(g, "✓", b.x + b.w * 0.11, b.y + b.h * 0.32, 11 * DPR, n === 3 ? "#ffcd75" : "#5fe36c");
        }
        ui.text(g, b.label, b.x + b.w * (n > 0 ? 0.31 : 0.25), b.y + b.h * 0.32, 16 * DPR, b.locked ? "#94b0c2" : "#f4f4f4");
        ui.text(g, b.locked ? "锁" : "★".repeat(n) + "☆".repeat(3 - n), b.x + b.w * 0.72, b.y + b.h * 0.34, 11 * DPR, "#ffcd75");
        const detail = b.locked
          ? "通关上一关解锁"
          : b.resume
            ? "续玩 · 不耗体力"
            : best && Number.isFinite(best.sec)
              ? "最佳 " + timeLabel(best.sec)
              : n > 0
                ? "已通关"
                : "未挑战";
        ui.text(g, detail, b.x + b.w * 0.42, b.y + b.h * 0.68, 9.5 * DPR, b.resume ? "#a7f070" : n > 0 ? "#5fe36c" : "#b5c9d6");
        // Bottom progress bar + efficiency % label beside it
        const barX = b.x + 8 * DPR, barY = b.y + b.h - 7 * DPR, barW = b.w * 0.68;
        g.fillStyle = "#101524";
        g.fillRect(barX, barY, barW, 3 * DPR);
        g.fillStyle = n === 3 ? "#ffcd75" : "#5fe36c";
        g.fillRect(barX, barY, (barW * Math.max(n > 0 ? 10 : 0, eff)) / 100, 3 * DPR);
        ui.text(g, eff + "%", b.x + b.w * 0.86, b.y + b.h - 5 * DPR, 8.5 * DPR, eff >= 80 ? "#ffcd75" : "#73eff7");
        if (pop !== 1 && g.restore) g.restore();
      }
      g.globalAlpha = 1;
    });
    if (!visible.length) {
      ui.text(
        g,
        filter === "stars" ? "本章暂无需要补星的已通关关卡" : "本章没有未完成的存档",
        W / 2,
        cardY + 28 * DPR,
        12 * DPR,
        "#b5c9d6",
      );
      ui.text(g, "切换“全部”，继续新的接力", W / 2, cardY + 54 * DPR, 11 * DPR, "#94b0c2");
    }
    const total = LV.slice(S.ch * 10, S.ch * 10 + 10).reduce((n, l) => n + (S.stars[l.id] || 0), 0);
    ui.panel(g, W * 0.05, footerY, W * 0.65, H * 0.025, 3);
    g.fillStyle = "#ffcd75";
    g.fillRect(W * 0.05 + 4, footerY + 4, ((W * 0.65 - 8) * total) / 30, Math.max(0, H * 0.025 - 8));
    ui.text(g, total + " / 30 ★", W * 0.83, footerY + H * 0.013, W * 0.033, "#ffcd75");
  },
  onTap(x, y) {
    const b = ui.hit(btns, x, y);
    if (!b) return;
    if (b.id === "home") go("world");
    else if (b.id.startsWith("ch:")) {
      S.ch = +b.id.slice(3);
      layout();
    } else if (b.id.startsWith("filter:")) {
      filter = b.id.slice(7);
      layout();
    } else if (b.id.startsWith("sort:")) {
      sortBy = b.id.slice(5);
      layout();
    } else if (b.id.startsWith("lv:") && !b.locked) {
      const i = +b.id.slice(3);
      entry.enter(
        i,
        () => go("game", { index: i, resume: true }),
        () => go("game", i),
      );
    }
  },
});
